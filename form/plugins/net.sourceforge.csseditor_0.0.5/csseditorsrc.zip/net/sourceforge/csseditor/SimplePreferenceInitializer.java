package net.sourceforge.csseditor;

import net.sourceforge.csseditor.internal.CssEditorPreferences;

import org.eclipse.core.runtime.preferences.AbstractPreferenceInitializer;
import org.eclipse.jface.preference.IPreferenceStore;
import org.eclipse.ui.editors.text.TextEditorPreferenceConstants;

public class SimplePreferenceInitializer extends AbstractPreferenceInitializer {
	
	public SimplePreferenceInitializer() {
		super();
	}
	
	public void initializeDefaultPreferences() {
		IPreferenceStore store = CssEditorPlugin.getDefault().getPreferenceStore();
        TextEditorPreferenceConstants.initializeDefaultValues(store);
        CssEditorPreferences.initializeDefaultValues(store);
	}

}
