/*
 * Copyright (c) 2003 Christopher Lenz and others.
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 * 
 * Contributors:
 *     Christopher Lenz - initial API and implementation
 * 
 * $Id: CssEditorPlugin.java,v 1.3 2004/06/25 09:51:22 cell Exp $
 */

package net.sourceforge.csseditor;

import java.net.URL;

import net.sourceforge.csseditor.internal.CssEditorPreferences;
import net.sourceforge.csseditor.internal.ProfileManager;
import net.sourceforge.csseditor.text.CssTextTools;

import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Status;
import org.eclipse.jface.preference.IPreferenceStore;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.jface.resource.ImageRegistry;
import org.eclipse.ui.editors.text.TextEditorPreferenceConstants;
import org.eclipse.ui.plugin.AbstractUIPlugin;
import org.osgi.framework.BundleContext;

/**
 * The main plugin class.
 */
public final class CssEditorPlugin extends AbstractUIPlugin  {

    // Constants ---------------------------------------------------------------

    public static final String ICON_STYLE_SHEET =
        "style_sheet_obj.gif"; //$NON-NLS-1$
    public static final String ICON_AT_RULE =
        "at_rule_obj.gif"; //$NON-NLS-1$
    public static final String ICON_STYLE_RULE =
        "style_rule_obj.gif"; //$NON-NLS-1$
    public static final String ICON_PROPERTY =
        "property_obj.gif"; //$NON-NLS-1$
    public static final String ICON_SHORTHAND =
        "shorthand_obj.gif"; //$NON-NLS-1$
    public static final String ICON_PSEUDO_CLASS =
        "pseudo_class_obj.gif"; //$NON-NLS-1$
    public static final String ICON_IMPORTANT =
        "important_obj.gif"; //$NON-NLS-1$

    // Class Variables ---------------------------------------------------------

    /**
     * Singleton instance of the plugin.
     */
    private static CssEditorPlugin plugin;

    // Instance Variables ------------------------------------------------------

    /**
     * The text tools collection.
     */
    private CssTextTools textTools;

    /**
     * The profile manager.
     */
    private IProfileManager profileManager;

    // Constructors ------------------------------------------------------------

    /**
     * Constructor.
     * 
     * @param descriptor the plugin descriptor.
     */
    public CssEditorPlugin() {
        plugin = this;
    }

    // Static Methods ----------------------------------------------------------

    /**
     * Returns the singleton instance of the plugin.
     * 
     * @return the plugin instance
     */
    public static CssEditorPlugin getDefault() {
        return plugin;
    }

    /**
     * Returns the plugin ID.
     * 
     * @return the plugin ID
     */
    public static String getPluginId() {
        return getDefault().getBundle().getSymbolicName();
    }

    // Public Methods ----------------------------------------------------------

    /**
     * 
     */
    public synchronized CssTextTools getTextTools() {
        if (textTools == null) {
            textTools = new CssTextTools(getPreferenceStore());
        }
        return textTools;
    }

    /**
     * Returns the object that manages the CSS profiles.
     * 
     * @return the profile manager
     */
    public synchronized IProfileManager getProfileManager() {
        if (profileManager == null) {
            profileManager = new ProfileManager(getPreferenceStore());
        }
        return profileManager;
    }

    /**
     * Returns an image descriptor for the image corresponding to the specified
     * key (which is the name of the image file).
     * 
     * @param key The key of the image
     * @return The descriptor for the requested image, or <code>null</code> if 
     *         the image could not be found
     */
    public ImageDescriptor getImageDescriptor(String key) {
        URL url = null;
        try {
			url = getBundle().getEntry("/icons/" + key); //$NON-NLS-1$
			return ImageDescriptor.createFromURL(url);
		} catch (IllegalStateException e) {
            // we'll just return null
        }
        return ImageDescriptor.createFromURL(url);
    }

    public static void log(IStatus status) {
        getDefault().getLog().log(status);
        if (status.getException() != null) {
            status.getException().printStackTrace(System.err);
        }
    }

    public static void log(String message, Throwable e) {
        IStatus status = new Status(IStatus.ERROR, getPluginId(), IStatus.ERROR,
            message, e); 
        log(status);
    }

    public static void log(String message) {
        IStatus status = new Status(IStatus.ERROR, getPluginId(), IStatus.ERROR,
            message, null); 
        log(status);
    }

    public static void log(Throwable e) {
        log(e.getMessage(), e);
    }
    
    // AbstractUIPlugin Implementation -----------------------------------------

    /*
     * @see org.eclipse.core.runtime.Plugin#stop(BundleContext)
     */
    public void stop(BundleContext context) throws Exception {
        if (textTools != null) {
            textTools.dispose();
            textTools = null;
        }
        super.stop(context);
    }

    /*
     * @see AbstractUIPlugin#initializeDefaultPreferences(IPreferenceStore)
     * 
     * 2008-03-26: this code has moved to net.sourceforge.csseditor.SimplePreferenceInitializer, because of changes in eclispe's preference mechanism.
     * see comment in: org.eclipse.core.runtime.PlugininitializeDefaultPluginPreferences()
     */
    /*
    protected void initializeDefaultPreferences(IPreferenceStore store) {
        TextEditorPreferenceConstants.initializeDefaultValues(store);
        CssEditorPreferences.initializeDefaultValues(store);
    }
    */
    

    /*
     * @see AbstractUIPlugin#initializeImageRegistry(ImageRegistry)
     */
    protected void initializeImageRegistry(ImageRegistry reg) {
        reg.put(ICON_AT_RULE, getImageDescriptor(ICON_AT_RULE));
        reg.put(ICON_STYLE_RULE, getImageDescriptor(ICON_STYLE_RULE));
        reg.put(ICON_STYLE_SHEET, getImageDescriptor(ICON_STYLE_SHEET));
        reg.put(ICON_PROPERTY, getImageDescriptor(ICON_PROPERTY));
        reg.put(ICON_SHORTHAND, getImageDescriptor(ICON_SHORTHAND));
        reg.put(ICON_PSEUDO_CLASS, getImageDescriptor(ICON_PSEUDO_CLASS));
        reg.put(ICON_IMPORTANT, getImageDescriptor(ICON_IMPORTANT));
    }

}
