/*
 * Copyright (c) 2003 Christopher Lenz and others.
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 * 
 * Contributors:
 *     Christopher Lenz - initial API and implementation
 * 
 * $Id: IStyleSheet.java,v 1.1.1.1 2003/12/14 21:59:56 cell Exp $
 */

package net.sourceforge.csseditor.model;

import net.sourceforge.csseditor.parser.IProblemCollector;
import net.sourceforge.csseditor.parser.LexicalErrorException;
import net.sourceforge.csseditor.parser.SyntaxErrorException;

/**
 * 
 */
public interface IStyleSheet extends ISourceReference {

    /**
     * Returns the rule at the specified offset into the document.
     * 
     * @param offset the offset
     * @return the rule at the offset, or <code>null</code> if no rule is found
     *         at that position
     */
    IRule getRuleAt(int offset);

    /**
     * Returns the list of rules in the order they have been defined in the 
     * style sheet.
     * 
     * @return the list of rules contained by the style sheet
     */
    IRule[] getRules();

    void reconcile(IProblemCollector problemCollector)
        throws LexicalErrorException, SyntaxErrorException;

    void addListener(IStyleSheetListener listener);

    void removeListener(IStyleSheetListener listener);

}
