/*
 * Copyright (c) 2003 Christopher Lenz and others.
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 * 
 * Contributors:
 *     Christopher Lenz - initial API and implementation
 * 
 * $Id: StyleSheetChangeEvent.java,v 1.1.1.1 2003/12/14 21:59:56 cell Exp $
 */

package net.sourceforge.csseditor.model;

/**
 * 
 */
public class StyleSheetChangeEvent {

    // Instance Variables ------------------------------------------------------

    /**
     * The style sheet associated with the change event.
     */
    private IStyleSheet fStyleSheet;

    // Constructors ------------------------------------------------------------

    /**
     * Constructor.
     * 
     * @param styleSheet The style sheet that has changed.
     */
    public StyleSheetChangeEvent(IStyleSheet styleSheet) {
        this.fStyleSheet = styleSheet;
    }

    // Public Methods ----------------------------------------------------------

    /**
     * Returns the style sheet that has changed.
     * 
     * @return the style sheet
     */
    public IStyleSheet getStyleSheet() {
        return this.fStyleSheet;
    }

}
