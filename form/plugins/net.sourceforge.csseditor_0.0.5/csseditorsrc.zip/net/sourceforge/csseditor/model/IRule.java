/*
 * Copyright (c) 2003 Christopher Lenz and others.
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 * 
 * Contributors:
 *     Christopher Lenz - initial API and implementation
 * 
 * $Id: IRule.java,v 1.1.1.1 2003/12/14 21:59:55 cell Exp $
 */

package net.sourceforge.csseditor.model;

/**
 * 
 */
public interface IRule extends ISourceReference {

    /**
     * Returns the style sheet that contains this rule.
     * 
     * @return the style sheet
     */
    IStyleSheet getStyleSheet();

    /**
     * Returns the rule in which this rule is nested, or <code>null</code> if 
     * this rule is at the top level of the style sheet.
     * 
     * @return the parent rule
     */
    IRule getParent();

    IRule[] getChildren();

    /**
     * Returns the declaration at the specified offset into the rule.
     * 
     * @param offset the offset
     * @return the declaration at the offset, or <code>null</code> if no
     *         declaration is found at that position
     */
    IDeclaration getDeclarationAt(int offset);

    IDeclaration[] getDeclarations();

}
