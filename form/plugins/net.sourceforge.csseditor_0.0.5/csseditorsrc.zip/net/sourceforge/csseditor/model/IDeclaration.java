/*
 * Copyright (c) 2003 Christopher Lenz and others.
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 * 
 * Contributors:
 *     Christopher Lenz - initial API and implementation
 * 
 * $Id: IDeclaration.java,v 1.1.1.1 2003/12/14 21:59:55 cell Exp $
 */

package net.sourceforge.csseditor.model;

/**
 * Represents a single CSS declaration.
 */
public interface IDeclaration extends ISourceReference {

    /**
     * Returns the rule that contains this declaration.
     * 
     * @return the rule containing this declaration, or <code>null</code> if the
     *         declaration doesn't belong to a specific rule
     */
    IRule getRule();

    /**
     * Returns the source reference representing the property.
     * 
     * @return the property
     */
    ISourceReference getProperty();

    /**
     * Returns the source reference consisting of the value assigned to the
     * property.
     * 
     * @return the value
     */
    ISourceReference getValue();

    /**
     * Returns the source reference representing the priority (mostly, that will
     * be "<code>!important</code>") of the declaration, or <code>null</code>
     * if no special priority was specified.
     * 
     * @return the priority
     */
    ISourceReference getPriority();

}
