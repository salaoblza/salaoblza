/*
 * Copyright (c) 2003 Christopher Lenz and others.
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 * 
 * Contributors:
 *     Christopher Lenz - initial API and implementation
 * 
 * $Id: IPropertyInfo.java,v 1.1.1.1 2003/12/14 21:59:55 cell Exp $
 */

package net.sourceforge.csseditor.model;

/**
 * Encapsulates information about a specific property. 
 */
public interface IPropertyInfo {

    String getName();

    String getCategory();

    String getDescription();

    boolean isShorthand();

}
