/*
 * Copyright (c) 2003 Christopher Lenz and others.
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 * 
 * Contributors:
 *     Christopher Lenz - initial API and implementation
 * 
 * $Id: ICssEditorHelpContextIds.java,v 1.1.1.1 2003/12/14 21:59:35 cell Exp $
 */

package net.sourceforge.csseditor.internal;

import net.sourceforge.csseditor.CssEditorPlugin;

/**
 * Symbolic constants for the help context IDs.
 */
public interface ICssEditorHelpContextIds {

    /** 
     * The string with which all other defined ids are prefixed to construct
     * help context ids. 
     */
    String PREFIX = CssEditorPlugin.getPluginId() + "."; //$NON-NLS-1$

    /**
     * Help context ID for the CSS editor.
     * Value: <code>"net.sourceforge.csseditor.editor_context"</code>.
     */
    String EDITOR = PREFIX + "css_editor_context"; //$NON-NLS-1$

}
