/*
 * Copyright (c) 2003 Christopher Lenz and others.
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 * 
 * Contributors:
 *     Christopher Lenz - initial API and implementation
 * 
 * $Id: DefaultProblem.java,v 1.1.1.1 2003/12/14 21:59:43 cell Exp $
 */

package net.sourceforge.csseditor.internal.parser;

import net.sourceforge.csseditor.parser.IProblem;

/**
 * 
 */
public class DefaultProblem implements IProblem {

    // Instance Variables ------------------------------------------------------

    private String fId;

    private String fMessage;

    private String fOriginatingFileName;

    private int fSourceStart;

    private int fSourceEnd;

    private int fSourceLineNumber;

    private boolean fError;

    // Constructors ------------------------------------------------------------

    public DefaultProblem(String id, String message, String originatingFileName,
        int sourceStart, int sourceEnd, int sourceLineNumber, boolean error) {
        this.fId = id;
        this.fMessage = message;
        this.fOriginatingFileName = originatingFileName;
        this.fSourceStart = sourceStart;
        this.fSourceEnd = sourceEnd;
        this.fSourceLineNumber = sourceLineNumber;
        this.fError = error;
    }

    // IProblem Implementation -------------------------------------------------

    /**
     * @see net.sourceforge.csseditor.IProblem#getID()
     */
    public String getId() {
        return fId;
    }

    /**
     * @see net.sourceforge.csseditor.IProblem#getMessage()
     */
    public String getMessage() {
        return fMessage;
    }

    /**
     * @see net.sourceforge.csseditor.IProblem#getOriginatingFileName()
     */
    public String getOriginatingFileName() {
        return fOriginatingFileName;
    }

    /**
     * @see net.sourceforge.csseditor.IProblem#getSourceEnd()
     */
    public int getSourceEnd() {
        return fSourceEnd;
    }

    /**
     * @see net.sourceforge.csseditor.IProblem#getSourceLineNumber()
     */
    public int getSourceLineNumber() {
        return fSourceLineNumber;
    }

    /**
     * @see net.sourceforge.csseditor.IProblem#getSourceStart()
     */
    public int getSourceStart() {
        return fSourceStart;
    }

    /**
     * @see net.sourceforge.csseditor.IProblem#isError()
     */
    public boolean isError() {
        return fError;
    }

    /**
     * @see net.sourceforge.csseditor.IProblem#isWarning()
     */
    public boolean isWarning() {
        return !fError;
    }

}
