/*
 * Copyright (c) 2003 Christopher Lenz and others.
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 * 
 * Contributors:
 *     Christopher Lenz - initial API and implementation
 * 
 * $Id: ICssEditorActionConstants.java,v 1.1.1.1 2003/12/14 21:59:34 cell Exp $
 */

package net.sourceforge.csseditor.internal;

import org.eclipse.ui.texteditor.ITextEditorActionConstants;

/**
 * 
 */
public interface ICssEditorActionConstants
    extends ITextEditorActionConstants {

    /**
     * Edit menu: name of the standard global action "Content Assist"
     * (value <code>"ContentAssist"</code>).
     */
    String CONTENT_ASSIST = "ContentAssist";  //$NON-NLS-1$

    /**
     * Source menu: name of standard global action "Comment"
     * (value <code>"Comment"</code>).
     */
    String COMMENT = "Comment"; //$NON-NLS-1$

    /**
     * Source menu: name of standard global action "Uncomment"
     * (value <code>"Uncomment"</code>).
     */
    String UNCOMMENT = "Uncomment"; //$NON-NLS-1$

}
