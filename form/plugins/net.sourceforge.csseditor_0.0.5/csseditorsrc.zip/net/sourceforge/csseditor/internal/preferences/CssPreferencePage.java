/*
 * Copyright (c) 2003 Christopher Lenz and others.
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 * 
 * Contributors:
 *     Christopher Lenz - initial API and implementation
 * 
 * $Id: CssPreferencePage.java,v 1.2 2003/12/27 18:46:56 cell Exp $
 */

package net.sourceforge.csseditor.internal.preferences;

import java.util.Arrays;
import java.util.Comparator;

import org.eclipse.jface.preference.FieldEditorPreferencePage;
import org.eclipse.jface.preference.RadioGroupFieldEditor;
import org.eclipse.ui.IWorkbench;
import org.eclipse.ui.IWorkbenchPreferencePage;

import net.sourceforge.csseditor.CssEditorPlugin;
import net.sourceforge.csseditor.IProfileDescriptor;
import net.sourceforge.csseditor.IProfileManager;
import net.sourceforge.csseditor.internal.CssEditorMessages;
import net.sourceforge.csseditor.internal.CssEditorPreferences;

/**
 * TODO This really just selects the default profile, not the global profile
 *      Depends on the implementation of a per-project or per-resource profile
 *      selection property page
 */
public class CssPreferencePage extends FieldEditorPreferencePage
    implements IWorkbenchPreferencePage {

    // Constructors ------------------------------------------------------------

    /**
     * Default constructor.
     */
    public CssPreferencePage() {
        super(getString("description"), FLAT); //$NON-NLS-1$
    }

    // FieldEditorPreferencePage Implementation --------------------------------

    /**
     * @see FieldEditorPreferencePage#createFieldEditors()
     */
    protected void createFieldEditors() {
        IProfileManager mgr = CssEditorPlugin.getDefault().getProfileManager();
        IProfileDescriptor[] profiles = mgr.getProfileDescriptors();
        String[][] radios = new String[profiles.length][2];
        for (int i = 0; i < profiles.length; i++) {
            radios[i][0] = profiles[i].getName();
            radios[i][1] = profiles[i].getId();
        }
        Arrays.sort(radios, new Comparator() {
            public int compare(Object o1, Object o2) {
                return (((String[]) o1)[0]).compareTo(((String[]) o2)[0]);
            }
        });
        RadioGroupFieldEditor profileField = 
            new RadioGroupFieldEditor(CssEditorPreferences.PROFILE,
                getString("profile"), 1, radios, //$NON-NLS-1$
                getFieldEditorParent(), true);
        addField(profileField);
    }

    // IWorkbenchPreferencePage Implementation ---------------------------------

    /**
     * @see IWorkbenchPreferencePage#init
     */
    public void init(IWorkbench workbench) {
        setPreferenceStore(CssEditorPlugin.getDefault().getPreferenceStore());
    }

    // Private Methods ---------------------------------------------------------

    private static String getString(String key) {
        return CssEditorMessages.getString(
            "CssPreferencePage." + key); //$NON-NLS-1$
    }

}
