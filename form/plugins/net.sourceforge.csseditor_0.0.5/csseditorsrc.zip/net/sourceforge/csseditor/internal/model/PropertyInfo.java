/*
 * Copyright (c) 2003 Christopher Lenz and others.
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 * 
 * Contributors:
 *     Christopher Lenz - initial API and implementation
 * 
 * $Id: PropertyInfo.java,v 1.2 2004/01/13 13:54:05 cell Exp $
 */

package net.sourceforge.csseditor.internal.model;

import net.sourceforge.csseditor.model.IPropertyInfo;

/**
 * 
 */
public class PropertyInfo implements IPropertyInfo {

    // Instance Variables ------------------------------------------------------

    private String name;

    private String category;

    private String description;

    private boolean shorthand;

    // Constructors ------------------------------------------------------------

    /**
     * Constructor.
     * 
     * @param name The name of the property
     * @param category The category of the property
     */
    public PropertyInfo(String name, String category) {
        this(name, category, false);
    }

    /**
     * Constructor.
     * 
     * @param name The name of the property
     * @param category The category of the property
     * @param shorthand Whether the property is a shorthand property
     */
    public PropertyInfo(String name, String category, boolean shorthand) {
        this(name, category, null, shorthand);
    }

    /**
     * Constructor.
     * 
     * @param name The name of the property
     * @param category The category of the property
     * @param description An optional description of the property
     * @param shorthand Whether the property is a shorthand property
     */
    public PropertyInfo(String name, String category, String description,
        boolean shorthand) {
        this.name = name;
        this.category = category;
        this.description = description;
        this.shorthand = shorthand;
    }

    // IPropertyInfo Implementation --------------------------------------------

    /*
     * @see net.sourceforge.csseditor.model.IPropertyInfo#getName()
     */
    public String getName() {
        return name;
    }

    /*
     * @see net.sourceforge.csseditor.model.IPropertyInfo#getCategory()
     */
    public String getCategory() {
        return category;
    }

    /*
     * @see net.sourceforge.csseditor.model.IPropertyInfo#getDescription()
     */
    public String getDescription() {
        return description;
    }

    /*
     * @see net.sourceforge.csseditor.model.IPropertyInfo#isShorthand()
     */
    public boolean isShorthand() {
        return shorthand;
    }

}
