/*
 * Copyright (c) 2003 Christopher Lenz and others.
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 * 
 * Contributors:
 *     Christopher Lenz - initial API and implementation
 * 
 * $Id: CssEditorAppearanceConfigurationBlock.java,v 1.2 2003/12/27 18:46:56 cell Exp $
 */

package net.sourceforge.csseditor.internal.preferences;

import org.eclipse.jface.preference.ColorSelector;
import org.eclipse.jface.preference.IPreferenceStore;
import org.eclipse.jface.preference.PreferenceConverter;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.graphics.RGB;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.List;

import net.sourceforge.csseditor.internal.CssEditorMessages;
import net.sourceforge.csseditor.internal.CssEditorPreferences;

/**
 * 
 */
final class CssEditorAppearanceConfigurationBlock
    extends AbstractConfigurationBlock {

    // Instance Variables ------------------------------------------------------

    private List fColorList;
    private final String[][] fColorListModel = new String[][] {
        { getString("lineNumberForegroundColor"), //$NON-NLS-1$
          CssEditorPreferences.EDITOR_LINE_NUMBER_RULER_COLOR },
        { getString("matchingBracketsHighlightColor"), //$NON-NLS-1$
          CssEditorPreferences.EDITOR_MATCHING_BRACKETS_COLOR },
        { getString("currentLineHighlighColor"), //$NON-NLS-1$
          CssEditorPreferences.EDITOR_CURRENT_LINE_COLOR },
        { getString("printMarginColor"), //$NON-NLS-1$
          CssEditorPreferences.EDITOR_PRINT_MARGIN_COLOR },
    };
    private ColorSelector fColorSelector;

    // Constructors ------------------------------------------------------------

    public CssEditorAppearanceConfigurationBlock(IPreferenceStore store) {
        super(store);
    }

    // Public Methods ----------------------------------------------------------

    public Control createControl(Composite parent) {

        Composite control = new Composite(parent, SWT.NONE);
        GridLayout layout = new GridLayout();
        layout.numColumns = 2;
        control.setLayout(layout);

        addTextField(control, getString("displayedTabWidth"), //$NON-NLS-1$
            CssEditorPreferences.EDITOR_TAB_WIDTH, 3, 0);
        addTextField(control, getString("printMarginColumn"), //$NON-NLS-1$
            CssEditorPreferences.EDITOR_PRINT_MARGIN_COLUMN, 3,
            0);
        addBooleanField(control, getString("showOverviewRuler"), //$NON-NLS-1$
            CssEditorPreferences.EDITOR_OVERVIEW_RULER, 0);
        addBooleanField(control, getString("showLineNumbers"), //$NON-NLS-1$
            CssEditorPreferences.EDITOR_LINE_NUMBER_RULER, 0);
        addBooleanField(control,
            getString("highlightMatchingBrackets"), //$NON-NLS-1$
            CssEditorPreferences.EDITOR_MATCHING_BRACKETS, 0);
        addBooleanField(control,
            getString("highlightCurrentLine"), //$NON-NLS-1$
            CssEditorPreferences.EDITOR_CURRENT_LINE, 0);
        addBooleanField(control, getString("showPrintMargin"), //$NON-NLS-1$
            CssEditorPreferences.EDITOR_PRINT_MARGIN, 0);

        Label label = new Label(control, SWT.LEFT);
        GridData gridData = new GridData(GridData.HORIZONTAL_ALIGN_FILL);
        gridData.horizontalSpan = 2;
        gridData.heightHint = convertHeightInCharsToPixels(control, 1) / 2;
        label.setLayoutData(gridData);

        label = new Label(control, SWT.LEFT);
        label.setText(getString("colorOptions")); //$NON-NLS-1$
        gridData = new GridData(GridData.HORIZONTAL_ALIGN_FILL);
        gridData.horizontalSpan = 2;
        label.setLayoutData(gridData);

        Composite editorComposite = new Composite(control, SWT.NONE);
        layout = new GridLayout();
        layout.numColumns = 2;
        layout.marginHeight = 0;
        layout.marginWidth = 0;
        editorComposite.setLayout(layout);
        gridData = new GridData(
            GridData.HORIZONTAL_ALIGN_FILL | GridData.FILL_VERTICAL);
        gridData.horizontalSpan = 2;
        editorComposite.setLayoutData(gridData);

        fColorList = new List(editorComposite,
            SWT.SINGLE | SWT.V_SCROLL | SWT.BORDER);
        gridData = new GridData(
            GridData.VERTICAL_ALIGN_BEGINNING | GridData.FILL_HORIZONTAL);
        gridData.heightHint = convertHeightInCharsToPixels(control, 8);
        fColorList.setLayoutData(gridData);
        fColorList.addSelectionListener(new SelectionListener() {
            public void widgetDefaultSelected(SelectionEvent e) {
                // do nothing
            }
            public void widgetSelected(SelectionEvent e) {
                handleColorListSelection();
            }
        });

        Composite stylesComposite = new Composite(editorComposite, SWT.NONE);
        layout = new GridLayout();
        layout.marginHeight = 0;
        layout.marginWidth = 0;
        layout.numColumns = 2;
        stylesComposite.setLayout(layout);
        stylesComposite.setLayoutData(new GridData(GridData.FILL_BOTH));
        label = new Label(stylesComposite, SWT.LEFT);
        label.setText(getString("color")); //$NON-NLS-1$
        gridData = new GridData();
        gridData.horizontalAlignment = GridData.BEGINNING;
        label.setLayoutData(gridData);

        fColorSelector = new ColorSelector(stylesComposite);
        Button foregroundColorButton = fColorSelector.getButton();
        gridData = new GridData(GridData.FILL_HORIZONTAL);
        gridData.horizontalAlignment = GridData.BEGINNING;
        foregroundColorButton.setLayoutData(gridData);
        foregroundColorButton.addSelectionListener(new SelectionListener() {
            public void widgetDefaultSelected(SelectionEvent e) {
                // do nothing
            }
            public void widgetSelected(SelectionEvent e) {
                int i = fColorList.getSelectionIndex();
                String key = fColorListModel[i][1];
                PreferenceConverter.setValue(getPreferenceStore(), key,
                    fColorSelector.getColorValue());
            }
        });

        initialize();

        return control;
    }

    // Event Handlers ----------------------------------------------------------

    void handleColorListSelection() {
        int i = fColorList.getSelectionIndex();
        String key = fColorListModel[i][1];
        RGB rgb = PreferenceConverter.getColor(getPreferenceStore(), key);
        fColorSelector.setColorValue(rgb);
    }

    // Private Methods ---------------------------------------------------------

    private static String getString(String key) {
        return CssEditorMessages.getString(
            "CssEditorPreferencePage.appearance." + key); //$NON-NLS-1$
    }

    private void initialize() {
        for (int i = 0; i < fColorListModel.length; i++) {
            fColorList.add(fColorListModel[i][0]);
        }
        fColorList.getDisplay().asyncExec(new Runnable() {
            public void run() {
                if ((fColorList != null)
                 && !fColorList.isDisposed()) {
                    fColorList.select(0);
                    handleColorListSelection();
                }
            }
        });
        initializeFields();
    }

}
