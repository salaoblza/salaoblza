/*
 * Copyright (c) 2003 Christopher Lenz and others.
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 * 
 * Contributors:
 *     Christopher Lenz - initial API and implementation
 * 
 * $Id: AbstractConfigurationBlock.java,v 1.1.1.1 2003/12/14 21:59:44 cell Exp $
 */

package net.sourceforge.csseditor.internal.preferences;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.eclipse.jface.dialogs.Dialog;
import org.eclipse.jface.preference.IPreferenceStore;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.ModifyEvent;
import org.eclipse.swt.events.ModifyListener;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.graphics.FontMetrics;
import org.eclipse.swt.graphics.GC;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Text;

/**
 * 
 */
abstract class AbstractConfigurationBlock {

    // Instance Variables ------------------------------------------------------

    private IPreferenceStore fPreferenceStore;

    private Map fCheckBoxes = new HashMap();
    private SelectionListener fCheckBoxListener = new SelectionListener() {
        public void widgetDefaultSelected(SelectionEvent e) {
        }
        public void widgetSelected(SelectionEvent e) {
            Button button = (Button) e.widget;
            getPreferenceStore().setValue((String) fCheckBoxes.get(button),
                button.getSelection());
        }
    };

    private Map fTextFields = new HashMap();
    private ModifyListener fTextFieldListener = new ModifyListener() {
        public void modifyText(ModifyEvent e) {
            Text text = (Text) e.widget;
            getPreferenceStore().setValue((String) fTextFields.get(text),
                text.getText());
        }
    };

    private List fNumberFields = new ArrayList();
    private ModifyListener fNumberFieldListener = new ModifyListener() {
        public void modifyText(ModifyEvent e) {
            //numberFieldChanged((Text) e.widget);
        }
    };

    private Map fLabels = new HashMap();

    // Constructors ------------------------------------------------------------

    public AbstractConfigurationBlock(IPreferenceStore store) {
        this.fPreferenceStore = store;    
    }

    // Public Methods ----------------------------------------------------------

    public void initializeFields() {
        for (Iterator i = fCheckBoxes.keySet().iterator(); i.hasNext(); ) {
            Button button = (Button) i.next();
            String key = (String) fCheckBoxes.get(button);
            button.setSelection(getPreferenceStore().getBoolean(key));
        }
        for (Iterator i = fTextFields.keySet().iterator(); i.hasNext(); ) {
            Text text = (Text) i.next();
            String key = (String) fTextFields.get(text);
            text.setText(getPreferenceStore().getString(key));
        }
    }

    // Protected Methods -------------------------------------------------------

    protected final Button addBooleanField(Composite parent, String label,
        String key, int indentation) {

        Button checkBox = new Button(parent, SWT.CHECK);
        checkBox.setText(label);

        GridData gd = new GridData(GridData.HORIZONTAL_ALIGN_BEGINNING);
        gd.horizontalIndent = indentation;
        gd.horizontalSpan = 2;
        checkBox.setLayoutData(gd);
        checkBox.addSelectionListener(fCheckBoxListener);

        fCheckBoxes.put(checkBox, key);

        return checkBox;
    }

    protected final Control addIntegerField(Composite composite, String label,
        String key, int textLimit, int indentation) {

        Text textControl =
            addStringField(composite, label, textLimit, indentation);
        fTextFields.put(textControl, key);
        fNumberFields.add(textControl);
        textControl.addModifyListener(fNumberFieldListener);

        return textControl;
    }

    protected final Control addTextField(Composite composite, String label,
        String key, int textLimit, int indentation) {

        Text textControl =
            addStringField(composite, label, textLimit, indentation);
        fTextFields.put(textControl, key);
        textControl.addModifyListener(fTextFieldListener);

        return textControl;
    }

    protected final int convertHeightInCharsToPixels(Control control,
        int chars) {
        GC gc = new GC(control);
        gc.setFont(control.getFont());
        FontMetrics fontMetrics = gc.getFontMetrics();
        gc.dispose();
        if (fontMetrics == null) {
            return 0;
        }
        return Dialog.convertHeightInCharsToPixels(fontMetrics, chars);
    }

    protected final int convertWidthInCharsToPixels(Control control,
        int chars) {
        GC gc = new GC(control);
        gc.setFont(control.getFont());
        FontMetrics fontMetrics = gc.getFontMetrics();
        gc.dispose();
        if (fontMetrics == null) {
            return 0;
        }
        return Dialog.convertWidthInCharsToPixels(fontMetrics, chars);
    }

    protected final Control getLabel(Control field) {
        return (Control) fLabels.get(field);
    }

    protected final IPreferenceStore getPreferenceStore() {
        return fPreferenceStore;
    }

    // Private Methods ---------------------------------------------------------

    private Text addStringField(Composite composite, String label,
        int textLimit, int indentation) {

        Label labelControl = new Label(composite, SWT.NONE);
        labelControl.setText(label);
        GridData gd = new GridData(GridData.HORIZONTAL_ALIGN_BEGINNING);
        gd.horizontalIndent = indentation;
        labelControl.setLayoutData(gd);

        Text textControl = new Text(composite, SWT.BORDER | SWT.SINGLE);
        gd = new GridData(GridData.HORIZONTAL_ALIGN_BEGINNING);
        gd.widthHint = convertWidthInCharsToPixels(textControl, textLimit + 1);
        textControl.setLayoutData(gd);
        textControl.setTextLimit(textLimit);

        fLabels.put(textControl, labelControl);

        return textControl;
    }

}
