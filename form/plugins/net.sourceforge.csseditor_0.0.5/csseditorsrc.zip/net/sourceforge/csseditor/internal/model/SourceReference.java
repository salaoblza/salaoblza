/*
 * Copyright (c) 2003 Christopher Lenz and others.
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 * 
 * Contributors:
 *     Christopher Lenz - initial API and implementation
 * 
 * $Id: SourceReference.java,v 1.3 2004/01/13 13:54:05 cell Exp $
 */

package net.sourceforge.csseditor.internal.model;

import org.eclipse.jface.text.BadLocationException;
import org.eclipse.jface.text.IDocument;
import org.eclipse.jface.text.IRegion;
import org.eclipse.jface.text.Region;

import net.sourceforge.csseditor.model.ISourceReference;

/**
 * 
 */
public class SourceReference implements ISourceReference {

    // Instance Variables ------------------------------------------------------

    /**
     * The associated document.
     */
    private IDocument document;

    /**
     * The region in the document that maps to the source reference.
     */
    private IRegion sourceRegion;

    // Constructors ------------------------------------------------------------

    /**
     * Constructor.
     * 
     * @param document The document that contains the source reference
     */
    public SourceReference(IDocument document) {
        this.document = document;
    }

    // ISourceReference Implementation -----------------------------------------

    /**
     * @see ISourceReference#getSource()
     */
    public String getSource() {
        try {
            return document.get(sourceRegion.getOffset(),
                sourceRegion.getLength());
        } catch (BadLocationException e) {
            throw new IllegalStateException(
                "Model not synchronized with document"); //$NON-NLS-1$
        }
    }

    /**
     * @see ISourceReference#getSourceRegion()
     */
    public IRegion getSourceRegion() {
        return sourceRegion;
    }

    // Public Methods ----------------------------------------------------------

    public final void setSourceRegion(IRegion region) {
        sourceRegion = new Region(region.getOffset(), region.getLength());
    }

    // Protected Methods -------------------------------------------------------

    protected final IDocument getDocument() {
        return document;
    }

}
