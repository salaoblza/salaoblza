/*
 * Copyright (c) 2003 Christopher Lenz and others.
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 * 
 * Contributors:
 *     Christopher Lenz - initial API and implementation
 * 
 * $Id: CssPartitionScanner.java,v 1.3 2004/06/25 09:55:53 cell Exp $
 */

package net.sourceforge.csseditor.internal.text;

import java.util.ArrayList;
import java.util.List;

import org.eclipse.jface.text.rules.IPredicateRule;
import org.eclipse.jface.text.rules.IToken;
import org.eclipse.jface.text.rules.MultiLineRule;
import org.eclipse.jface.text.rules.RuleBasedPartitionScanner;
import org.eclipse.jface.text.rules.SingleLineRule;
import org.eclipse.jface.text.rules.Token;

/**
 * 
 */
public class CssPartitionScanner extends RuleBasedPartitionScanner {

    // Constants ---------------------------------------------------------------

    public static final String CSS_COMMENT =
        "__css_comment_partition_content_type"; //$NON-NLS-1$

    public static final String CSS_STRING =
        "__css_string_partition_content_type"; //$NON-NLS-1$

    // Constructors ------------------------------------------------------------

    /**
     * Constructor.
     */
    public CssPartitionScanner() {

        IToken commentToken = new Token(CSS_COMMENT);
        IToken stringToken = new Token(CSS_STRING);

        List rules = new ArrayList();

        rules.add(new MultiLineRule(
            "/*", "*/", commentToken)); //$NON-NLS-1$ //$NON-NLS-2$

        rules.add(new SingleLineRule("\"", "\"", //$NON-NLS-1$ //$NON-NLS-2$
                stringToken, '\\', false, true));
        rules.add(new SingleLineRule("'", "'", //$NON-NLS-1$ //$NON-NLS-2$
                stringToken, '\\', false, true));

        setPredicateRules((IPredicateRule[])
            rules.toArray(new IPredicateRule[rules.size()]));
    }

}
