/*
 * Copyright (c) 2003 Christopher Lenz and others.
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 * 
 * Contributors:
 *     Christopher Lenz - initial API and implementation
 * 
 * $Id: ProfileManager.java,v 1.2 2003/12/27 18:46:55 cell Exp $
 */

package net.sourceforge.csseditor.internal;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.WeakHashMap;

import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IConfigurationElement;
import org.eclipse.core.runtime.IExtension;
import org.eclipse.core.runtime.IExtensionPoint;
import org.eclipse.core.runtime.IPluginRegistry;
import org.eclipse.core.runtime.Platform;
import org.eclipse.core.runtime.QualifiedName;
import org.eclipse.jface.preference.IPreferenceStore;

import net.sourceforge.csseditor.CssEditorPlugin;
import net.sourceforge.csseditor.IProfile;
import net.sourceforge.csseditor.IProfileDescriptor;
import net.sourceforge.csseditor.IProfileManager;

/**
 * Implementation of the <code>IProfileManager</code> interface.
 * 
 * TODO Store the profile as core preference, not as JFace preference.
 */
public class ProfileManager implements IProfileManager {

    // Constants ---------------------------------------------------------------

    /**
     * The qualified name used to persist the selected profile on projects and
     * resources.
     */
    public static final QualifiedName PROFILE_PROPERTY = new QualifiedName(
        CssEditorPlugin.getPluginId(), "profile"); //$NON-NLS-1$

    // Instance Variables ------------------------------------------------------

    /**
     * The preferences store.
     */
    private IPreferenceStore store;

    /**
     * The profile descriptors, keyed by extension ID.
     */
    private Map profileDescriptors;

    /**
     * Cache of the already loaded profiles.
     */
    private Map profiles = new WeakHashMap();

    // Constructors ------------------------------------------------------------

    /**
     * Constructor.
     * 
     * @param store the preference store
     */
    public ProfileManager(IPreferenceStore store) {
        this.store = store;
    }

    // IProfileManager Implementation ------------------------------------------

    /**
     * @see IProfileManager#getProfileDescriptors()
     */
    public IProfileDescriptor[] getProfileDescriptors() {
        if (profileDescriptors == null) {
            loadProfileExtensions();
        }
        List retVal = new ArrayList();
        retVal.addAll(profileDescriptors.values());
        return (IProfileDescriptor[]) retVal.toArray(
            new IProfileDescriptor[retVal.size()]);
    }

    /**
     * @see IProfileManager#getProfile(IResource)
     */
    public IProfile getProfile(IResource resource) {
        String profileId = null;
        if (resource != null) {
            try {
                profileId = resource.getPersistentProperty(PROFILE_PROPERTY);
            } catch (CoreException e) {
                CssEditorPlugin.log(
                    "Failed to get profile for resource", e); //$NON-NLS-1$
            }
            if (profileId == null) {
                IProject project = resource.getProject();
                try {
                    profileId = project.getPersistentProperty(PROFILE_PROPERTY);
                } catch (CoreException e) {
                    CssEditorPlugin.log(
                        "Failed to get profile for project", e); //$NON-NLS-1$
                }
            }
        }
        if (profileId == null) {
            profileId = store.getString(CssEditorPreferences.PROFILE);
        }
        IProfile profile = getProfile(profileId);
        return profile;
    }

    /**
     * @see IProfileManager#setProfile(IResource, String)
     */
    public void setProfile(IResource resource, String profileId) {
        if (resource != null) {
            try {
                resource.setPersistentProperty(
                    ProfileManager.PROFILE_PROPERTY, profileId);
            } catch (CoreException e) {
                CssEditorPlugin.log(
                    "Cannot store profile as resource property", //$NON-NLS-1$
                    e);
            }
        } else if (profileId != null) {
            store.setValue(CssEditorPreferences.PROFILE, profileId);
        } else {
            store.setToDefault(CssEditorPreferences.PROFILE);
        }
    }

    // Private Methods ---------------------------------------------------------

    /**
     * Returns the profile associated with the specified extension ID. The
     * profile is instantiated if not already in the cache.
     * 
     * @param profileId the ID of the extension implementing the profile
     */
    private IProfile getProfile(String profileId) {
        IProfile profile = (IProfile) profiles.get(profileId);
        if (profile == null) {
            IProfileDescriptor descriptor = getProfileDescriptor(profileId);
            if (descriptor == null) {
                CssEditorPlugin.log("Profile '" + profileId + //$NON-NLS-1$
                    "' not found."); //$NON-NLS-1$
                descriptor = getDefaultProfileDescriptor();
            }
            if (descriptor != null) {
                profile = instantiateProfile(descriptor);
                profiles.put(profileId, profile);
            }
        }
        return profile;
    }

    /**
     * Returns the descriptor of the default profile.
     * 
     * @return the descriptor of the default profile
     */
    private IProfileDescriptor getDefaultProfileDescriptor() {
        String profileId = store.getDefaultString(CssEditorPreferences.PROFILE);
        return getProfileDescriptor(profileId);
    }

    /**
     * Returns the descriptor of the specified profile.
     * 
     * @param profileId the ID of the profile
     * @return the descriptor of the profile with the given ID
     */
    private IProfileDescriptor getProfileDescriptor(String profileId) {
        if (profileDescriptors == null) {
            loadProfileExtensions();
        }
        return (IProfileDescriptor) profileDescriptors.get(profileId);
    }

    /**
     * Instantiates and the returns the profile.
     * 
     * @param descriptor the profile descriptor
     * @return the instantiated profile, or <code>null</code> if there was a 
     *         problem instantiating the profile
     */
    private IProfile instantiateProfile(IProfileDescriptor descriptor) {
        try {
            Class clazz = Class.forName(descriptor.getClassName());
            Constructor ctor = clazz.getConstructor(
                new Class[] { IProfileDescriptor.class });
            return (IProfile) ctor.newInstance(new Object[] { descriptor });
        } catch (ClassNotFoundException e) {
            CssEditorPlugin.log("Failed to get CSS profile", e); //$NON-NLS-1$
        } catch (IllegalAccessException e) {
            CssEditorPlugin.log("Failed to get CSS profile", e); //$NON-NLS-1$
        } catch (InvocationTargetException e) {
            CssEditorPlugin.log("Failed to get CSS profile", e); //$NON-NLS-1$
        } catch (InstantiationException e) {
            CssEditorPlugin.log("Failed to get CSS profile", e); //$NON-NLS-1$
        } catch (NoSuchMethodException e) {
            CssEditorPlugin.log("Failed to get CSS profile", e); //$NON-NLS-1$
        }
        return null;
    }

    /**
     * Initializes the list of available profiles by querying the platform for
     * extensions of the <em>profiles</em> extension point and storing an
     * <code>IProfileDescriptor</code> for each extension found.
     */
    private void loadProfileExtensions() {
        profileDescriptors = new HashMap();
        IPluginRegistry registry = Platform.getPluginRegistry();
        IExtensionPoint extensionPoint = registry.getExtensionPoint(
            IProfileDescriptor.EXTENSION_POINT_ID);
        IExtension[] extensions = extensionPoint.getExtensions();
        for (int i = 0; i < extensions.length; i++) {
            IExtension extension = extensions[i];
            IConfigurationElement[] elements =
                extension.getConfigurationElements();
            for (int j = 0; j < elements.length; j++) {
                IConfigurationElement element = elements[j];
                IProfileDescriptor descriptor = new ProfileDescriptor(element);
                profileDescriptors.put(descriptor.getId(), descriptor);
            }
        }
    }

}
