/*
 * Copyright (c) 2003 Christopher Lenz and others.
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 * 
 * Contributors:
 *     Christopher Lenz - initial API and implementation
 * 
 * $Id: CssEditorAnnotationsConfigurationBlock.java,v 1.2 2003/12/27 18:46:56 cell Exp $
 */

package net.sourceforge.csseditor.internal.preferences;

import java.util.ArrayList;
import java.util.Iterator;

import org.eclipse.jface.preference.ColorSelector;
import org.eclipse.jface.preference.IPreferenceStore;
import org.eclipse.jface.preference.PreferenceConverter;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.graphics.RGB;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.List;
import org.eclipse.ui.texteditor.AnnotationPreference;
import org.eclipse.ui.texteditor.MarkerAnnotationPreferences;

import net.sourceforge.csseditor.internal.CssEditorMessages;

/**
 * 
 */
final class CssEditorAnnotationsConfigurationBlock
    extends AbstractConfigurationBlock {

    // Instance Variables ------------------------------------------------------

    private List fColorList;
    private String[][] fColorListModel;
    private ColorSelector fColorSelector;
    private Button fShowInTextCheckBox;
    private Button fShowInOverviewRulerCheckBox;

    // Constructors ------------------------------------------------------------

    public CssEditorAnnotationsConfigurationBlock(IPreferenceStore store) {
        super(store);
        MarkerAnnotationPreferences preferences =
            new MarkerAnnotationPreferences();
        fColorListModel = createAnnotationTypeListModel(preferences);
    }

    // Public Methods ----------------------------------------------------------

    public Control createControl(Composite parent) {

        Composite composite = new Composite(parent, SWT.NONE);
        GridLayout layout = new GridLayout();
        layout.numColumns = 2;
        composite.setLayout(layout);

        Label label = new Label(composite, SWT.LEFT);
        label.setText(getString("presentationOptions")); //$NON-NLS-1$
        GridData gridData = new GridData(GridData.HORIZONTAL_ALIGN_FILL);
        gridData.horizontalSpan = 2;
        label.setLayoutData(gridData);

        Composite editorComposite = new Composite(composite, SWT.NONE);
        layout = new GridLayout();
        layout.numColumns = 2;
        layout.marginHeight = 0;
        layout.marginWidth = 0;
        editorComposite.setLayout(layout);
        gridData = new GridData(
            GridData.HORIZONTAL_ALIGN_FILL | GridData.FILL_VERTICAL);
        gridData.horizontalSpan = 2;
        editorComposite.setLayoutData(gridData);      

        fColorList = new List(editorComposite,
            SWT.SINGLE | SWT.V_SCROLL | SWT.BORDER);
        gridData = new GridData(
            GridData.VERTICAL_ALIGN_BEGINNING | GridData.FILL_HORIZONTAL);
        gridData.heightHint = convertHeightInCharsToPixels(composite, 8);
        fColorList.setLayoutData(gridData);
        fColorList.addSelectionListener(new SelectionListener() {
            public void widgetDefaultSelected(SelectionEvent e) { }
            public void widgetSelected(SelectionEvent e) {
                handleAnnotationColorListSelection();
            }
        });

        Composite optionsComposite = new Composite(editorComposite, SWT.NONE);
        layout = new GridLayout();
        layout.marginHeight = 0;
        layout.marginWidth = 0;
        layout.numColumns = 2;
        optionsComposite.setLayout(layout);
        optionsComposite.setLayoutData(new GridData(GridData.FILL_BOTH));
        
        fShowInTextCheckBox = new Button(optionsComposite, SWT.CHECK);
        fShowInTextCheckBox.setText(getString(
            "showInText")); //$NON-NLS-1$
        gridData = new GridData(GridData.FILL_HORIZONTAL);
        gridData.horizontalAlignment = GridData.BEGINNING;
        gridData.horizontalSpan = 2;
        fShowInTextCheckBox.setLayoutData(gridData);
        fShowInTextCheckBox.addSelectionListener(new SelectionListener() {
            public void widgetDefaultSelected(SelectionEvent e) { }
            public void widgetSelected(SelectionEvent e) {
                int i = fColorList.getSelectionIndex();
                String key = fColorListModel[i][2];
                getPreferenceStore().setValue(key,
                    fShowInTextCheckBox.getSelection());
            }
        });
        
        fShowInOverviewRulerCheckBox = new Button(optionsComposite, SWT.CHECK);
        fShowInOverviewRulerCheckBox.setText(getString(
            "showInOverviewRuler")); //$NON-NLS-1$
        gridData = new GridData(GridData.FILL_HORIZONTAL);
        gridData.horizontalAlignment = GridData.BEGINNING;
        gridData.horizontalSpan = 2;
        fShowInOverviewRulerCheckBox.setLayoutData(gridData);
        fShowInOverviewRulerCheckBox.addSelectionListener(
            new SelectionListener() {
                public void widgetDefaultSelected(SelectionEvent e) { }
                public void widgetSelected(SelectionEvent e) {
                    int i = fColorList.getSelectionIndex();
                    String key = fColorListModel[i][3];
                    getPreferenceStore().setValue(key,
                        fShowInOverviewRulerCheckBox.getSelection());
                }
            });
        
        label = new Label(optionsComposite, SWT.LEFT);
        label.setText(getString("color")); //$NON-NLS-1$
        gridData = new GridData();
        gridData.horizontalAlignment = GridData.BEGINNING;
        label.setLayoutData(gridData);

        fColorSelector = new ColorSelector(optionsComposite);
        Button foregroundColorButton = fColorSelector.getButton();
        gridData = new GridData(GridData.FILL_HORIZONTAL);
        gridData.horizontalAlignment = GridData.BEGINNING;
        foregroundColorButton.setLayoutData(gridData);
        foregroundColorButton.addSelectionListener(new SelectionListener() {
            public void widgetDefaultSelected(SelectionEvent e) { }
            public void widgetSelected(SelectionEvent e) {
                int i = fColorList.getSelectionIndex();
                String key = fColorListModel[i][1];
                PreferenceConverter.setValue(getPreferenceStore(), key,
                    fColorSelector.getColorValue());
            }
        });

        initialize();

        return composite;
    }

    // Event Handlers ----------------------------------------------------------

    void handleAnnotationColorListSelection() {
        int i = fColorList.getSelectionIndex();
        String key = fColorListModel[i][1];
        RGB rgb = PreferenceConverter.getColor(getPreferenceStore(), key);
        fColorSelector.setColorValue(rgb);
        key = fColorListModel[i][2];
        fShowInTextCheckBox.setSelection(getPreferenceStore().getBoolean(key));
        key = fColorListModel[i][3];
        fShowInOverviewRulerCheckBox.setSelection(
            getPreferenceStore().getBoolean(key));               
    }
    
    // Private Methods ---------------------------------------------------------

    private String[][] createAnnotationTypeListModel(
        MarkerAnnotationPreferences preferences) {
        
        ArrayList listModelItems = new ArrayList();
        Iterator i = preferences.getAnnotationPreferences().iterator();
        while (i.hasNext()) {
            AnnotationPreference info = (AnnotationPreference) i.next();
            /*
             * string info.getPreferenceLabel() can be null, if none is set by the annotation
             * but a valid string is required to show it in the list in the annotation preference tab
             * so check !=null is reuqired
             */ 
            if (info.getPreferenceLabel()!=null) {
	            listModelItems.add(new String[] {
	                info.getPreferenceLabel(),
	                info.getColorPreferenceKey(),
	                info.getTextPreferenceKey(),
	                info.getOverviewRulerPreferenceKey()
	            });
            }
        }

        String[][] listModel = new String[listModelItems.size()][];
        listModelItems.toArray(listModel);
        return listModel;
    }

    private static String getString(String key) {
        return CssEditorMessages.getString(
            "CssEditorPreferencePage.annotations." + key); //$NON-NLS-1$
    }

    private void initialize() {
        for (int i = 0; i < fColorListModel.length; i++) {
            fColorList.add(fColorListModel[i][0]);
        }
        fColorList.getDisplay().asyncExec(new Runnable() {
            public void run() {
                if ((fColorList != null)
                 && !fColorList.isDisposed()) {
                    fColorList.select(0);
                    handleAnnotationColorListSelection();
                }
            }
        });
        initializeFields();
    }

}
