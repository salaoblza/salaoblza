/*
 * Copyright (c) 2003 Christopher Lenz and others.
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 * 
 * Contributors:
 *     Christopher Lenz - initial API and implementation
 * 
 * $Id: CssPairMatcher.java,v 1.5 2003/12/28 20:00:46 cell Exp $
 */

package net.sourceforge.csseditor.internal.text;

import org.eclipse.jface.text.BadLocationException;
import org.eclipse.jface.text.IDocument;
import org.eclipse.jface.text.IRegion;
import org.eclipse.jface.text.Region;
import org.eclipse.jface.text.source.ICharacterPairMatcher;
import org.eclipse.jface.util.Assert;

import net.sourceforge.csseditor.internal.CssTextUtils;

/**
 * 
 */
public class CssPairMatcher implements ICharacterPairMatcher {

    // Constants ---------------------------------------------------------------

    private static final char PAIRS[] = {
        '{', '}', '(', ')', '[', ']'
    };

    // Instance Variables ------------------------------------------------------

    private IDocument document;

    private int offset;

    private int anchor;
   
    // ICharacterPairMatcher Implementation ------------------------------------

    /*
     * @see ICharacterPairMatcher#clear
     */
    public void clear() {
        document = null;
        offset = -1;
        anchor = 0;
    }

    /*
     * @see ICharacterPairMatcher#dispose
     */
    public void dispose() {
        document = null;
    }

    /*
     * @see ICharacterPairMatcher#match
     */
    public IRegion match(IDocument document, int offset) {
        Assert.isNotNull(document);
        Assert.isLegal(offset >= 0);
        this.document = document;
        this.offset = offset;

        IRegion retVal = null;
        try {
        	retVal = matchPairsAt();
        } catch (BadLocationException e) {
        	// ignore, there's probably no matching character to highlight
        }
        return retVal;
    }

    /*
     * @see ICharacterPairMatcher#getAnchor
     */
    public int getAnchor() {
        return anchor;
    }

    // Private Methods ---------------------------------------------------------

    private boolean isClosingCharacter(char ch) {
        for (int i = 1; i < PAIRS.length; i += 2) {
            if (ch == PAIRS[i]) {
                return true;
            }
        }
        return false;
    }

    private boolean isOpeningCharacter(char ch) {
        for (int i = 0; i < PAIRS.length; i += 2) {
            if (ch == PAIRS[i]) {
                return true;
            }
        }
        return false;
    }

    private IRegion matchPairsAt() throws BadLocationException {
        int startPos = -1, endPos = -1;
        char prevChar = document.getChar(Math.max(offset - 1, 0));
        if (isOpeningCharacter(prevChar)) {
            startPos = offset - 1;
            if (startPos >= 0) {
                anchor = LEFT;
                endPos = CssTextUtils.findMatchingClosingPeer(
                    document, startPos + 1, prevChar);
                if (endPos > -1) {
                    return new Region(startPos, endPos - startPos + 1);
                }
            }
        }
        if (isClosingCharacter(prevChar)) {
            endPos = offset - 1;
            if (endPos >= 0) {
                anchor = RIGHT;
                startPos = CssTextUtils.findMatchingOpeningPeer(
                    document, endPos - 1, prevChar);
                if (startPos > -1) {
                    return new Region(startPos, endPos - startPos + 1);
                }
            }
        } 
        return null;
    }

}
