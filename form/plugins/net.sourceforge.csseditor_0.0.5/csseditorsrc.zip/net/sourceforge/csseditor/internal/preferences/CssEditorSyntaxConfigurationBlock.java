/*
 * Copyright (c) 2003 Christopher Lenz and others.
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 * 
 * Contributors:
 *     Christopher Lenz - initial API and implementation
 * 
 * $Id: CssEditorSyntaxConfigurationBlock.java,v 1.2 2003/12/27 18:46:56 cell Exp $
 */

package net.sourceforge.csseditor.internal.preferences;

import org.eclipse.jface.preference.ColorSelector;
import org.eclipse.jface.preference.IPreferenceStore;
import org.eclipse.jface.preference.PreferenceConverter;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.graphics.RGB;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.layout.RowLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.List;

import net.sourceforge.csseditor.internal.CssEditorMessages;
import net.sourceforge.csseditor.internal.CssEditorPreferences;

/**
 * 
 */
final class CssEditorSyntaxConfigurationBlock
    extends AbstractConfigurationBlock {

    // Instance Variables ------------------------------------------------------

    private Button fBackgroundDefaultRadioButton;
    private Button fBackgroundCustomRadioButton;
    private ColorSelector fBackgroundColorSelector;
    private List fColorList;
    private final String[][] fColorListModel = new String[][] {
        { getString("commentColor"), //$NON-NLS-1$
          CssEditorPreferences.EDITOR_COMMENT_COLOR,
          CssEditorPreferences.EDITOR_COMMENT_BOLD },
        { getString("stringColor"), //$NON-NLS-1$
          CssEditorPreferences.EDITOR_STRING_COLOR,
          CssEditorPreferences.EDITOR_STRING_BOLD },
        { getString("propertyNameColor"), //$NON-NLS-1$
          CssEditorPreferences.EDITOR_PROPERTY_COLOR,
          CssEditorPreferences.EDITOR_PROPERTY_BOLD },
        { getString("atKeywordColor"), //$NON-NLS-1$
          CssEditorPreferences.EDITOR_AT_KEYWORD_COLOR,
          CssEditorPreferences.EDITOR_AT_KEYWORD_BOLD },
        { getString("pseudoClassColor"), //$NON-NLS-1$
          CssEditorPreferences.EDITOR_PSEUDO_CLASS_COLOR,
          CssEditorPreferences.EDITOR_PSEUDO_CLASS_BOLD },
        { getString("defaultColor"), //$NON-NLS-1$
          CssEditorPreferences.EDITOR_DEFAULT_COLOR,
          CssEditorPreferences.EDITOR_DEFAULT_BOLD },
    };
    private ColorSelector fColorSelector;
    private Button fBoldCheckbox;

    // Constructors ------------------------------------------------------------

    public CssEditorSyntaxConfigurationBlock(IPreferenceStore store) {
        super(store);
    }

    // Public Methods ----------------------------------------------------------

    public Control createControl(Composite parent) {

        Composite composite = new Composite(parent, SWT.NONE);
        composite.setLayout(new GridLayout());

        Group backgroundComposite = new Group(composite, SWT.SHADOW_ETCHED_IN);
        backgroundComposite.setLayout(new RowLayout());
        backgroundComposite.setText(getString("backgroundColor")); //$NON-NLS-1$
        SelectionListener backgroundSelectionListener =
            new SelectionListener() {
                public void widgetSelected(SelectionEvent e) {              
                    boolean custom =
                        fBackgroundCustomRadioButton.getSelection();
                    fBackgroundColorSelector.setEnabled(custom);
                    getPreferenceStore().setValue(
                        CssEditorPreferences.EDITOR_BACKGROUND_DEFAULT_COLOR,
                        !custom);
                }
                public void widgetDefaultSelected(SelectionEvent e) { }
            };
        fBackgroundDefaultRadioButton = new Button(backgroundComposite,
            SWT.RADIO | SWT.LEFT);
        fBackgroundDefaultRadioButton.setText(getString(
            "backgroundColorSystemDefault")); //$NON-NLS-1$
        fBackgroundDefaultRadioButton.addSelectionListener(
            backgroundSelectionListener);
        fBackgroundCustomRadioButton = new Button(backgroundComposite,
            SWT.RADIO | SWT.LEFT);
        fBackgroundCustomRadioButton.setText(getString(
            "backgroundColorCustom")); //$NON-NLS-1$
        fBackgroundCustomRadioButton.addSelectionListener(
            backgroundSelectionListener);

        fBackgroundColorSelector = new ColorSelector(backgroundComposite);
        Button backgroundColorButton = fBackgroundColorSelector.getButton();
        backgroundColorButton.addSelectionListener(new SelectionListener() {
            public void widgetDefaultSelected(SelectionEvent e) { }
            public void widgetSelected(SelectionEvent e) {
                PreferenceConverter.setValue(getPreferenceStore(),
                    CssEditorPreferences.EDITOR_BACKGROUND_COLOR,
                    fBackgroundColorSelector.getColorValue());
            }
        });

        Label label = new Label(composite, SWT.LEFT);
        label.setText(getString("foregroundColor")); //$NON-NLS-1$
        label.setLayoutData(new GridData(GridData.FILL_HORIZONTAL));

        Composite editorComposite = new Composite(composite, SWT.NONE);
        GridLayout layout = new GridLayout();
        layout.numColumns = 2;
        layout.marginHeight = 0;
        layout.marginWidth = 0;
        editorComposite.setLayout(layout);
        GridData gridData = new GridData(GridData.FILL_BOTH);
        editorComposite.setLayoutData(gridData);      

        fColorList = new List(editorComposite,
            SWT.SINGLE | SWT.V_SCROLL | SWT.BORDER);
        gridData = new GridData(GridData.FILL_BOTH);
        gridData.heightHint = convertHeightInCharsToPixels(composite, 5);
        fColorList.setLayoutData(gridData);
        fColorList.addSelectionListener(new SelectionListener() {
            public void widgetDefaultSelected(SelectionEvent e) {
            }
            public void widgetSelected(SelectionEvent e) {
                handleSyntaxColorListSelection();
            }
        });

        Composite stylesComposite = new Composite(editorComposite, SWT.NONE);
        layout = new GridLayout();
        layout.marginHeight = 0;
        layout.marginWidth = 0;
        layout.numColumns = 2;
        stylesComposite.setLayout(layout);
        stylesComposite.setLayoutData(new GridData(GridData.FILL_BOTH));
        
        label = new Label(stylesComposite, SWT.LEFT);
        label.setText(getString("color")); //$NON-NLS-1$
        gridData = new GridData();
        gridData.horizontalAlignment = GridData.BEGINNING;
        label.setLayoutData(gridData);

        fColorSelector = new ColorSelector(stylesComposite);
        Button foregroundColorButton = fColorSelector.getButton();
        gridData = new GridData(GridData.FILL_HORIZONTAL);
        gridData.horizontalAlignment = GridData.BEGINNING;
        foregroundColorButton.setLayoutData(gridData);
        foregroundColorButton.addSelectionListener(new SelectionListener() {
            public void widgetDefaultSelected(SelectionEvent e) { }
            public void widgetSelected(SelectionEvent e) {
                int i = fColorList.getSelectionIndex();
                String key = fColorListModel[i][1];
                PreferenceConverter.setValue(getPreferenceStore(), key,
                    fColorSelector.getColorValue());
            }
        });
        
        fBoldCheckbox = new Button(stylesComposite, SWT.CHECK);
        fBoldCheckbox.setText(getString("bold")); //$NON-NLS-1$
        gridData = new GridData(GridData.FILL_HORIZONTAL);
        gridData.horizontalAlignment = GridData.BEGINNING;
        gridData.horizontalSpan = 2;
        fBoldCheckbox.setLayoutData(gridData);
        fBoldCheckbox.addSelectionListener(new SelectionListener() {
            public void widgetDefaultSelected(SelectionEvent e) { }
            public void widgetSelected(SelectionEvent e) {
                int i = fColorList.getSelectionIndex();
                String key = fColorListModel[i][2];
                getPreferenceStore().setValue(key,
                    fBoldCheckbox.getSelection());
            }
        });

        Control previewer =
            new SyntaxPreviewer(composite, getPreferenceStore()).getControl();
        gridData = new GridData(GridData.FILL_BOTH);
        gridData.widthHint = convertWidthInCharsToPixels(composite, 20);
        gridData.heightHint = convertHeightInCharsToPixels(composite, 5);
        previewer.setLayoutData(gridData);

        initialize();

        return composite;
    }

    /**
     * @see AbstractConfigurationBlock#initializeFields()
     */
    public void initializeFields() {
        super.initializeFields();
        RGB rgb = PreferenceConverter.getColor(getPreferenceStore(),
            CssEditorPreferences.EDITOR_BACKGROUND_COLOR);
        fBackgroundColorSelector.setColorValue(rgb);
        boolean defaultBackgroud = getPreferenceStore().getBoolean(
            CssEditorPreferences.EDITOR_BACKGROUND_DEFAULT_COLOR);
        fBackgroundDefaultRadioButton.setSelection(defaultBackgroud);
        fBackgroundCustomRadioButton.setSelection(!defaultBackgroud);
        fBackgroundColorSelector.setEnabled(!defaultBackgroud);
    }

    // Event Handlers ----------------------------------------------------------

    void handleSyntaxColorListSelection() {
        int i = fColorList.getSelectionIndex();
        String key = fColorListModel[i][1];
        RGB rgb = PreferenceConverter.getColor(getPreferenceStore(), key);
        fColorSelector.setColorValue(rgb);
        key = fColorListModel[i][2];
        fBoldCheckbox.setSelection(getPreferenceStore().getBoolean(key));
    }

    // Private Methods ---------------------------------------------------------

    private static String getString(String key) {
        return CssEditorMessages.getString(
            "CssEditorPreferencePage.syntax." + key); //$NON-NLS-1$
    }

    private void initialize() {
        for (int i = 0; i < fColorListModel.length; i++) {
            fColorList.add(fColorListModel[i][0]);
        }
        fColorList.getDisplay().asyncExec(new Runnable() {
            public void run() {
                if ((fColorList != null)
                 && !fColorList.isDisposed()) {
                    fColorList.select(0);
                    handleSyntaxColorListSelection();
                }
            }
        });
        initializeFields();
    }

}
