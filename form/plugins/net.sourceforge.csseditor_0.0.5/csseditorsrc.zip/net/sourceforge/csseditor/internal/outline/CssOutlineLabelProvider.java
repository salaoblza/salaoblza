/*
 * Copyright (c) 2003 Christopher Lenz and others.
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 * 
 * Contributors:
 *     Christopher Lenz - initial API and implementation
 * 
 * $Id: CssOutlineLabelProvider.java,v 1.2 2003/12/27 18:46:55 cell Exp $
 */

package net.sourceforge.csseditor.internal.outline;

import org.eclipse.jface.viewers.LabelProvider;
import org.eclipse.swt.graphics.Image;

import net.sourceforge.csseditor.CssEditorPlugin;
import net.sourceforge.csseditor.model.IAtRule;
import net.sourceforge.csseditor.model.ISourceReference;
import net.sourceforge.csseditor.model.IStyleRule;

/**
 * Label provider for the CSS outline page.
 */
public class CssOutlineLabelProvider extends LabelProvider {

    // LabelProvider Implementation --------------------------------------------

    /**
     * @see org.eclipse.jface.viewers.ILabelProvider#getImage(java.lang.Object)
     */
    public Image getImage(Object element) {
        if (element instanceof IStyleRule) {
            return CssEditorPlugin.getDefault().getImageRegistry().get(
                CssEditorPlugin.ICON_STYLE_RULE);
        } else if (element instanceof IAtRule) {
            return CssEditorPlugin.getDefault().getImageRegistry().get(
                CssEditorPlugin.ICON_AT_RULE);
        }
        return null;
    }

    /**
     * @see org.eclipse.jface.viewers.ILabelProvider#getText(java.lang.Object)
     */
    public String getText(Object element) {
        StringBuffer text = new StringBuffer();
        if (element instanceof IStyleRule) {
            IStyleRule rule = (IStyleRule) element;
            ISourceReference selector = rule.getSelector();
            if (selector != null) {
                text.append(selector.getSource());
            }
        } else if (element instanceof IAtRule) {
            IAtRule rule = (IAtRule) element;
            ISourceReference name = rule.getName();
            ISourceReference value = rule.getValue();
            if (name != null) {
                text.append(name.getSource());
                if (value != null) {
                    text.append(' ');
                }
            }
            if (value != null) {
                text.append(value.getSource());
            }
        }
        return normalizeWhitespace(text.toString());
    }

    // Private Methods ---------------------------------------------------------

    /**
     * Replaces all whitespace characters by regular spaces, and trims excessive
     * whitespace down to at most one whitespace between non-whitespace
     * characters.
     * 
     * @param text The text to normalize
     * @return The normalized text
     */
    public String normalizeWhitespace(String text) {
        StringBuffer buf = new StringBuffer();
        boolean previousWasWhitespace = false;
        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i);
            if ((c == 9) || (c == 10) || (c == 13)) { // Tab
                c = ' ';
            }
            if ((c != ' ') || !previousWasWhitespace) {
                buf.append(c);
            }
            previousWasWhitespace = (c == ' ');
        }
        return buf.toString();
    }

}
