/*
 * Copyright (c) 2003 Christopher Lenz and others.
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 * 
 * Contributors:
 *     Christopher Lenz - initial API and implementation
 * 
 * $Id: ProfileDescriptor.java,v 1.2 2003/12/27 18:46:55 cell Exp $
 */

package net.sourceforge.csseditor.internal;

import org.eclipse.core.runtime.IConfigurationElement;

import net.sourceforge.csseditor.IProfileDescriptor;

/**
 * 
 */
public class ProfileDescriptor implements IProfileDescriptor {

    // Constants ---------------------------------------------------------------

    private static final String ATTR_ID = "id"; //$NON-NLS-1$
    private static final String ATTR_NAME = "name"; //$NON-NLS-1$
    private static final String ATTR_CLASS = "class"; //$NON-NLS-1$
    private static final String ATTR_DESCRIPTION = "description"; //$NON-NLS-1$

    // Instance Variables ------------------------------------------------------

    /**
     * The profile ID.
     */
    private String id;

    /**
     * The name of the profile.
     */
    private String name;

    /**
     * The name of the implementation class.
     */
    private String className;

    /**
     * An optional description.
     */
    private String description;

    // Constructors ------------------------------------------------------------

    /**
     * Constructor.
     * 
     * @param element The configuration element corresponding to the declaration
     *        of the profile
     */
    public ProfileDescriptor(IConfigurationElement element) {
        this.id = element.getAttribute(ATTR_ID);
        this.name = element.getAttribute(ATTR_NAME);
        this.className = element.getAttribute(ATTR_CLASS);
        this.description = element.getAttribute(ATTR_DESCRIPTION);
    }

    // IProfileDescriptor Implementation ---------------------------------------

    /**
     * @see IProfileDescriptor#getId()
     */
    public String getId() {
        return id;
    }

    /**
     * @see IProfileDescriptor#getName()
     */
    public String getName() {
        return name;
    }

    /**
     * @see IProfileDescriptor#getDescription()
     */
    public String getDescription() {
        return description;
    }

    /**
     * @see IProfileDescriptor#getProfile()
     */
    public String getClassName() {
        return className;
    }

}
