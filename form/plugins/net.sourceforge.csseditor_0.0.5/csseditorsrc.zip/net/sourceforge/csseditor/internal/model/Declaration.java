/*
 * Copyright (c) 2003 Christopher Lenz and others.
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 * 
 * Contributors:
 *     Christopher Lenz - initial API and implementation
 * 
 * $Id: Declaration.java,v 1.3 2004/01/13 13:54:05 cell Exp $
 */

package net.sourceforge.csseditor.internal.model;

import org.eclipse.jface.text.IDocument;

import net.sourceforge.csseditor.model.IDeclaration;
import net.sourceforge.csseditor.model.IRule;
import net.sourceforge.csseditor.model.ISourceReference;

/**
 * 
 */
public class Declaration extends SourceReference
    implements IDeclaration {

    // Instance Variables ------------------------------------------------------

    /**
     * The rule that contains this declaration.
     */
    private IRule rule;

    /**
     * The part of the declaration that contains the property name.
     */
    private ISourceReference property;

    /**
     * The value part of the declaration.
     */
    private ISourceReference value;

    /**
     * The priority part of the declaration.
     */
    private ISourceReference priority;

    // Constructors ------------------------------------------------------------

    /**
     * Constructor.
     * 
     * @param document the document that contains the property
     * @param rule the rule that contains this property, or <code>null</code> if
     *        the declaration does not belong to a specific rule 
     */
    public Declaration(IDocument document, IRule rule) {
        super(document);
        this.rule = rule;
    }

    // IProperty Implementation ------------------------------------------------

    /*
     * @see IDeclaration#getRule()
     */
    public final IRule getRule() {
        return rule;
    }

    /*
     * @see IDeclaration#getProperty()
     */
    public final ISourceReference getProperty() {
        return property;
    }

    /*
     * @see IDeclaration#getValue()
     */
    public final ISourceReference getValue() {
        return value;
    }

    /*
     * @see IDeclaration#getPriority()
     */
    public final ISourceReference getPriority() {
        return priority;
    }

    // Instance Variables ------------------------------------------------------

    /**
     * Sets the property.
     * 
     * @param property The property to set
     */
    public final void setProperty(ISourceReference property) {
        this.property = property;
    }

    /**
     * Sets the value.
     * 
     * @param value The value to set
     */
    public final void setValue(ISourceReference value) {
        this.value = value;
    }

    /**
     * Sets the priority.
     * 
     * @param priority The priority to set
     */
    public final void setPriority(ISourceReference priority) {
        this.priority = priority;
    }

}
