/*
 * Copyright (c) 2003 Christopher Lenz and others.
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 * 
 * Contributors:
 *     Christopher Lenz - initial API and implementation
 * 
 * $Id: CssOutlinePage.java,v 1.4 2004/01/13 17:03:49 cell Exp $
 */

package net.sourceforge.csseditor.internal.outline;

import java.util.List;

import org.eclipse.jface.action.IMenuManager;
import org.eclipse.jface.action.IStatusLineManager;
import org.eclipse.jface.action.IToolBarManager;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.viewers.StructuredSelection;
import org.eclipse.jface.viewers.TreeViewer;
import org.eclipse.jface.viewers.ViewerSorter;
import org.eclipse.swt.custom.BusyIndicator;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.ui.IActionBars;
import org.eclipse.ui.part.IPageSite;
import org.eclipse.ui.texteditor.IDocumentProvider;
import org.eclipse.ui.texteditor.ITextEditorActionDefinitionIds;
import org.eclipse.ui.texteditor.ResourceAction;
import org.eclipse.ui.views.contentoutline.ContentOutlinePage;

import net.sourceforge.csseditor.CssEditorPlugin;
import net.sourceforge.csseditor.internal.CssDocumentProvider;
import net.sourceforge.csseditor.internal.CssEditorMessages;
import net.sourceforge.csseditor.internal.CssEditorPreferences;
import net.sourceforge.csseditor.internal.editor.CssEditor;
import net.sourceforge.csseditor.internal.editor.ShowSelectedElementOnlyAction;
import net.sourceforge.csseditor.model.IAtRule;
import net.sourceforge.csseditor.model.ISourceReference;
import net.sourceforge.csseditor.model.IStyleSheet;

/**
 * Implements the outline page associated with the CSS editor.
 */
public class CssOutlinePage extends ContentOutlinePage {

    // Inner Classes -----------------------------------------------------------

    /**
     * Action that activates or deactivates the lexical sorting of elements in
     * the outline tree viewer.
     */
    private class ToggleLexicalSortingAction extends ResourceAction {

        // Constants -----------------------------------------------------------

        private static final int CATEGORY_AT_RULE = 0;
        private static final int CATEGORY_STYLE_RULE = 1;

        // Instance Variables --------------------------------------------------

        /**
         * The viewer sorter. At-rules are displayed before style rules,
         * otherwise the default lexical sorting applies.
         */
        private final ViewerSorter sorter = new ViewerSorter() {
            public int category(Object element) {
                if (element instanceof IAtRule) {
                    return CATEGORY_AT_RULE;
                } else {
                    return CATEGORY_STYLE_RULE;
                }
            }
        };

        // Constructors --------------------------------------------------------

        /**
         * Constructor.
         */
        public ToggleLexicalSortingAction() {
            super(CssEditorMessages.getResourceBundle(),
                "CssOutlinePage.sort."); //$NON-NLS-1$
            CssEditorPlugin plugin = CssEditorPlugin.getDefault();
            boolean checked = plugin.getPreferenceStore().getBoolean(
                CssEditorPreferences.OUTLINE_SORT_LEXICALLY); //$NON-NLS-1$
            valueChanged(checked, false);
        }

        // Action Implementation -----------------------------------------------

        /*
         * @see org.eclipse.jface.action.Action#run()
         */
        public void run() {
            valueChanged(isChecked(), true);
        }

        // Private Methods -----------------------------------------------------

        /**
         * Updates the sorting of the outline.
         * 
         * @param checked Whether lexical sorting is enabled
         * @param store Whether the new state should be written back as a 
         *        preference
         */
        private void valueChanged(final boolean checked, boolean store) {
            setChecked(checked);
            BusyIndicator.showWhile(getTreeViewer().getControl().getDisplay(),
                new Runnable() {
                    public void run() {
                        getTreeViewer().setSorter(checked ? sorter : null);
                    }
                });
            if (store) {
                CssEditorPlugin plugin = CssEditorPlugin.getDefault();
                plugin.getPreferenceStore().setValue(
                    CssEditorPreferences.OUTLINE_SORT_LEXICALLY, checked);
            }
        }

    }

    /**
     * This action toggles whether this Java Outline page links its selection
     * to the active editor.
     */
    private class ToggleLinkingAction extends ResourceAction {
        
        /**
         * Constructs a new action.
         */
        public ToggleLinkingAction() {
            super(CssEditorMessages.getResourceBundle(),
                "CssOutlinePage.linkWithEditor."); //$NON-NLS-1$
            CssEditorPlugin plugin = CssEditorPlugin.getDefault();
            boolean checked = plugin.getPreferenceStore().getBoolean(
                CssEditorPreferences.OUTLINE_LINK_WITH_EDITOR); //$NON-NLS-1$
            valueChanged(checked, false);
        }

        /*
         * @see org.eclipse.jface.action.Action#run()
         */
        public void run() {
            valueChanged(isChecked(), true);
        }
    
        // Private Methods -----------------------------------------------------

        /**
         * Updates the sorting of the outline.
         * 
         * @param checked Whether lexical sorting is enabled
         * @param store Whether the new state should be written back as a 
         *        preference
         */
        private void valueChanged(final boolean checked, boolean store) {
            setChecked(checked);
            BusyIndicator.showWhile(getTreeViewer().getControl().getDisplay(),
                new Runnable() {
                    public void run() {
                        editor.synchronizeOutlinePage();
                    }
                });
            if (store) {
                CssEditorPlugin plugin = CssEditorPlugin.getDefault();
                plugin.getPreferenceStore().setValue(
                    CssEditorPreferences.OUTLINE_LINK_WITH_EDITOR, checked);
            }
        }

    }

    // Instance Variables ------------------------------------------------------

    /**
     * The associated editor.
     */
    private CssEditor editor;

    /**
     * Toolbar action for showing only the selected element in the editor.
     */
    private ShowSelectedElementOnlyAction showSelectedElementOnlyAction = 
        new ShowSelectedElementOnlyAction(); //$NON-NLS-1$
        
    // Constructors ------------------------------------------------------------

    /**
     * Constructor.
     * 
     * @param editor The associated text editor
     */
    public CssOutlinePage(CssEditor editor) {
        this.editor = editor;
    }

    // ContentOutlinePage Implementation ---------------------------------------

    /*
     * @see org.eclipse.ui.part.IPage#createControl(Composite)
     */
    public void createControl(Composite parent) {
        super.createControl(parent);
        TreeViewer viewer = getTreeViewer();
        viewer.addDoubleClickListener(new CssOutlineDoubleClickListener(this));
        viewer.setContentProvider(new CssOutlineContentProvider(this));
        viewer.setLabelProvider(new CssOutlineLabelProvider());
        viewer.setInput(getStyleSheet());
    }

    /*
     * @see org.eclipse.ui.part.IPage#dispose()
     */
    public void dispose() {
        if (editor != null) {
            editor.outlinePageClosed();
            editor = null;
        }
        super.dispose();
    }

    /*
     * @see org.eclipse.ui.part.IPageBookViewPage#init(org.eclipse.ui.part.IPageSite)
     */
    public void init(IPageSite pageSite) {
        super.init(pageSite);
        IActionBars bars = pageSite.getActionBars();      
        bars.setGlobalActionHandler(
            ITextEditorActionDefinitionIds.TOGGLE_SHOW_SELECTED_ELEMENT_ONLY,
            showSelectedElementOnlyAction);
        showSelectedElementOnlyAction.setEditor(editor);
        showSelectedElementOnlyAction.update();
    }

    /*
     * @see org.eclipse.ui.part.Page#makeContributions(IMenuManager, IToolBarManager, IStatusLineManager)
     */
    public void makeContributions(IMenuManager menuManager,
        IToolBarManager toolBarManager, IStatusLineManager statusLineManager) {
        if (toolBarManager != null) {   
            toolBarManager.add(new ToggleLexicalSortingAction());
            toolBarManager.add(new ToggleLinkingAction());
        }
        super.makeContributions(menuManager, toolBarManager, statusLineManager);
    }

    // Public Methods ----------------------------------------------------------

    /**
     * Selects a specific element in the outline page.
     * 
     * @param element the element to select
     */
    public void select(ISourceReference element) {
        TreeViewer viewer = getTreeViewer();
        if (viewer != null) {
            ISelection selection = viewer.getSelection();
            if (selection instanceof IStructuredSelection) {
                IStructuredSelection structuredSelection =
                    (IStructuredSelection) selection;
                List elements = structuredSelection.toList();
                if (!elements.contains(element)) {
                    if (element == null) {
                        selection = StructuredSelection.EMPTY;
                    } else {
                        selection = new StructuredSelection(element);
                    }
                    viewer.setSelection(selection, true);
                }
            }
        }
    }

    /**
     * Updates the outline page.
     */
    public void update() {
        IStyleSheet styleSheet = getStyleSheet();
        if (styleSheet != null) {
            TreeViewer viewer = getTreeViewer();
            if (viewer != null) {
                Control control = viewer.getControl();
                if ((control != null) && !control.isDisposed()) {
                    control.setRedraw(false);
                    viewer.setInput(styleSheet);
                    viewer.expandAll();
                    control.setRedraw(true);
                }
            }
        }
    }

    // Private Methods ---------------------------------------------------------

    /**
     * Returns the parsed model of the style sheet that is loaded into the 
     * associated editor.
     * 
     * @return the parsed style sheet
     */
    private IStyleSheet getStyleSheet() {
        IDocumentProvider provider = editor.getDocumentProvider();
        if (provider instanceof CssDocumentProvider) {
            CssDocumentProvider cssProvider = (CssDocumentProvider) provider;
            return cssProvider.getStyleSheet(editor.getEditorInput());
        }
        return null;
    }

}
