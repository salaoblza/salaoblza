/*
 * Copyright (c) 2003 Christopher Lenz and others.
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 * 
 * Contributors:
 *     Christopher Lenz - initial API and implementation
 * 
 * $Id: MutableRegion.java,v 1.1.1.1 2003/12/14 21:59:43 cell Exp $
 */

package net.sourceforge.csseditor.internal.parser;

import org.eclipse.jface.text.IRegion;

/**
 * @author chris
 * @version $Revision: 1.1.1.1 $
 */
public class MutableRegion implements IRegion {

    // Instance Variables ------------------------------------------------------

    /**
     * The offset of the region.
     */
    private int fOffset = 0;

    /**
     * The length of the region.
     */
    private int fLength = 0;

    // Constructors ------------------------------------------------------------

    /**
     * Default constructor.
     */
    public MutableRegion() {
        this(0);
    }

    /**
     * Constructor with partial initialization.
     * 
     * @param offset the offset of the region
     */
    public MutableRegion(int offset) {
        this.fOffset = offset;
    }

    /**
     * Constructor with initialization.
     * 
     * @param offset the offset of the region
     * @param length the length of the region
     */
    public MutableRegion(int offset, int length) {
        this.fOffset = offset;
        this.fLength = length;
    }

    /**
     * Constructor with initialization.
     * 
     * @param region another region to initialize this region with
     */
    public MutableRegion(IRegion region) {
        this.fOffset = region.getOffset();
        this.fLength = region.getLength();
    }

    // IRegion Implementation --------------------------------------------------

    /*
     * @see org.eclipse.jface.text.IRegion#getLength()
     */
    public int getLength() {
        return fLength;
    }

    /*
     * @see org.eclipse.jface.text.IRegion#getOffset()
     */
    public int getOffset() {
        return fOffset;
    }

    // Public Methods ----------------------------------------------------------

    /**
     * Adds another region to this region, which will be enlarged so that the
     * added region completely fits into this region.
     * 
     * @param region the region to add 
     */
    public void add(IRegion region) {
        int start1 = fOffset;
        int end1 = fOffset + fLength;
        int start2 = region.getOffset();
        int end2 = start2 + region.getLength();
        fOffset = (start1 < start2) ? start1 : start2;
        fLength = (end1 > end2) ? (end1 - fOffset) : (end2 - fOffset);
    }

    /**
     * Sets the length of the region.
     * 
     * @param length the length to set
     */
    public void setLength(int length) {
        fLength = length;
    }

    /**
     * Sets the offset of the region.
     * 
     * @param offset the offset to set
     */
    public void setOffset(int offset) {
        fOffset = offset;
    }

}
