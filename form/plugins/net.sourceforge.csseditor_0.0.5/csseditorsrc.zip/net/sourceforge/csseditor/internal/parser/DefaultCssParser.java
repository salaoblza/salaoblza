/*
 * Copyright (c) 2003 Christopher Lenz and others.
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 * 
 * Contributors:
 *     Christopher Lenz - initial API and implementation
 * 
 * $Id: DefaultCssParser.java,v 1.3 2004/01/11 19:15:33 cell Exp $
 */

package net.sourceforge.csseditor.internal.parser;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.eclipse.jface.text.IDocument;

import net.sourceforge.csseditor.internal.CssTextUtils;
import net.sourceforge.csseditor.internal.model.AtRule;
import net.sourceforge.csseditor.internal.model.Declaration;
import net.sourceforge.csseditor.internal.model.SourceReference;
import net.sourceforge.csseditor.internal.model.StyleRule;
import net.sourceforge.csseditor.model.IAtRule;
import net.sourceforge.csseditor.model.IDeclaration;
import net.sourceforge.csseditor.model.IRule;
import net.sourceforge.csseditor.model.ISourceReference;
import net.sourceforge.csseditor.model.IStyleRule;
import net.sourceforge.csseditor.model.IStyleSheet;
import net.sourceforge.csseditor.parser.ICssParser;
import net.sourceforge.csseditor.parser.ICssScanner;
import net.sourceforge.csseditor.parser.ICssTokens;
import net.sourceforge.csseditor.parser.IProblem;
import net.sourceforge.csseditor.parser.IProblemCollector;
import net.sourceforge.csseditor.parser.LexicalErrorException;
import net.sourceforge.csseditor.parser.SyntaxErrorException;

/**
 * A simple CSS parser implementation.
 * 
 * TODO At-rules can contain child rules as well as declarations. Currently we
 *      only handle child rules.
 */
public class DefaultCssParser extends AbstractProblemReporter
    implements ICssParser {

    // Instance Variables ------------------------------------------------------

    /**
     * The underlying CSS token scanner.
     */
    private ICssScanner fScanner;

    /**
     * The token being currently processed.
     */
    private int fCurrentToken;

    /**
     * Whether the parser is currently initializer. Is <code>true</code> as soon
     * as fCurrentToken has been initialized.
     */
    private boolean fInitialized;

    // ICssParser Implementation -----------------------------------------------

    /**
     * @see ICssParser#parseRules()
     */
    public IRule[] parseRules(IStyleSheet styleSheet)
        throws LexicalErrorException, SyntaxErrorException {
        List rules = new ArrayList();
        nextToken();
        if (fCurrentToken == ICssTokens.CDO) {
            // ignore an opening SGML comment delimiter at the start of the
            // style sheet
            nextToken();
        }
        while (fCurrentToken != ICssTokens.EOF) {
            if (fCurrentToken == ICssTokens.CDC) {
                // ignore a closing SGML comment delimiter at the end of the
                // style sheet
                IProblem problem = createWarning(
                    "illegalPositionForCDC", //$NON-NLS-1$
                    fScanner.getTokenRegion());
                if (nextToken() != ICssTokens.EOF) {
                    reportProblem(problem);
                }
            } else if (fCurrentToken == ICssTokens.CDO) {
                reportWarning("illegalPositionForCDO", //$NON-NLS-1$
                    fScanner.getTokenRegion());
                nextToken();
            } else {
                IRule rule = parseRule(styleSheet, null);
                if (rule != null) {
                    rules.add(rule);
                } else {
                    break;
                }
            }
        }
        return (IRule[]) rules.toArray(new IRule[rules.size()]);
    }

    /**
     * Parses a CSS rule, which can be either an at-rule like
     * <code>@import</code> or a normal style rule.
     * 
     * @param parent the parent rule in which the rule to parse is nested, or
     *        <code>null</code> if the rule to parse is at the top level of the
     *        style sheet
     * @return the parsed rule
     * @throws LexicalErrorException if a lexical error is reported by the
     *         scanner
     * @throws SyntaxErrorException if a syntax error has been encountered from
     *         which recovery is not possible
     */
    public IRule parseRule(IStyleSheet styleSheet, IRule parent)
        throws LexicalErrorException, SyntaxErrorException {
        if (!fInitialized) {
            nextToken();
        }
        if ((fCurrentToken == -1) || (fCurrentToken == '}')) {
            reportError("expectedRule", //$NON-NLS-1$
                fScanner.getTokenRegion());
            return null;
        }
        switch (fCurrentToken) {
            case ICssTokens.AT: {
                return parseAtRule(styleSheet, parent);
            }
            default: {
                return parseStyleRule(styleSheet, parent);
            }
        }
    }

    /**
     * Parses a CSS selector. The provided reader is expected to be positioned
     * at the beginning of the selector (leading whitespace will be ignored).
     * 
     * @return the parsed selector
     * @throws LexicalErrorException if a lexical error is reported by the
     *         scanner
     * @throws SyntaxErrorException if a syntax error has been encountered from
     *         which recovery is not possible
     */
    public ISourceReference parseSelector(IRule rule)
        throws LexicalErrorException, SyntaxErrorException {
        if (!fInitialized) {
            nextToken();
        }
        return parseAnythingUpto(new int[] { ICssTokens.LBRACE });
    }

    /**
     * Parses a declaration. The provided reader is expected to be positioned at
     * the beginning of the property name (leading whitespace will be ignored).
     * The return declaration will start with the start of the property, and
     * will end at the end of the value, excluding the semicolon, if one is 
     * present.
     * 
     * @return the parsed style declaration
     * @throws LexicalErrorException if a lexical error is reported by the
     *         scanner
     * @throws SyntaxErrorException if a syntax error has been encountered from
     *         which recovery is not possible
     */
    public IDeclaration parseDeclaration(IRule rule)
        throws LexicalErrorException, SyntaxErrorException {
        if (!fInitialized) {
            nextToken();
        }
        if ((fCurrentToken == -1) || (fCurrentToken == '}')) {
            return null;
        }
        Declaration declaration = new Declaration(fDocument, rule);
        MutableRegion declarationRegion = newRegion();

        // parse the property
        if (fCurrentToken == ICssTokens.IDENT) {
            SourceReference property = new SourceReference(fDocument);
            property.setSourceRegion(fScanner.getTokenRegion());
            declaration.setProperty(property);
            nextToken(declarationRegion);
        } else {
            reportError("expectedProperty", //$NON-NLS-1$
                fScanner.getTokenRegion());
        }

        // expect a colon to delimit the property from the value
        if (fCurrentToken == ICssTokens.COLON) {
            nextToken(declarationRegion);
        } else {
            reportError("expectedToken", ":", //$NON-NLS-1$ //$NON-NLS-2$
                fScanner.getTokenRegion());
        }

        // parse the declaration value (excluding the priority)
        ISourceReference value = parseAnythingUpto(new int[] {
            ICssTokens.RBRACE, ICssTokens.SEMICOLON, ICssTokens.EXCLAMATION
        });
        if (value != null) {
            declaration.setValue(value);
            declarationRegion.add(value.getSourceRegion());
        } else {
            reportError("emptyDeclarationValue", //$NON-NLS-1$
                fScanner.getTokenRegion());
        }

        // if present, parse the declaration priority
        if (fCurrentToken == '!') {
            SourceReference priority = new SourceReference(fDocument);
            MutableRegion priorityRegion = newRegion();
            if (nextToken() == ICssTokens.IDENT) {
                nextToken(priorityRegion);
            } else {
                reportError("priorityExpected", //$NON-NLS-1$
                    fScanner.getTokenRegion());
            }
            priority.setSourceRegion(priorityRegion);
            declaration.setPriority(priority);
            declarationRegion.add(priority.getSourceRegion());
        }

        declaration.setSourceRegion(declarationRegion);
        return declaration;
    }

    /**
     * @see ICssParser#setProblemCollector(IProblemCollector)
     */
    public void setProblemCollector(IProblemCollector problemCollector) {
        super.setProblemCollector(problemCollector);
        if (fScanner != null) {
            fScanner.setProblemCollector(problemCollector);
        }
    }

    /**
     * @see ICssParser#setSource(IDocument)
     */
    public void setSource(IDocument document) {
        setDocument(document);
        if (fScanner != null) {
            fScanner.setSource(document);
        }
    }

    // Protected Methods -------------------------------------------------------

    protected ICssScanner createScanner(IDocument document) {
        ICssScanner retVal = new DefaultCssScanner();
        retVal.setSource(document);
        retVal.setProblemCollector(fProblemCollector);
        return retVal;
    }

    /**
     * Parses a region of the source until one of the specified tokens is 
     * encountered. In addition, this method keeps track of opened parenthesis
     * and brackets, and will report an error if they are not closed.
     * 
     * @param tokens an array containing the tokens that should delimit the
     *        range of source to parse
     * @return the parsed source reference
     * @throws LexicalErrorException if a lexical error is reported by the
     *         scanner
     * @throws SyntaxErrorException if a syntax error has been encountered from
     *         which recovery is not possible
     */
    protected final ISourceReference parseAnythingUpto(int tokens[])
        throws LexicalErrorException, SyntaxErrorException {
        Arrays.sort(tokens);
        SourceReference any = null;
        MutableRegion region = newRegion();
        while (fCurrentToken != ICssTokens.EOF) {
            if (Arrays.binarySearch(tokens, fCurrentToken) >= 0) {
                break;
            } else {
                any = new SourceReference(fDocument);
                if ((fCurrentToken == '(') || (fCurrentToken == '[')) {
                    char peer = CssTextUtils.getPeerCharacter(
                        (char) fCurrentToken);
                    nextToken(region);
                    ISourceReference ref = parseAnythingUpto(new int[] { peer } );
                    if (fCurrentToken != peer) {
                        reportError("expectedToken", //$NON-NLS-1$
                            String.valueOf(peer), fScanner.getTokenRegion());
                    }
                    if (ref != null) {
                        region.add(ref.getSourceRegion());
                    }
                }
            }
            nextToken(region);
        }
        if (any != null) {
            any.setSourceRegion(region);
        }
        return any;
    }

    /**
     * Parses an at-rule.
     *  
     * @param styleSheet the owning style sheet
     * @param parent the rule in which the rule to parse is nested, or
     *        <code>null</code> if this rule is at the top level of the style
     *        sheet
     * @return the parsed rule
     * @throws LexicalErrorException if a lexical error is reported by the
     *         scanner
     * @throws SyntaxErrorException if a syntax error has been encountered from
     *         which recovery is not possible
     */
    protected final IAtRule parseAtRule(IStyleSheet styleSheet, IRule parent)
        throws LexicalErrorException, SyntaxErrorException {
        AtRule rule = new AtRule(fDocument, styleSheet, parent);
        MutableRegion ruleRegion = newRegion();
        if (fCurrentToken == ICssTokens.AT) {
            nextToken();
        } else {
            reportError("expectedToken", "@",  //$NON-NLS-1$//$NON-NLS-2$
                fScanner.getTokenRegion());
        }
        if (fCurrentToken == ICssTokens.IDENT) {
            SourceReference name = new SourceReference(fDocument);
            name.setSourceRegion(fScanner.getTokenRegion());
            rule.setName(name);
            nextToken(ruleRegion);
        } else {
            reportError("expectedAtKeyword", //$NON-NLS-1$
                fScanner.getTokenRegion());
        }
        if ((fCurrentToken != ICssTokens.LBRACE)
         && (fCurrentToken != ICssTokens.SEMICOLON)
         && (fCurrentToken != ICssTokens.EOF)) {
            ISourceReference value = parseAnythingUpto(new int[] {
                ICssTokens.LBRACE, ICssTokens.SEMICOLON
            });
            rule.setValue(value);
            ruleRegion.add(value.getSourceRegion());
        }
        if (fCurrentToken == ICssTokens.LBRACE) {
            nextToken(ruleRegion);
            while (fCurrentToken != ICssTokens.RBRACE) {
                IRule child = parseRule(styleSheet, rule);
                if (child != null) {
                    rule.addChild(child);
                    ruleRegion.add(child.getSourceRegion());
                }
                if (fCurrentToken == ICssTokens.EOF) {
                    reportError("unexpectedEndOfFile", //$NON-NLS-1$
                        fScanner.getTokenRegion());
                    break;
                }
            }
            if (fCurrentToken == ICssTokens.RBRACE) {
                nextToken(ruleRegion);
            } else {
                reportError("expectedToken", "}", //$NON-NLS-1$ //$NON-NLS-2$
                    fScanner.getTokenRegion());
            }
        } else {
            if ((rule.getValue() == null) && (rule.getChildren().length == 0)) {
                reportError("expectedValueOrBlock", //$NON-NLS-1$
                    fScanner.getTokenRegion());
            } else if (fCurrentToken != ICssTokens.SEMICOLON) {
                reportError("expectedToken", ";", //$NON-NLS-1$ //$NON-NLS-2$
                    fScanner.getTokenRegion());
            }
            if (fCurrentToken == ICssTokens.SEMICOLON) {
                nextToken(ruleRegion);
            }
        }
        rule.setSourceRegion(ruleRegion);
        return rule;
    }

    /**
     * Parses a style rule.
     * 
     * <p>
     *   This corresponds to the <code>ruleset</code> production in the
     *   specification  of the CSS 3 syntax module:
     * </p>
     * <pre>
     *   selector? '{' S* declaration? [ ';' S* declaration? ]* '}' S*
     * </pre>
     * 
     * <p>
     *   <strong>Question</strong>: why is the selector optional in the above
     *   production? In section 4.8 the specification says that <em>"A rule set
     *   (also called 'rule') consists of a selector followed by a declaration
     *   block."</em> So we should be able to assume that there
     *   <strong>must</strong> be a selector, and otherwise report an error.
     * </p>
     * 
     * @param parent the parent rule in which the style rule is nested, or
     *        <code>null</code> if the style rule to parse is at the top level
     *        of the style sheet
     * @return the parsed style rule
     * @throws LexicalErrorException if a lexical error is reported by the
     *         scanner
     * @throws SyntaxErrorException if a syntax error has been encountered from
     *         which recovery is not possible
     */
    protected final IStyleRule parseStyleRule(IStyleSheet styleSheet,
        IRule parent) throws LexicalErrorException, SyntaxErrorException {
        StyleRule rule = new StyleRule(fDocument, styleSheet, parent);
        MutableRegion ruleRegion = newRegion();
        ISourceReference selector = parseSelector(rule);
        if (selector != null) {
            rule.setSelector(selector);
        } else {
            reportError("expectedSelectorOrAtKeyword", //$NON-NLS-1$
                fScanner.getTokenRegion());
        }
        if (fCurrentToken == ICssTokens.LBRACE) {
            nextToken(ruleRegion);
            do {
                IDeclaration declaration = parseDeclaration(rule);
                if (declaration != null) {
                    rule.addDeclaration(declaration);
                    ruleRegion.add(declaration.getSourceRegion());
                }
                if (fCurrentToken == ';') {
                    nextToken(ruleRegion);
                } else {
                    break;
                }
            } while ((fCurrentToken != ICssTokens.RBRACE)
                  && (fCurrentToken != ICssTokens.EOF));
            if (fCurrentToken == ICssTokens.RBRACE) {
                nextToken(ruleRegion);
            } else {
                reportError("expectedToken", "}", //$NON-NLS-1$ //$NON-NLS-2$
                    fScanner.getTokenRegion());
            }
        } else {
            reportError("expectedToken", "{", //$NON-NLS-1$ //$NON-NLS-2$
                fScanner.getTokenRegion());
        }
        rule.setSourceRegion(ruleRegion);
        return rule;
    }

    // Private Methods ---------------------------------------------------------

    private int nextToken()
        throws LexicalErrorException {
        return nextToken(null);
    }

    private int nextToken(MutableRegion region)
        throws LexicalErrorException {
        fInitialized = true;
        if (fScanner == null) {
            fScanner = createScanner(fDocument);
        }
        if (region != null) {
            region.add(fScanner.getTokenRegion());
        }
        fCurrentToken = fScanner.getNextToken();
        return fCurrentToken;
    }

    private MutableRegion newRegion() {
        return new MutableRegion(fScanner.getTokenRegion());
    }

}
