/*
 * Copyright (c) 2003 Christopher Lenz and others.
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 * 
 * Contributors:
 *     Christopher Lenz - initial API and implementation
 * 
 * $Id: CssOutlineContentProvider.java,v 1.3 2004/01/13 16:19:58 cell Exp $
 */

package net.sourceforge.csseditor.internal.outline;

import org.eclipse.jface.viewers.ITreeContentProvider;
import org.eclipse.jface.viewers.Viewer;

import net.sourceforge.csseditor.model.IRule;
import net.sourceforge.csseditor.model.IStyleSheet;
import net.sourceforge.csseditor.model.IStyleSheetListener;
import net.sourceforge.csseditor.model.StyleSheetChangeEvent;

/**
 * Content provider for the CSS outline page.
 */
public class CssOutlineContentProvider
    implements ITreeContentProvider, IStyleSheetListener {

    // Instance Variables ------------------------------------------------------

    /**
     * The outline page that this content provider belongs to.
     */
    private CssOutlinePage outlinePage;

    /**
     * The parsed style sheet.
     */
    private IStyleSheet styleSheet;

    // Constructors ------------------------------------------------------------

    /**
     * Constructor.
     * 
     * @param page the outline page
     */
    public CssOutlineContentProvider(CssOutlinePage page) {
        this.outlinePage = page;
    }

    // ITreeContentProvider Implementation -------------------------------------

    /*
     * ITreeContentProvider#getChildren(Object)
     */
    public Object[] getChildren(Object parentElement) {
        if (parentElement instanceof IRule) {
            return ((IRule) parentElement).getChildren();
        }
        return new Object[0];
    }

    /*
     * @see ITreeContentProvider#getParent(Object)
     */
    public Object getParent(Object element) {
        if (element instanceof IRule) {
            return ((IRule) element).getParent();
        }
        return null;
    }

    /*
     * @see ITreeContentProvider#hasChildren(Object)
     */
    public boolean hasChildren(Object element) {
        return getChildren(element).length > 0;
    }

    /*
     * @see org.eclipse.jface.viewers.IStructuredContentProvider#getElements(Object)
     */
    public Object[] getElements(Object inputElement) {
        if (styleSheet != null) {
            return styleSheet.getRules();
        }
        return new Object[0];
    }

    /*
     * @see org.eclipse.jface.viewers.IContentProvider#dispose()
     */
    public void dispose() {
        outlinePage = null;
        styleSheet = null;
    }

    /*
     * @see org.eclipse.jface.viewers.IContentProvider#inputChanged(Viewer, Object, Object)
     */
    public void inputChanged(Viewer viewer, Object oldInput, Object newInput) {
        if (oldInput != newInput) {
            if (oldInput instanceof IStyleSheet) {
                IStyleSheet oldStyleSheet = (IStyleSheet) oldInput;
                oldStyleSheet.removeListener(this);
            }
            if (newInput instanceof IStyleSheet) {
                IStyleSheet newStyleSheet = (IStyleSheet) newInput;
                newStyleSheet.addListener(this);
                styleSheet = newStyleSheet;
            }      
        }
    }

    // IStyleSheetListener Implementation --------------------------------------

    /*
     * @see IStyleSheetListener#styleSheetChanged(StyleSheetChangeEvent)
     */
    public void styleSheetChanged(StyleSheetChangeEvent event) {
        outlinePage.getControl().getDisplay().asyncExec(new Runnable() {
            public void run() {
                if (outlinePage != null) {
                    outlinePage.update();
                }
            }
        });
    }

}
