/*
 * Copyright (c) 2003 Christopher Lenz and others.
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 * 
 * Contributors:
 *     Christopher Lenz - initial API and implementation
 * 
 * $Id: CssAnnotationHover.java,v 1.2 2003/12/27 14:33:09 cell Exp $
 */

package net.sourceforge.csseditor.internal.text;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.eclipse.jface.text.BadLocationException;
import org.eclipse.jface.text.IDocument;
import org.eclipse.jface.text.IRegion;
import org.eclipse.jface.text.ITextHover;
import org.eclipse.jface.text.ITextViewer;
import org.eclipse.jface.text.Position;
import org.eclipse.jface.text.Region;
import org.eclipse.jface.text.source.Annotation;
import org.eclipse.jface.text.source.IAnnotationHover;
import org.eclipse.jface.text.source.IAnnotationModel;
import org.eclipse.jface.text.source.ISourceViewer;

/**
 * Implements simple annotation hover to show the associated messages.
 */
public class CssAnnotationHover implements IAnnotationHover, ITextHover {

    // Instance Variables ------------------------------------------------------

    /**
     * This hovers annotation model.
     */
    private IAnnotationModel model;

    // Constructors ------------------------------------------------------------

    /**
     * Creates a new annotation hover.
     * 
     * @param model this hover's annotation model
     */
    public CssAnnotationHover(IAnnotationModel model)  {
        this.model = model;
    }
    
    // IAnnotationHover Implementation -----------------------------------------

    /*
     * @see IVerticalRulerHover#getHoverInfo(ISourceViewer, int)
     */
    public String getHoverInfo(ISourceViewer sourceViewer, int lineNumber) {
        List annotations = getAnnotationsForLine(sourceViewer, lineNumber);
        if (annotations != null) {
            List messages = new ArrayList();
            Iterator e = annotations.iterator();
            while (e.hasNext()) {
                Annotation annotation = (Annotation) e.next();
                String message = annotation.getText();
                if (message != null) {
                    message = message.trim();
                    if (message.length() > 0) {
                        messages.add(message);
                    }
                }
            }
            if (messages.size() == 1) {
                return (String) messages.get(0);
            }
            if (messages.size() > 1) {
                return formatMessages(messages);
            }
        }
        return null;
    }

    // ITextHover Implementation -----------------------------------------------

    /*
     * @see ITextHover#getHoverInfo(ITextViewer, IRegion)
     */
    public String getHoverInfo(ITextViewer textViewer, IRegion region) {
        Iterator e = this.model.getAnnotationIterator();
        while (e.hasNext()) {
            Annotation a = (Annotation) e.next();
            Position p = this.model.getPosition(a);
            if (p.overlapsWith(region.getOffset(), region.getLength())) {
                String text = a.getText();
                if ((text != null) && (text.trim().length() > 0)) {
                    return text;
                }
            }
        }
        return null;
    }

    /*
     * @see ITextHover#getHoverRegion(ITextViewer, int)
     */
    public IRegion getHoverRegion(ITextViewer textViewer, int offset) {
        // TODO If this is too slow then we might return new Region(offset, 0)
        Iterator e = this.model.getAnnotationIterator();
        while (e.hasNext()) {
            Annotation a = (Annotation) e.next();
            Position p = this.model.getPosition(a);
            if (p.overlapsWith(offset, 0)) {
                String text = a.getText();
                if ((text != null) && (text.trim().length() > 0)) {
                    return new Region(p.offset, p.length);
                }
            }
        }
        return null;
    }
    // Private Methods ---------------------------------------------------------

    /**
     * Formats multiple annotation messages for display.
     */
    private String formatMessages(List messages) {
        StringBuffer buffer = new StringBuffer();
        Iterator e = messages.iterator();
        while (e.hasNext())  {
            buffer.append("- "); //$NON-NLS-1$
            buffer.append(e.next());
            buffer.append('\n');
        }
        return buffer.toString();
    }

    /**
     * Returns annotations for the ruler's line of activity.
     */
    private List getAnnotationsForLine(ISourceViewer viewer, int line) {
        IDocument document = viewer.getDocument();
        IAnnotationModel model = viewer.getAnnotationModel();
        if (model == null) {
            return null;
        }
        List retVal = new ArrayList();
        Iterator e = model.getAnnotationIterator();
        while (e.hasNext()) {
            Annotation a = (Annotation) e.next();
            Position position = model.getPosition(a);
            if (position != null) {
                try {
                    int annotationLine =
                        document.getLineOfOffset(position.getOffset());
                    if (annotationLine == line) {
                        retVal.add(a);
                    }
                } catch (BadLocationException e1) {
                    // ignore
                }
            }
        }
        return retVal;
    }

}
