/*
 * Copyright (c) 2003 Christopher Lenz and others.
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 * 
 * Contributors:
 *     Christopher Lenz - initial API and implementation
 * 
 * $Id: CssTextUtils.java,v 1.3 2003/12/28 17:09:15 cell Exp $
 */

package net.sourceforge.csseditor.internal;

import java.io.IOException;

import org.eclipse.jface.text.IDocument;

import net.sourceforge.csseditor.CssEditorPlugin;
import net.sourceforge.csseditor.internal.text.CssCodeReader;

/**
 * TODO Fix the context-detection methods to work properly, maybe base them on
 *       the parsed AST, which would use document change listeners to trigger 
 *       partial reparses so to stay in sync.
 */
public final class CssTextUtils {

    // Constructors ------------------------------------------------------------

    /**
     * Hidden.
     */
    private CssTextUtils() {
        // Hidden
    }

    // Public Methods ----------------------------------------------------------

    public static int findMatchingClosingPeer(IDocument document, int offset,
        char openingPeer) {
        try {
            CssCodeReader reader = new CssCodeReader(document, offset,
                document.getLength(), CssCodeReader.FORWARD);
            char closingChar = getPeerCharacter(openingPeer);
            int stack = 1;
            int c = reader.read();
            while (c != -1) {
                if ((c == openingPeer) && (c != closingChar)) {
                    stack++;
                } else if (c == closingChar) {
                    stack--;
                }
                if (stack == 0) {
                    return reader.getOffset();
                }
                c = reader.read();
            }
        } catch (IOException e) {
            CssEditorPlugin.log(
                "Failed to find matching closing peer for '" + //$NON-NLS-1$
                openingPeer + '\'', e);
        }
        return -1;
    }

    public static int findMatchingOpeningPeer(IDocument document, int offset,
        char closingPeer) {
        try {
            CssCodeReader reader = new CssCodeReader(document, offset + 1,
                document.getLength(), CssCodeReader.BACKWARD);
            char openingChar = getPeerCharacter(closingPeer);
            int stack = 1;
            int c = reader.read();
            while (c != -1) {
                if ((c == closingPeer) && (c != openingChar)) {
                    stack++;
                } else if (c == openingChar) {
                    stack--;
                }
                if (stack == 0) {
                    return reader.getOffset();
                }
                c = reader.read();
            }
        } catch (IOException e) {
            CssEditorPlugin.log(
                "Failed to find matching opening peer for '" + //$NON-NLS-1$
                closingPeer + '\'', e);
        }
        return  -1;
    }

    public static char getPeerCharacter(char c) {
        switch (c) {
            case '{': return '}';
            case '}': return '{';
            case '[': return ']';
            case ']': return '[';
            case '(': return ')';
            case ')': return '(';
            case '"': return '"';
            case '\'': return '\'';
            default: return 0;
        }
    }

    public static boolean isCssIdentifierPart(char c) {
        return ((c == '_') || Character.isLetterOrDigit(c) || (c == '-'));
    }

    public static boolean isCssIdentifierStart(char c) {
        return ((c == '_') || Character.isLetter(c));
    }

    public static boolean isCssNumberPart(char c) {
        return ((c == '.') || Character.isDigit(c));
    }

    public static boolean isCssNumberStart(char c) {
        return ((c == '-') || (c == '.') || Character.isDigit(c));
    }

    public static boolean isCssWhitespace(char c) {
        return Character.isWhitespace(c);
    }

}
