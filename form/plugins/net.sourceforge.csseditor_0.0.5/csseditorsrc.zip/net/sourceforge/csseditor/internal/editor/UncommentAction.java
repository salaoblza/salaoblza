/*
 * Copyright (c) 2003 Christopher Lenz and others.
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 * 
 * Contributors:
 *     Christopher Lenz - initial API and implementation
 * 
 * $Id: UncommentAction.java,v 1.2 2003/12/27 18:46:55 cell Exp $
 */

package net.sourceforge.csseditor.internal.editor;

import java.util.ResourceBundle;

import org.eclipse.jface.text.BadLocationException;
import org.eclipse.jface.text.IDocument;
import org.eclipse.jface.text.IRewriteTarget;
import org.eclipse.jface.text.ITextSelection;
import org.eclipse.jface.text.ITypedRegion;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.ISelectionProvider;
import org.eclipse.ui.IEditorInput;
import org.eclipse.ui.texteditor.IDocumentProvider;
import org.eclipse.ui.texteditor.ITextEditor;
import org.eclipse.ui.texteditor.ITextEditorExtension2;
import org.eclipse.ui.texteditor.TextEditorAction;

import net.sourceforge.csseditor.internal.text.CssPartitionScanner;

/**
 * (Heavily inspired by the RemoveBlockComment class in JDT-UI)
 */
public class UncommentAction extends TextEditorAction {

    // Constructors ------------------------------------------------------------

    /**
     * Creates a new instance.
     * 
     * @param bundle the resource bundle
     * @param prefix a prefix to be prepended to the various resource keys
     *   (described in <code>ResourceAction</code> constructor), or 
     *   <code>null</code> if none
     * @param editor the text editor
     */
    public UncommentAction(ResourceBundle bundle, String prefix,
        ITextEditor editor) {
        super(bundle, prefix, editor);
    }
    
    // TextEditorAction Implementation -----------------------------------------

    /**
     * @see org.eclipse.jface.action.Action#run()
     */
    public void run() {
        if (!isEnabled()) {
            return;
        }
        ITextEditor editor = getTextEditor();
        if ((editor == null) || !ensureEditable(editor)) {
            return;
        }
        ITextSelection selection = getCurrentSelection();
        if (!isValidSelection(selection)) {
            return;
        }
        IDocumentProvider docProvider = editor.getDocumentProvider();
        IEditorInput input = editor.getEditorInput();
        if (docProvider == null || input == null) {
            return;
        }
        IDocument document = docProvider.getDocument(input);
        if (document == null) {
            return;
        }
        IRewriteTarget target = (IRewriteTarget)
            editor.getAdapter(IRewriteTarget.class);
        if (target != null) {
            target.beginCompoundChange();
        }
        try {
            ITypedRegion region = getBlockCommentRegion(document, selection);
            if (region != null) {
                int offset = region.getOffset();
                document.replace(offset, 2, ""); //$NON-NLS-1$
                document.replace(offset + region.getLength() - 4, 2,
                    ""); //$NON-NLS-1$
            }
        } catch (BadLocationException e) {
            // ignore
        } finally {
            if (target != null) {
                target.endCompoundChange();
            }
        }
    }
    
    // Private Methods ---------------------------------------------------------

    /**
     * Ensures that the editor is modifyable. If the editor is an instance of
     * <code>ITextEditorExtension2</code>, its 
     * <code>validateEditorInputState</code> method is called, otherwise, the 
     * result of <code>isEditable</code> is returned.
     * 
     * @param editor the editor to be checked
     * @return <code>true</code> if the editor is editable, <code>false</code> 
     *         otherwise
     */
    private boolean ensureEditable(ITextEditor editor) {
        if (editor instanceof ITextEditorExtension2) {
            ITextEditorExtension2 extension = (ITextEditorExtension2) editor;
            return extension.validateEditorInputState();
        }
        return editor.isEditable();
    }

    /**
     * Returns the block comment typed region enclosing the position at the end 
     * of <code>selection</code> or <code>null</code> if there is no block 
     * comment at this position.
     * 
     * @param selection the caret position (the end of the selection is taken as
     *        the position)
     * @return the block comment region at the selection's end, or 
     *         <code>null</code>
     */
    private ITypedRegion getBlockCommentRegion(IDocument document,
        ITextSelection selection) {
        try {
            ITypedRegion region = document.getPartition(
                selection.getOffset() + selection.getLength());
            if (CssPartitionScanner.CSS_COMMENT.equals(region.getType())) {
                return region;
            }
        } catch (BadLocationException e) {
            // ignore
        }
        return null;
    }

    /**
     * Returns the editor's selection, or <code>null</code> if no selection can 
     * be obtained or the editor is <code>null</code>.
     * 
     * @return the selection of the action's editor, or <code>null</code>
     */
    private ITextSelection getCurrentSelection() {
        ITextEditor editor = getTextEditor();
        if (editor != null) {
            ISelectionProvider provider = editor.getSelectionProvider();
            if (provider != null) {
                ISelection selection = provider.getSelection();
                if (selection instanceof ITextSelection) {
                    return (ITextSelection) selection;
                }
            }
        }
        return null;
    }

    /**
     * Checks whether given selection is valid, i.e. neither <code>null</code> 
     * or empty.
     * 
     * @param selection the selection to check
     * @return <code>true</code> if the selection is valid, <code>false</code> 
     *         otherwise
     */
    private boolean isValidSelection(ITextSelection selection) {
        if (selection != null) {
            return (!selection.isEmpty() && (selection.getLength() > 0));
        }
        return false;
    }

}
