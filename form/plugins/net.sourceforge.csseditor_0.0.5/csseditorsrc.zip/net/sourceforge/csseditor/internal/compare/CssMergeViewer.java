/*
 * Copyright (c) 2003 Christopher Lenz and others.
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 * 
 * Contributors:
 *     Christopher Lenz - initial API and implementation
 * 
 * $Id: CssMergeViewer.java,v 1.3 2004/01/13 17:10:28 cell Exp $
 */

package net.sourceforge.csseditor.internal.compare;

import org.eclipse.compare.CompareConfiguration;
import org.eclipse.compare.contentmergeviewer.TextMergeViewer;
import org.eclipse.jface.preference.IPreferenceStore;
import org.eclipse.jface.preference.PreferenceConverter;
import org.eclipse.jface.text.IDocumentPartitioner;
import org.eclipse.jface.text.TextViewer;
import org.eclipse.jface.text.source.SourceViewer;
import org.eclipse.jface.util.IPropertyChangeListener;
import org.eclipse.jface.util.PropertyChangeEvent;
import org.eclipse.swt.events.DisposeEvent;
import org.eclipse.swt.graphics.RGB;
import org.eclipse.swt.widgets.Composite;

import net.sourceforge.csseditor.CssEditorPlugin;
import net.sourceforge.csseditor.internal.CssEditorMessages;
import net.sourceforge.csseditor.internal.CssEditorPreferences;
import net.sourceforge.csseditor.text.CssSourceViewerConfiguration;
import net.sourceforge.csseditor.text.CssTextTools;

/**
 * Merge viewer for CSS files.
 */
public class CssMergeViewer extends TextMergeViewer {

    // Constants ---------------------------------------------------------------

    /**
     * Alias for the preference constant <code>EDITOR_BACKGROUND_COLOR</code>.
     */
    private static final String PREFERENCE_BACKGROUND_COLOR =
        CssEditorPreferences.EDITOR_BACKGROUND_COLOR;

    /**
     * Alias for the preference constant
     * <code>EDITOR_BACKGROUND_DEFAULT_COLOR</code>.
     */
    private static final String PREFERENCE_BACKGROUND_DEFAULT_COLOR =
        CssEditorPreferences.EDITOR_BACKGROUND_DEFAULT_COLOR;

    // Instance Variables ------------------------------------------------------

    /**
     * The preference store.
     */
    private IPreferenceStore preferenceStore;

    /**
     * The listener for changes to the preference store. 
     */
    private IPropertyChangeListener propertyChangeListener;

    /**
     * The CSS text tools.
     */
    private CssTextTools textTools;

    // Constructors ------------------------------------------------------------

    /**
     * Constructor.
     * 
     * @param parent the parent control
     * @param style SWT style bits for top level composite of this viewer
     * @param configuration the configuration object
     */
    public CssMergeViewer(Composite parent, int style,
        CompareConfiguration configuration) {
        super(parent, style, configuration);
    }

    // TextMergeViewer Implementation ------------------------------------------

    /*
     * @see TextMergeViewer#configureTextViewer()
     */
    protected void configureTextViewer(TextViewer textViewer) {

        CssEditorPlugin plugin = CssEditorPlugin.getDefault();

        this.preferenceStore = plugin.getPreferenceStore();
        if (preferenceStore != null) {
             propertyChangeListener = new IPropertyChangeListener() {
                public void propertyChange(PropertyChangeEvent event) {
                    handlePreferenceStoreChanged(event);
                }
            };
            preferenceStore.addPropertyChangeListener(propertyChangeListener);
        }

        textTools = plugin.getTextTools();
        if (textViewer instanceof SourceViewer) {
            SourceViewer sourceViewer = (SourceViewer) textViewer;
            sourceViewer.configure(new CssSourceViewerConfiguration(
                textTools, preferenceStore));
        }

        updateBackgroundColor();
    }

    /*
     * @see TextMergeViewer#getDocumentPartitioner()
     */
    protected IDocumentPartitioner getDocumentPartitioner() {
        return textTools.createDocumentPartitioner();
    }

    /*
     * @see org.eclipse.compare.contentmergeviewer.ContentMergeViewer#getTitle()
     */
    public String getTitle() {
        return CssEditorMessages.getString(
            "CssMergeViewer.title"); //$NON-NLS-1$
    }

    /*
     * @see org.eclipse.jface.viewers.ContentViewer#handleDispose(org.eclipse.swt.events.DisposeEvent)
     */
    protected void handleDispose(DisposeEvent event) {
        if (propertyChangeListener != null) {
            if (preferenceStore != null) {
                preferenceStore.removePropertyChangeListener(
                    propertyChangeListener);
            }
            propertyChangeListener = null;
        }
        super.handleDispose(event);
    }

    // Private Methods ---------------------------------------------------------

    /**
     * Called when the preference store notifies us about a change.
     * 
     * @param event the change event
     */
    protected void handlePreferenceStoreChanged(PropertyChangeEvent event) {
        String p = event.getProperty();
        if (PREFERENCE_BACKGROUND_COLOR.equals(p)
         || PREFERENCE_BACKGROUND_DEFAULT_COLOR.equals(p)) {
            updateBackgroundColor();
        } else if (textTools.affectsPresentation(event)) {
            invalidateTextPresentation();
        }
    }

    /**
     * Updates the background color of the merge viewer to the value set in the
     * preferences.
     */
    private void updateBackgroundColor() {
        boolean defaultBackgroundColor = preferenceStore.getBoolean(
            PREFERENCE_BACKGROUND_DEFAULT_COLOR);
        if (defaultBackgroundColor) {
            setBackgroundColor(null);
        } else {
            RGB backgroundColor = PreferenceConverter.getColor(
                preferenceStore, CssEditorPreferences.EDITOR_BACKGROUND_COLOR);
            setBackgroundColor(backgroundColor);
        }
    }

}
