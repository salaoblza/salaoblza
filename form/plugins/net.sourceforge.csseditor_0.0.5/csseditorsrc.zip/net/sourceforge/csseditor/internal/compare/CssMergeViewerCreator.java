/*
 * Copyright (c) 2003 Christopher Lenz and others.
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 * 
 * Contributors:
 *     Christopher Lenz - initial API and implementation
 * 
 * $Id: CssMergeViewerCreator.java,v 1.2 2004/01/13 17:10:28 cell Exp $
 */

package net.sourceforge.csseditor.internal.compare;

import org.eclipse.compare.CompareConfiguration;
import org.eclipse.compare.IViewerCreator;
import org.eclipse.jface.viewers.Viewer;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Composite;

/**
 * Factory for creating a CSS merge viewer.
 */
public class CssMergeViewerCreator implements IViewerCreator {

    /*
     * @see IViewerCreator#createViewer(Composite, CompareConfiguration)
     */
    public Viewer createViewer(Composite parent, CompareConfiguration config) {
        return new CssMergeViewer(parent, SWT.NULL, config);
    }

}
