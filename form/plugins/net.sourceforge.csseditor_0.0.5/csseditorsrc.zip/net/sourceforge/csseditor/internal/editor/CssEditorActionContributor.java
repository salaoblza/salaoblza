/*
 * Copyright (c) 2003 Christopher Lenz and others.
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 * 
 * Contributors:
 *     Christopher Lenz - initial API and implementation
 * 
 * $Id: CssEditorActionContributor.java,v 1.3 2004/01/13 14:14:53 cell Exp $
 */

package net.sourceforge.csseditor.internal.editor;

import org.eclipse.jface.action.IMenuManager;
import org.eclipse.jface.action.IToolBarManager;
import org.eclipse.jface.action.Separator;
import org.eclipse.ui.IActionBars;
import org.eclipse.ui.IEditorPart;
import org.eclipse.ui.IWorkbenchActionConstants;
import org.eclipse.ui.texteditor.BasicTextEditorActionContributor;
import org.eclipse.ui.texteditor.ITextEditor;
import org.eclipse.ui.texteditor.ITextEditorActionConstants;
import org.eclipse.ui.texteditor.ITextEditorActionDefinitionIds;
import org.eclipse.ui.texteditor.RetargetTextEditorAction;

import net.sourceforge.csseditor.internal.CssEditorMessages;
import net.sourceforge.csseditor.internal.ICssEditorActionConstants;
import net.sourceforge.csseditor.internal.ICssEditorActionDefinitionIds;

/**
 * 
 */
public class CssEditorActionContributor
    extends BasicTextEditorActionContributor {

    // Instance Variables ------------------------------------------------------

    private RetargetTextEditorAction contentAssistAction =
        new RetargetTextEditorAction(CssEditorMessages.getResourceBundle(),
            "CssEditor.contentAssistProposal."); //$NON-NLS-1$

    private ShowSelectedElementOnlyAction showSelectedElementOnlyAction = 
        new ShowSelectedElementOnlyAction(); //$NON-NLS-1$

    // IEditorActionBarContributor Implementation ------------------------------

    /**
     * @see org.eclipse.ui.part.EditorActionBarContributor#contributeToMenu(IMenuManager)
     */
    public void contributeToMenu(IMenuManager menu) {
        super.contributeToMenu(menu);
        IMenuManager editMenu = menu.findMenuUsingPath(
            IWorkbenchActionConstants.M_EDIT);
        if (editMenu != null) {
            editMenu.add(new Separator());
            editMenu.add(this.contentAssistAction);
        }
    }

    /**
     * @see org.eclipse.ui.part.EditorActionBarContributor#contributeToToolBar(IToolBarManager)
     */
    public void contributeToToolBar(IToolBarManager toolBarManager) {
        super.contributeToToolBar(toolBarManager);
        if (toolBarManager != null) {
            toolBarManager.add(new Separator());
        }
    }

    /**
     * @see org.eclipse.ui.IEditorActionBarContributor#dispose()
     */
    public void dispose() {
        doSetActiveEditor(null);
        super.dispose();
    }

    /**
     * @see org.eclipse.ui.IEditorActionBarContributor#setActiveEditor(IEditorPart)
     */
    public void setActiveEditor(IEditorPart part) {
        super.setActiveEditor(part);
        doSetActiveEditor(part);
    }

    // Private Methods ---------------------------------------------------------

    private void doSetActiveEditor(IEditorPart part) {
        ITextEditor editor = null;
        if (part instanceof ITextEditor) {
            editor = (ITextEditor) part;
        }

        contentAssistAction.setAction(
            getAction(editor, ICssEditorActionConstants.CONTENT_ASSIST));

        showSelectedElementOnlyAction.setEditor(editor);
        showSelectedElementOnlyAction.update();

        IActionBars bars = getActionBars();      
        bars.setGlobalActionHandler(
            ITextEditorActionDefinitionIds.TOGGLE_SHOW_SELECTED_ELEMENT_ONLY,
            showSelectedElementOnlyAction);
        bars.setGlobalActionHandler(
            ICssEditorActionDefinitionIds.COMMENT,
            getAction(editor, ICssEditorActionConstants.COMMENT));
        bars.setGlobalActionHandler(
            ICssEditorActionDefinitionIds.UNCOMMENT,
            getAction(editor, ICssEditorActionConstants.UNCOMMENT));
        bars.setGlobalActionHandler(
            ITextEditorActionDefinitionIds.SHIFT_LEFT,
            getAction(editor, ITextEditorActionConstants.SHIFT_LEFT));
        bars.setGlobalActionHandler(
            ITextEditorActionDefinitionIds.SHIFT_RIGHT,
            getAction(editor, ITextEditorActionConstants.SHIFT_RIGHT));
    }

}
