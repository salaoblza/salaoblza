/*
 * Copyright (c) 2003 Christopher Lenz and others.
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 * 
 * Contributors:
 *     Christopher Lenz - initial API and implementation
 * 
 * $Id: CssColorManager.java,v 1.2 2003/12/27 16:53:09 cell Exp $
 */

package net.sourceforge.csseditor.internal.text;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.RGB;
import org.eclipse.swt.widgets.Display;

import net.sourceforge.csseditor.text.IColorManager;

/**
 * CSS color manager.
 */
public class CssColorManager implements IColorManager {

    // Instance Variables ------------------------------------------------------

    private Map keyTable = new HashMap(10);

    private Map displayTable = new HashMap(2);

    /** 
     * Flag which tells if the colors are automatically disposed when the
     * current display gets disposed.
     */
    private boolean autoDisposeOnDisplayDispose;

    // Constructors ------------------------------------------------------------

    /**
     * Creates a new CSS color manager which automatically disposes the
     * allocated colors when the current display gets disposed.
     */ 
    public CssColorManager() {
        this(true);
    }

    /**
     * Creates a new CSS color manager.
     * 
     * @param autoDisposeOnDisplayDispose if <code>true</code> the color manager
     *        automatically disposes all managed colors when the current display
     *        gets disposed and all calls to {@link ISharedTextColors#dispose()}
     *        are ignored.
     */
    public CssColorManager(boolean autoDisposeOnDisplayDispose) {
        this.autoDisposeOnDisplayDispose = autoDisposeOnDisplayDispose;
    }
    
    // IColorManager Implementation --------------------------------------------

    /*
     * @see ISharedTextColors#dispose()
     */
    public void dispose() {
        if (!this.autoDisposeOnDisplayDispose) {
            dispose(Display.getCurrent());
        }
    }
    
    /*
     * @see ISharedTextColors#getColor(RGB)
     */
    public Color getColor(RGB rgb) {
        if (rgb == null) {
            return null;
        }
        final Display display = Display.getCurrent();
        Map colorTable = (Map) this.displayTable.get(display);
        if (colorTable == null) {
            colorTable = new HashMap(10);
            this.displayTable.put(display, colorTable);
            if (this.autoDisposeOnDisplayDispose) {
                display.disposeExec(new Runnable() {
                    public void run() {
                        dispose(display);
                    }
                });
            }
        }
        Color color = (Color) colorTable.get(rgb);
        if (color == null) {
            color = new Color(Display.getCurrent(), rgb);
            colorTable.put(rgb, color);
        }
        return color;
    }

    /*
     * @see IColorManager#bindColor(String, RGB)
     */
    public void bindColor(String key, RGB rgb) {
        Object value = this.keyTable.get(key);
        if (value != null) {
            throw new IllegalStateException();
        }
        this.keyTable.put(key, rgb);
    }

    /*
     * @see IColorManager#getColor(String)
     */
    public Color getColor(String key) {
        if (key == null) {
            return null;
        }
        RGB rgb = (RGB) this.keyTable.get(key);
        return getColor(rgb);
    }

    /*
     * @see IColorManager#unbindColor(String)
     */
    public void unbindColor(String key) {
        this.keyTable.remove(key);
    }

    // Private Methods ---------------------------------------------------------

    private void dispose(Display display) {
        Map colorTable = (Map) this.displayTable.get(display);
        if (colorTable != null) {
            for (Iterator i = colorTable.values().iterator(); i.hasNext(); ) {
                Color color = (Color) i.next();
                if (color != null && !color.isDisposed()) {
                    color.dispose();
                }
            }
        }
    }
    
}
