/*
 * Copyright (c) 2003 Christopher Lenz and others.
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 * 
 * Contributors:
 *     Christopher Lenz - initial API and implementation
 * 
 * $Id: CssCodeScanner.java,v 1.2 2003/12/27 16:53:09 cell Exp $
 */

package net.sourceforge.csseditor.internal.text;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.eclipse.jface.preference.IPreferenceStore;
import org.eclipse.jface.text.rules.ICharacterScanner;
import org.eclipse.jface.text.rules.IRule;
import org.eclipse.jface.text.rules.IToken;
import org.eclipse.jface.text.rules.IWhitespaceDetector;
import org.eclipse.jface.text.rules.Token;
import org.eclipse.jface.text.rules.WhitespaceRule;

import net.sourceforge.csseditor.IProfile;
import net.sourceforge.csseditor.internal.CssEditorPreferences;
import net.sourceforge.csseditor.internal.CssTextUtils;
import net.sourceforge.csseditor.text.IColorManager;

/**
 * Rule based scanner responsible for syntax highlighting CSS source.
 */
public class CssCodeScanner extends AbstractCssScanner {

    // Inner Classes -----------------------------------------------------------

    /**
     * Custom rule that detects the SGML/XML comment delimiters
     * (<code>&lt;!--</code> and <code>--&gt;</code> which are allowed at the 
     * beginning and the end of CSS content.
     */
    private class CdoCdcRule implements IRule {

        /**
         * The associated token.
         */
        private IToken token;

        /**
         * Constructor.
         * 
         * @param token the associated token
         */
        public CdoCdcRule(IToken token) {
            this.token = token;
        }

        /**
         * @see IRule#evaluate(ICharacterScanner)
         */
        public synchronized IToken evaluate(ICharacterScanner scanner) {
            IToken retVal = Token.UNDEFINED;
            int count = 1;
            int c = scanner.read();
            if (c == '<') {
                count++;
                c = scanner.read();
                if (c == '!') {
                    count++;
                    c = scanner.read();
                    if (c == '-') {
                        count++;
                        c = scanner.read();
                        if (c == '-') {
                            return this.token;
                        }
                    }
                }
            } else if (c == '-') {
                count++;
                c = scanner.read();
                if (c == '-') {
                    count++;
                    c = scanner.read();
                    if (c == '>') {
                        return this.token;
                    }
                }
            }
            while (count-- > 0) {
                scanner.unread();
            }
            return retVal;
        }
        
    }

    /**
     * Custom rule that can detect an at-keyword such as <code>@import</code>.
     */
    private class AtKeywordRule implements IRule {

        /**
         * The associated token.
         */
        private IToken token;

        /**
         * Collection of known at-keywords.
         */
        private Collection atKeywords;

        /**
         * Constructor.
         * 
         * @param token the associated token
         */
        public AtKeywordRule(IToken token) {
            this.token = token;
            this.atKeywords = getProfile().getAtKeywords();
        }

        /**
         * @see IRule#evaluate(ICharacterScanner)
         */
        public synchronized IToken evaluate(ICharacterScanner scanner) {
            IToken retVal = Token.UNDEFINED;
            int count = 1;
            int c = scanner.read();
            if (c == '@') {
                c = scanner.read();
                if (CssTextUtils.isCssIdentifierStart((char) c)) {
                    resetBuffer();
                    do {
                        appendToBuffer((char) c);
                        c = scanner.read();
                        count++;
                    } while (CssTextUtils.isCssIdentifierPart((char) c));
                    String candidate = getBufferContent().toLowerCase();
                    if (this.atKeywords.contains(candidate)) {
                        return this.token;
                    }
                }
            }
            while (count-- > 0) {
                scanner.unread();
            }
            return retVal;
        }
        
    }

    /**
     * Custom rule that can detect a known property.
     */
    private class PropertyRule implements IRule {

        /**
         * The associated token.
         */
        private IToken fToken;

        /**
         * Collection of known properties.
         */
        private Collection fProperties;

        /**
         * Constructor.
         * 
         * @param token the associated token
         */
        public PropertyRule(IToken token) {
            this.fToken = token;
            this.fProperties = getProfile().getProperties();
        }

        /**
         * @see IRule#evaluate(ICharacterScanner)
         */
        public synchronized IToken evaluate(ICharacterScanner scanner) {
            IToken retVal = Token.UNDEFINED;
            int count = 1;
            int c = scanner.read();
            if (CssTextUtils.isCssIdentifierStart((char) c)) {
                resetBuffer();
                do {
                    appendToBuffer((char) c);
                    c = scanner.read();
                    count++;
                } while (CssTextUtils.isCssIdentifierPart((char) c));
                String candidate = getBufferContent().toLowerCase();
                if (this.fProperties.contains(candidate)) {
                    while (CssTextUtils.isCssWhitespace((char) c)) {
                        c = scanner.read();
                        count++;
                    }
                    if (c == ':') {
                        scanner.unread();
                        return this.fToken;
                    }
                }
            }
            while (count-- > 0) {
                scanner.unread();
            }
            return retVal;
        }
        
    }

    /**
     * Custom rule that can detect a pseudo-class in a selector.
     */
    private class PseudoClassRule implements IRule {

        /**
         * The associated token.
         */
        private IToken token;

        /**
         * Collection of known pseudo-classes.
         */
        private Collection pseudoClasses;

        /**
         * Constructor.
         * 
         * @param token the associated token
         */
        public PseudoClassRule(IToken token) {
            this.token = token;
            this.pseudoClasses = getProfile().getPseudoClassNames();
        }

        /**
         * @see IRule#evaluate(ICharacterScanner)
         */
        public synchronized IToken evaluate(ICharacterScanner scanner) {
            IToken retVal = Token.UNDEFINED;
            int count = 1;
            int c = scanner.read();
            if (c == ':') {
                c = scanner.read();
                if (CssTextUtils.isCssIdentifierStart((char) c)) {
                    resetBuffer();
                    do {
                        appendToBuffer((char) c);
                        c = scanner.read();
                        count++;
                    } while (CssTextUtils.isCssIdentifierPart((char) c));
                    String candidate = getBufferContent().toLowerCase();
                    if (this.pseudoClasses.contains(candidate)) {
                        return this.token;
                    }
                }
            }
            while (count-- > 0) {
                scanner.unread();
            }
            return retVal;
        }
        
    }

    /**
     * Detects CSS white space.
     */
    private static class WhitespaceDetector implements IWhitespaceDetector {

        /**
         * @see IWhitespaceDetector#isWhitespace
         */
        public boolean isWhitespace(char c) {
            return CssTextUtils.isCssWhitespace(c);
        }

    }

    // Instance Variables ------------------------------------------------------

    /**
     * The current CSS profile.
     */
    private IProfile fProfile;

    /**
     * Shared buffer used by the word detectors.
     */
    private StringBuffer fBuffer = new StringBuffer();

    // Constructors ------------------------------------------------------------

    /**
     * Constructor.
     * 
     * @param store The preference store
     * @param manager The color manager
     * @param profile The CSS profile to use
     */
    public CssCodeScanner(IPreferenceStore store, IColorManager manager, 
        IProfile profile) {
        super(store, manager);
        this.fProfile = profile;

        List rules = new ArrayList();

        rules.add(new WhitespaceRule(new WhitespaceDetector()));

        rules.add(new CdoCdcRule(createToken(
            CssEditorPreferences.EDITOR_COMMENT_COLOR,
            CssEditorPreferences.EDITOR_COMMENT_BOLD)));
        rules.add(new AtKeywordRule(createToken(
            CssEditorPreferences.EDITOR_AT_KEYWORD_COLOR,
            CssEditorPreferences.EDITOR_AT_KEYWORD_BOLD)));
        rules.add(new PropertyRule(createToken(
            CssEditorPreferences.EDITOR_PROPERTY_COLOR,
            CssEditorPreferences.EDITOR_PROPERTY_BOLD)));
        rules.add(new PseudoClassRule(createToken(
            CssEditorPreferences.EDITOR_PSEUDO_CLASS_COLOR,
            CssEditorPreferences.EDITOR_PSEUDO_CLASS_BOLD)));

        setRules((IRule[]) rules.toArray(new IRule[rules.size()]));

        setDefaultReturnToken(createToken(
            CssEditorPreferences.EDITOR_DEFAULT_COLOR,
            CssEditorPreferences.EDITOR_DEFAULT_BOLD));
    }

    // Private Methods ---------------------------------------------------------

    private IProfile getProfile() {
        return this.fProfile;
    }

    private void appendToBuffer(char c) {
        this.fBuffer.append(c);
    }

    private String getBufferContent() {
        return this.fBuffer.toString();
    }
    
    private void resetBuffer() {
        this.fBuffer.setLength(0);
    }

}
