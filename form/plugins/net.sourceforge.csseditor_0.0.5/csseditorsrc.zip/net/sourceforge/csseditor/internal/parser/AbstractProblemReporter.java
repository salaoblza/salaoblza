/*
 * Copyright (c) 2003 Christopher Lenz and others.
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 * 
 * Contributors:
 *     Christopher Lenz - initial API and implementation
 * 
 * $Id: AbstractProblemReporter.java,v 1.2 2003/12/27 18:46:55 cell Exp $
 */

package net.sourceforge.csseditor.internal.parser;

import org.eclipse.jface.text.BadLocationException;
import org.eclipse.jface.text.IDocument;
import org.eclipse.jface.text.IRegion;

import net.sourceforge.csseditor.internal.CssEditorMessages;
import net.sourceforge.csseditor.parser.IProblem;
import net.sourceforge.csseditor.parser.IProblemCollector;

/**
 * 
 */
public abstract class AbstractProblemReporter {

    // Instance Variables ------------------------------------------------------

    protected IDocument fDocument;

    protected IProblemCollector fProblemCollector = new IProblemCollector() {
        public void addProblem(IProblem problem) {
            // do nothing
        }
    };

    // Public Methods ----------------------------------------------------------

    /**
     * @see IProblemReporter#setProblemCollector(IProblemCollector)
     */
    public void setProblemCollector(IProblemCollector problemCollector) {
        fProblemCollector = problemCollector;
    }

    // Protected Methods -------------------------------------------------------

    protected final IProblem createError(String id, IRegion region) {
        return createError(id, new String[0], region);
    }

    protected final IProblem createError(String id, String arg,
        IRegion region) {
        return createError(id, new String[] {arg}, region);
    }

    protected final IProblem createError(String id, String args[],
        IRegion region) {
        return createProblem(id, args, region, true);
    }

    protected final IProblem createWarning(String id, IRegion region) {
        return createWarning(id, new String[0], region);
    }

    protected final IProblem createWarning(String id, String arg,
        IRegion region) {
        return createWarning(id, new String[] {arg}, region);
    }

    protected final IProblem createWarning(String id, String args[],
        IRegion region) {
        return createProblem(id, args, region, false);
    }

    protected final IProblem reportError(String id, IRegion region) {
        return reportProblem(createError(id, region));
    }

    protected final IProblem reportError(String id, String arg,
        IRegion region) {
        return reportProblem(createError(id, arg, region));
    }

    protected final IProblem reportError(String id, String args[],
        IRegion region) {
        return reportProblem(createError(id, args, region));
    }

    protected final IProblem reportWarning(String id, IRegion region) {
        return reportProblem(createWarning(id, region));
    }

    protected final IProblem reportWarning(String id, String arg,
        IRegion region) {
        return reportProblem(createWarning(id, arg, region));
    }

    protected final IProblem reportWarning(String id, String args[],
        IRegion region) {
        return reportProblem(createWarning(id, args, region));
    }

    protected final IProblem reportProblem(IProblem problem) {
        fProblemCollector.addProblem(problem);
        return problem;
    }

    protected final void setDocument(IDocument document) {
        fDocument = document;
    }

    // Private Methods ---------------------------------------------------------

    private final IProblem createProblem(String id, String args[],
        IRegion region, boolean error) {
        String message = CssEditorMessages.getString(
            "CssParser.problem." + id, args); //$NON-NLS-1$
        int offset = region.getOffset();
        int lineNumber = -1;
        try {
            lineNumber = fDocument.getLineOfOffset(offset);
        } catch (BadLocationException e) {
            // ignore
        }
        return new DefaultProblem(id, message, null, offset,
            offset + region.getLength(), lineNumber, error);
    }

}
