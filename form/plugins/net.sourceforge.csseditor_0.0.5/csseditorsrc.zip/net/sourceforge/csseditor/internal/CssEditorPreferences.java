/*
 * Copyright (c) 2003 Christopher Lenz and others.
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 * 
 * Contributors:
 *     Christopher Lenz - initial API and implementation
 * 
 * $Id: CssEditorPreferences.java,v 1.2 2004/06/25 09:51:23 cell Exp $
 */

package net.sourceforge.csseditor.internal;

import org.eclipse.jface.preference.IPreferenceStore;
import org.eclipse.jface.preference.PreferenceConverter;
import org.eclipse.swt.graphics.RGB;
import org.eclipse.ui.texteditor.AbstractTextEditor;
import org.eclipse.ui.texteditor.AbstractDecoratedTextEditorPreferenceConstants;

/**
 * 
 */
public final class CssEditorPreferences {

    // Constants ---------------------------------------------------------------

    // TODO Make this a core preference
    public static final String PROFILE =
        "profile"; //$NON-NLS-1$

    // Inherited constants

    public static final String EDITOR_CURRENT_LINE =
        AbstractDecoratedTextEditorPreferenceConstants.EDITOR_CURRENT_LINE;

    public static final String EDITOR_CURRENT_LINE_COLOR =
        AbstractDecoratedTextEditorPreferenceConstants.EDITOR_CURRENT_LINE_COLOR;

    public static final String EDITOR_LINE_NUMBER_RULER =
        AbstractDecoratedTextEditorPreferenceConstants.EDITOR_LINE_NUMBER_RULER;

    public static final String EDITOR_LINE_NUMBER_RULER_COLOR =
        AbstractDecoratedTextEditorPreferenceConstants.EDITOR_LINE_NUMBER_RULER_COLOR;

    public static final String EDITOR_PRINT_MARGIN =
        AbstractDecoratedTextEditorPreferenceConstants.EDITOR_PRINT_MARGIN;

    public static final String EDITOR_PRINT_MARGIN_COLOR =
        AbstractDecoratedTextEditorPreferenceConstants.EDITOR_PRINT_MARGIN_COLOR;

    public static final String EDITOR_PRINT_MARGIN_COLUMN =
        AbstractDecoratedTextEditorPreferenceConstants.EDITOR_PRINT_MARGIN_COLUMN;

    public static final String EDITOR_OVERVIEW_RULER =
        AbstractDecoratedTextEditorPreferenceConstants.EDITOR_OVERVIEW_RULER;

    public static final String EDITOR_BACKGROUND_DEFAULT_COLOR =
        AbstractTextEditor.PREFERENCE_COLOR_BACKGROUND_SYSTEM_DEFAULT;

    public static final String EDITOR_BACKGROUND_COLOR =
        AbstractTextEditor.PREFERENCE_COLOR_BACKGROUND;

    public static final String EDITOR_FOREGROUND_COLOR =
        AbstractTextEditor.PREFERENCE_COLOR_FOREGROUND;

    public static final String EDITOR_FOREGROUND_DEFAULT_COLOR =
        AbstractTextEditor.PREFERENCE_COLOR_FOREGROUND_SYSTEM_DEFAULT;

    // Custom constants

    public static final String EDITOR_TAB_WIDTH =
        "tabWidth"; //$NON-NLS-1$

    public static final String EDITOR_MATCHING_BRACKETS =
        "matchingBrackets"; //$NON-NLS-1$

    public static final String EDITOR_MATCHING_BRACKETS_COLOR =
        "matchingBracketsColor"; //$NON-NLS-1$

    public static final String EDITOR_COMMENT_COLOR =
        "commentColor"; //$NON-NLS-1$

    public static final String EDITOR_COMMENT_BOLD =
        "commentBold"; //$NON-NLS-1$

    public static final String EDITOR_PROPERTY_COLOR =
        "propertyColor"; //$NON-NLS-1$

    public static final String EDITOR_PROPERTY_BOLD =
        "propertyBold"; //$NON-NLS-1$

    public static final String EDITOR_AT_KEYWORD_COLOR =
        "atKeywordColor"; //$NON-NLS-1$

    public static final String EDITOR_AT_KEYWORD_BOLD =
        "atKeywordBold"; //$NON-NLS-1$

    public static final String EDITOR_PSEUDO_CLASS_COLOR =
        "pseudoClassColor"; //$NON-NLS-1$

    public static final String EDITOR_PSEUDO_CLASS_BOLD =
        "pseudoClassBold"; //$NON-NLS-1$

    public static final String EDITOR_STRING_COLOR =
        "stringColor"; //$NON-NLS-1$

    public static final String EDITOR_STRING_BOLD =
        "stringBold"; //$NON-NLS-1$

    public static final String EDITOR_DEFAULT_COLOR =
        "defaultColor"; //$NON-NLS-1$

    public static final String EDITOR_DEFAULT_BOLD =
        "defaultBold"; //$NON-NLS-1$

    public static final String EDITOR_SPACES_FOR_TABS =
        "spacesForTabs"; //$NON-NLS-1$

    public static final String EDITOR_CLOSE_STRINGS =
        "closeStrings"; //$NON-NLS-1$

    public static final String EDITOR_CLOSE_BRACKETS_AND_PARENS =
        "closeBracketsAndParens"; //$NON-NLS-1$

    public static final String EDITOR_CLOSE_BRACES =
        "closeBraces"; //$NON-NLS-1$

    public static final String EDITOR_SHOW_SELECTED_ELEMENT_ONLY =
        "showSelectedElementOnly"; //$NON-NLS-1$

    public static final String OUTLINE_LINK_WITH_EDITOR =
        "linkOutlineWithEditor"; //$NON-NLS-1$

    public static final String OUTLINE_SORT_LEXICALLY =
        "sortOutlineLexically"; //$NON-NLS-1$

    public static final String CONTENTASSIST_AUTOACTIVATION =
        "contentAssistAutoActivation"; //$NON-NLS-1$

    public static final String CONTENTASSIST_AUTOACTIVATION_DELAY =
        "contentAssistAutoActivationDelay"; //$NON-NLS-1$

    public static final String CONTENTASSIST_AUTOACTIVATION_TRIGGERS =
        "contentAssistAutoActivationTriggers"; //$NON-NLS-1$

    public static final String CONTENTASSIST_AUTOINSERT =
        "contentAssistAutoInsert"; //$NON-NLS-1$

    public static final String CONTENTASSIST_ORDER_PROPOSALS =
        "contentAssistOrderProposals"; //$NON-NLS-1$

    public static final String CONTENTASSIST_PROPOSALS_BACKGROUND =
        "contentAssistProposalsBackground"; //$NON-NLS-1$

    public static final String CONTENTASSIST_PROPOSALS_FOREGROUND =
        "contentAssistProposalsForeground"; //$NON-NLS-1$

    // Constructors ------------------------------------------------------------

    /**
     * Hidden constructor.
     */
    private CssEditorPreferences() {
        // Hidden
    }

    // Public Methods ----------------------------------------------------------

    /**
     * Initializes the preference store with the default values.
     * 
     * @param store The preference store to initialize
     */
    public static final void initializeDefaultValues(IPreferenceStore store) {

        // General
        store.setDefault(PROFILE,
            "net.sourceforge.csseditor.profiles.css2"); //$NON-NLS-1$
        
        // Appearance
        store.setDefault(EDITOR_TAB_WIDTH, 4);
        store.setDefault(EDITOR_MATCHING_BRACKETS, true);
        PreferenceConverter.setDefault(store, EDITOR_MATCHING_BRACKETS_COLOR,
            new RGB(192, 192, 192));

        // Syntax
        store.setDefault(EDITOR_FOREGROUND_DEFAULT_COLOR, true);
        store.setDefault(EDITOR_BACKGROUND_DEFAULT_COLOR, true);
        PreferenceConverter.setDefault(store, EDITOR_COMMENT_COLOR,
            new RGB(63, 127, 95));
        store.setDefault(EDITOR_COMMENT_BOLD, false);
        PreferenceConverter.setDefault(store, EDITOR_PROPERTY_COLOR,
            new RGB(127, 0, 85));
        store.setDefault(EDITOR_PROPERTY_BOLD, true);
        PreferenceConverter.setDefault(store, EDITOR_AT_KEYWORD_COLOR,
            new RGB(127, 0, 85));
        store.setDefault(EDITOR_AT_KEYWORD_BOLD, true);
        PreferenceConverter.setDefault(store, EDITOR_PSEUDO_CLASS_COLOR,
            new RGB(0, 0, 0));
        store.setDefault(EDITOR_PSEUDO_CLASS_BOLD, false);
        PreferenceConverter.setDefault(store, EDITOR_STRING_COLOR,
            new RGB(42, 0, 255));
        store.setDefault(EDITOR_STRING_BOLD, false);
        PreferenceConverter.setDefault(store, EDITOR_DEFAULT_COLOR,
            new RGB(0, 0, 0));
        store.setDefault(EDITOR_DEFAULT_BOLD, false);

        // Content assist
        store.setDefault(CONTENTASSIST_AUTOINSERT, false);
        store.setDefault(CONTENTASSIST_ORDER_PROPOSALS, false);
        store.setDefault(CONTENTASSIST_AUTOACTIVATION, true);
        store.setDefault(CONTENTASSIST_AUTOACTIVATION_DELAY, 500);
        store.setDefault(CONTENTASSIST_AUTOACTIVATION_TRIGGERS,
            "-@:"); //$NON-NLS-1$
        PreferenceConverter.setDefault(store,
            CONTENTASSIST_PROPOSALS_BACKGROUND, new RGB(254, 241, 233));
        PreferenceConverter.setDefault(store,
            CONTENTASSIST_PROPOSALS_FOREGROUND, new RGB(0, 0, 0));

        // Typing
        store.setDefault(EDITOR_TAB_WIDTH, 4);
        store.setDefault(EDITOR_SPACES_FOR_TABS, false);
        store.setDefault(EDITOR_CLOSE_STRINGS, true);
        store.setDefault(EDITOR_CLOSE_BRACKETS_AND_PARENS, true);
        store.setDefault(EDITOR_CLOSE_BRACES, true);

        // Outline
        store.setDefault(OUTLINE_SORT_LEXICALLY, false);
        store.setDefault(OUTLINE_LINK_WITH_EDITOR, false);
    }

}
