/*
 * Copyright (c) 2003 Christopher Lenz and others.
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 * 
 * Contributors:
 *     Christopher Lenz - initial API and implementation
 * 
 * $Id: ShowSelectedElementOnlyAction.java,v 1.3 2004/01/13 17:06:30 cell Exp $
 */

package net.sourceforge.csseditor.internal.editor;

import org.eclipse.jface.preference.IPreferenceStore;
import org.eclipse.jface.text.IRegion;
import org.eclipse.jface.util.IPropertyChangeListener;
import org.eclipse.jface.util.PropertyChangeEvent;
import org.eclipse.ui.texteditor.ITextEditor;
import org.eclipse.ui.texteditor.TextEditorAction;

import net.sourceforge.csseditor.CssEditorPlugin;
import net.sourceforge.csseditor.internal.CssEditorMessages;
import net.sourceforge.csseditor.internal.CssEditorPreferences;

/**
 * A toolbar action which toggles the presentation model of the connected text 
 * editor. The editor shows either the highlight range only or always the whole 
 * document.
 * 
 * <p>
 *   This class is an implementation for the retargetable action 
 *   <code>TOGGLE_SHOW_SELECTED_ELEMENT_ONLY</code> provided by the platform.
 * </p>
 * 
 * @see org.eclipse.ui.texteditor.ITextEditorActionDefinitionIds#TOGGLE_SHOW_SELECTED_ELEMENT_ONLY
 */
public class ShowSelectedElementOnlyAction extends TextEditorAction
    implements IPropertyChangeListener {

    // Instance Variables ------------------------------------------------------

    private IPreferenceStore store;

    // Constructors ------------------------------------------------------------

    /**
     * Constructor.
     */
    public ShowSelectedElementOnlyAction() {
        super(CssEditorMessages.getResourceBundle(),
            "CssEditor.showSelectedElementOnly.", null); //$NON-NLS-1$
        store = CssEditorPlugin.getDefault().getPreferenceStore();
        update();
    }

    // TextEditor Implementation -----------------------------------------------

    /*
     * @see org.eclipse.jface.action.IAction#run()
     */
    public void run() {
        ITextEditor editor = getTextEditor();
        if (editor != null) {
            IRegion highlightRange = editor.getHighlightRange();
            editor.resetHighlightRange();
            boolean show = !editor.showsHighlightRangeOnly();
            setChecked(show);
            editor.showHighlightRangeOnly(show);
            if (highlightRange != null) {
                editor.setHighlightRange(highlightRange.getOffset(),
                    highlightRange.getLength(), true);
            }
            store.removePropertyChangeListener(this);
            store.setValue(
                CssEditorPreferences.EDITOR_SHOW_SELECTED_ELEMENT_ONLY, show);
            store.addPropertyChangeListener(this);
        }
    }

    /*
     * @see TextEditorAction#setEditor(ITextEditor)
     */
    public void setEditor(ITextEditor editor) {
        super.setEditor(editor);
        if (editor != null) {
            if (store == null) {
                store = CssEditorPlugin.getDefault().getPreferenceStore();
                store.addPropertyChangeListener(this);
            }
            synchronizeWithPreference(editor);
        } else if (store != null) {
            store.removePropertyChangeListener(this);
            store = null;
        }
        update();
    }
    
    /*
     * @see org.eclipse.ui.texteditor.IUpdate#update()
     */
    public void update() {
        ITextEditor editor = getTextEditor();
        if (editor != null) {
            setChecked(getTextEditor().showsHighlightRangeOnly());
            setEnabled(true);
        } else {
            setEnabled(false);
        }
    }

    // IPropertyChangeListener Implementation ----------------------------------

    /*
     * @see IPropertyChangeListener#propertyChange(PropertyChangeEvent)
     */
    public void propertyChange(PropertyChangeEvent event) {
        String p = event.getProperty();
        if (CssEditorPreferences.EDITOR_SHOW_SELECTED_ELEMENT_ONLY.equals(p)) {
            synchronizeWithPreference(getTextEditor());
        }
    }

    // Private Methods ---------------------------------------------------------

    /**
     * Synchronizes the appearance of the editor with what the preference store
     * contains.
     * 
     * @param editor the editor to synchronize
     */
    private void synchronizeWithPreference(ITextEditor editor) {
        if (editor != null) {
            boolean show = this.store.getBoolean(
                CssEditorPreferences.EDITOR_SHOW_SELECTED_ELEMENT_ONLY);
            setChecked(show);
            if (show != editor.showsHighlightRangeOnly()) {
                IRegion highlightRange = editor.getHighlightRange();
                editor.resetHighlightRange();
                editor.showHighlightRangeOnly(show);
                if (highlightRange != null) {
                    editor.setHighlightRange(highlightRange.getOffset(),
                        highlightRange.getLength(), true);
                }
            }
        }
    }


}
