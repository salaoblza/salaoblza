/*
 * Copyright (c) 2003 Christopher Lenz and others.
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 * 
 * Contributors:
 *     Christopher Lenz - initial API and implementation
 * 
 * $Id: AbstractRule.java,v 1.3 2004/01/13 13:54:05 cell Exp $
 */

package net.sourceforge.csseditor.internal.model;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.eclipse.core.runtime.IAdaptable;
import org.eclipse.jface.text.IDocument;
import org.eclipse.jface.text.IRegion;
import org.eclipse.ui.views.properties.IPropertySource;

import net.sourceforge.csseditor.internal.properties.CssRulePropertySource;
import net.sourceforge.csseditor.model.IDeclaration;
import net.sourceforge.csseditor.model.IRule;
import net.sourceforge.csseditor.model.IStyleSheet;

/**
 * 
 */
public abstract class AbstractRule extends SourceReference
    implements IAdaptable, IRule {

    // Instance Variables ------------------------------------------------------

    private IStyleSheet styleSheet;

    private IRule parent;

    private List children = new ArrayList(); 

    private List declarations = new ArrayList();

    private IPropertySource propertySource;    

    // Constructors ------------------------------------------------------------

    /**
     * Constructor.
     * 
     * @param document the document that contains the rule
     * @param styleSheet the style sheet that contains the rule
     */
    public AbstractRule(IDocument document, IStyleSheet styleSheet) {
        this(document, styleSheet, null);
    }

    /**
     * Constructor.
     * 
     * @param document the document that contains the rule
     * @param styleSheet the style sheet that contains the rule
     * @param parent the parent rule, or <code>null</code> if the rule is at top
     *        level
     */
    public AbstractRule(IDocument document, IStyleSheet styleSheet,
        IRule parent) {
        super(document);
        this.styleSheet = styleSheet;
        this.parent = parent;
    }

    // IStyleRule Implementation -----------------------------------------------

    /*
     * @see IRule#getStyleSheet()
     */
    public final IStyleSheet getStyleSheet() {
        return styleSheet;
    }

    /*
     * @see IRule#getParent()
     */
    public final IRule getParent() {
        return parent;
    }

    /*
     * @see IRule#getChildren()
     */
    public final IRule[] getChildren() {
        return (IRule[]) children.toArray(new IRule[children.size()]);
    }

    /*
     * @see IRule#getDeclarationAt(int)
     */
    public final IDeclaration getDeclarationAt(int offset) {
        for (Iterator i = declarations.iterator(); i.hasNext(); ) {
            IDeclaration declaration = (IDeclaration) i.next();
            IRegion region = declaration.getSourceRegion();
            if ((offset > region.getOffset())
             && (offset < (region.getOffset() + region.getLength()))) {
                return declaration;
            }
        }
        return null;
    }

    /*
     * @see IRule#getDeclarations()
     */
    public final IDeclaration[] getDeclarations() {
        return (IDeclaration[]) declarations.toArray(
            new IDeclaration[declarations.size()]);
    }

    // IAdaptable Implementation -----------------------------------------------

    /*
     * @see IAdaptable#getAdapter(Class)
     */
    public Object getAdapter(Class adapter) {
        if (adapter == IPropertySource.class) {
            if (propertySource == null) {
                propertySource = new CssRulePropertySource(this);
            }
            return propertySource;
        }
        return null;
    }

    // Public Methods ----------------------------------------------------------

    public final void addChild(IRule rule) {
        children.add(rule);
    }

    public final void addDeclaration(IDeclaration declaration) {
        declarations.add(declaration);
    }

}
