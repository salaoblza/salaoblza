/*
 * Copyright (c) 2003 Christopher Lenz and others.
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 * 
 * Contributors:
 *     Christopher Lenz - initial API and implementation
 * 
 * $Id: CssEditorPreferencePage.java,v 1.2 2003/12/27 18:46:56 cell Exp $
 */

package net.sourceforge.csseditor.internal.preferences;

import java.util.Iterator;

import org.eclipse.jface.preference.PreferencePage;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.TabFolder;
import org.eclipse.swt.widgets.TabItem;
import org.eclipse.ui.IWorkbench;
import org.eclipse.ui.IWorkbenchPreferencePage;
import org.eclipse.ui.texteditor.AnnotationPreference;
import org.eclipse.ui.texteditor.MarkerAnnotationPreferences;

import net.sourceforge.csseditor.CssEditorPlugin;
import net.sourceforge.csseditor.internal.CssEditorMessages;
import net.sourceforge.csseditor.internal.CssEditorPreferences;

/**
 * Implements the CSS editor preference page.
 */
public class CssEditorPreferencePage extends PreferencePage
    implements IWorkbenchPreferencePage {

    // Instance Variables ------------------------------------------------------

    private OverlayPreferenceStore fOverlayStore;

    private CssEditorAppearanceConfigurationBlock fAppearanceBlock;
    private CssEditorSyntaxConfigurationBlock fSyntaxBlock;
    private CssEditorContentAssistConfigurationBlock fContentAssistBlock;
    private CssEditorAnnotationsConfigurationBlock fAnnotationsBlock;
    private CssEditorTypingConfigurationBlock fTypingBlock;

    // PreferencePage Implementation -------------------------------------------

    /**
     * @see PreferencePage#createContents
     */
    protected Control createContents(Composite parent) {

        TabFolder folder = new TabFolder(parent, SWT.NONE);
        TabItem item;

        item = new TabItem(folder, SWT.NONE);
        item.setText(getString("appearance")); //$NON-NLS-1$
        item.setControl(createAppearancePage(folder));

        item = new TabItem(folder, SWT.NONE);
        item.setText(getString("syntax")); //$NON-NLS-1$
        item.setControl(createSyntaxPage(folder));

        item = new TabItem(folder, SWT.NONE);
        item.setText(getString("contentAssist")); //$NON-NLS-1$
        item.setControl(createCodeAssistPage(folder));

        item = new TabItem(folder, SWT.NONE);
        item.setText(getString("annotations")); //$NON-NLS-1$
        item.setControl(createAnnotationsPage(folder));

        item = new TabItem(folder, SWT.NONE);
        item.setText(getString("typing")); //$NON-NLS-1$
        item.setControl(createTypingPage(folder));

        return folder;
    }

    /**
     * @see PreferencePage#dispose()
     */
    public void dispose() {
        if (fOverlayStore != null) {
            fOverlayStore.stopListening();
            fOverlayStore = null;
        }
        super.dispose();
    }

    /**
     * @see PreferencePage#performOk()
     */
    public boolean performOk() {
        fOverlayStore.propagate();
        CssEditorPlugin.getDefault().savePluginPreferences();
        return true;
    }

    /**
     * @see PreferencePage#performDefaults()
     */
    protected void performDefaults() {
        fOverlayStore.loadDefaults();
        super.performDefaults();
    }
    
    // IWorkbenchPreferencePage Implementation ---------------------------------

    /**
     * @see IWorkbenchPreferencePage#init
     */
    public void init(IWorkbench workbench) {
        setDescription(getString("description")); //$NON-NLS-1$
        setPreferenceStore(CssEditorPlugin.getDefault().getPreferenceStore());

        MarkerAnnotationPreferences preferences =
            new MarkerAnnotationPreferences();
        fOverlayStore = createOverlayStore(preferences);
        fOverlayStore.load();
        fOverlayStore.startListening();
    }

    // Private Methods ---------------------------------------------------------

    private OverlayPreferenceStore createOverlayStore(
        MarkerAnnotationPreferences preferences) {

        OverlayPreferenceStore store = 
            new OverlayPreferenceStore(getPreferenceStore());

        Iterator e = preferences.getAnnotationPreferences().iterator();
        while (e.hasNext()) {
            AnnotationPreference info = (AnnotationPreference) e.next();
            store.addStringKey(info.getColorPreferenceKey());
            store.addBooleanKey(info.getTextPreferenceKey());
            store.addBooleanKey(info.getOverviewRulerPreferenceKey());
        }

        // Generic
        store.addStringKey(CssEditorPreferences.PROFILE);

        // Appearance
        store.addIntKey(CssEditorPreferences.EDITOR_TAB_WIDTH);
        store.addBooleanKey(CssEditorPreferences.EDITOR_CURRENT_LINE);
        store.addStringKey(CssEditorPreferences.EDITOR_CURRENT_LINE_COLOR);
        store.addBooleanKey(CssEditorPreferences.EDITOR_MATCHING_BRACKETS);
        store.addStringKey(CssEditorPreferences.EDITOR_MATCHING_BRACKETS_COLOR);
        store.addBooleanKey(CssEditorPreferences.EDITOR_PRINT_MARGIN);
        store.addStringKey(CssEditorPreferences.EDITOR_PRINT_MARGIN_COLOR);
        store.addIntKey(CssEditorPreferences.EDITOR_PRINT_MARGIN_COLUMN);
        store.addBooleanKey(CssEditorPreferences.EDITOR_OVERVIEW_RULER);
        store.addStringKey(CssEditorPreferences.EDITOR_LINE_NUMBER_RULER_COLOR);
        store.addBooleanKey(CssEditorPreferences.EDITOR_LINE_NUMBER_RULER);

        // Syntax coloring
        store.addStringKey(CssEditorPreferences.EDITOR_FOREGROUND_COLOR);
        store.addBooleanKey(
            CssEditorPreferences.EDITOR_FOREGROUND_DEFAULT_COLOR);
        store.addStringKey(CssEditorPreferences.EDITOR_BACKGROUND_COLOR);
        store.addBooleanKey(
            CssEditorPreferences.EDITOR_BACKGROUND_DEFAULT_COLOR);
        store.addStringKey(CssEditorPreferences.EDITOR_COMMENT_COLOR);
        store.addBooleanKey(CssEditorPreferences.EDITOR_COMMENT_BOLD);
        store.addStringKey(CssEditorPreferences.EDITOR_STRING_COLOR);
        store.addBooleanKey(CssEditorPreferences.EDITOR_STRING_BOLD);
        store.addStringKey(CssEditorPreferences.EDITOR_PROPERTY_COLOR);
        store.addBooleanKey(CssEditorPreferences.EDITOR_PROPERTY_BOLD);
        store.addStringKey(CssEditorPreferences.EDITOR_AT_KEYWORD_COLOR);
        store.addBooleanKey(CssEditorPreferences.EDITOR_AT_KEYWORD_BOLD);
        store.addStringKey(CssEditorPreferences.EDITOR_PSEUDO_CLASS_COLOR);
        store.addBooleanKey(CssEditorPreferences.EDITOR_PSEUDO_CLASS_BOLD);
        store.addStringKey(CssEditorPreferences.EDITOR_DEFAULT_COLOR);
        store.addBooleanKey(CssEditorPreferences.EDITOR_DEFAULT_BOLD);

        // Content assist
        store.addBooleanKey(CssEditorPreferences.CONTENTASSIST_AUTOINSERT);
        store.addBooleanKey(CssEditorPreferences.CONTENTASSIST_ORDER_PROPOSALS);
        store.addBooleanKey(CssEditorPreferences.CONTENTASSIST_AUTOACTIVATION);
        store.addIntKey(
            CssEditorPreferences.CONTENTASSIST_AUTOACTIVATION_DELAY);
        store.addStringKey(
            CssEditorPreferences.CONTENTASSIST_AUTOACTIVATION_TRIGGERS);
        store.addStringKey(
            CssEditorPreferences.CONTENTASSIST_PROPOSALS_BACKGROUND);
        store.addStringKey(
            CssEditorPreferences.CONTENTASSIST_PROPOSALS_FOREGROUND);

        // Typing
        store.addBooleanKey(CssEditorPreferences.EDITOR_SPACES_FOR_TABS);
        store.addBooleanKey(CssEditorPreferences.EDITOR_CLOSE_STRINGS);
        store.addBooleanKey(
            CssEditorPreferences.EDITOR_CLOSE_BRACKETS_AND_PARENS);
        store.addBooleanKey(CssEditorPreferences.EDITOR_CLOSE_BRACES);

        return store;
    }
    
    private Control createAppearancePage(Composite parent) {
        fAppearanceBlock =
            new CssEditorAppearanceConfigurationBlock(fOverlayStore); 
        return fAppearanceBlock.createControl(parent);
    }

    private Control createSyntaxPage(Composite parent) {
        fSyntaxBlock = new CssEditorSyntaxConfigurationBlock(fOverlayStore); 
        return fSyntaxBlock.createControl(parent);
    }

    private Control createCodeAssistPage(Composite parent) {
        fContentAssistBlock =
            new CssEditorContentAssistConfigurationBlock(fOverlayStore);
        return fContentAssistBlock.createControl(parent);
    }

    private Control createAnnotationsPage(Composite parent) {
        fAnnotationsBlock =
            new CssEditorAnnotationsConfigurationBlock(fOverlayStore); 
        return fAnnotationsBlock.createControl(parent);
    }

    private Control createTypingPage(Composite parent) {
        fTypingBlock = new CssEditorTypingConfigurationBlock(fOverlayStore); 
        return fTypingBlock.createControl(parent);
    }

    private static String getString(String key) {
        return CssEditorMessages.getString(
            "CssEditorPreferencePage." + key); //$NON-NLS-1$
    }

}
