/*
 * Copyright (c) 2003 Christopher Lenz and others.
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 * 
 * Contributors:
 *     Christopher Lenz - initial API and implementation
 * 
 * $Id: CssDocumentProvider.java,v 1.1.1.1 2003/12/14 21:59:33 cell Exp $
 */

package net.sourceforge.csseditor.internal;

import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.jface.text.IDocument;
import org.eclipse.jface.text.IDocumentListener;
import org.eclipse.jface.text.source.IAnnotationModel;
import org.eclipse.ui.IFileEditorInput;
import org.eclipse.ui.editors.text.FileDocumentProvider;

import net.sourceforge.csseditor.CssEditorPlugin;
import net.sourceforge.csseditor.internal.model.StyleSheet;
import net.sourceforge.csseditor.model.IStyleSheet;
import net.sourceforge.csseditor.text.CssTextTools;

/**
 * 
 */
public class CssDocumentProvider extends FileDocumentProvider {

    // Inner Classes -----------------------------------------------------------

    /**
     * 
     */
    private class StyleSheetInfo extends FileInfo {

        /**
         * The parsed style sheet.
         */
        private IStyleSheet styleSheet;

        /**
         * Constructor.
         * 
         * @param document the document
         * @param model the annotation model
         * @param fileSynchronizer the file synchronizer
         * @param styleSheet the style sheet
         */
        public StyleSheetInfo(IDocument document, IAnnotationModel model,
            FileSynchronizer fileSynchronizer, IStyleSheet styleSheet) {
            super(document, model, fileSynchronizer);
            this.styleSheet = styleSheet;
        }

    }

    // FileDocumentProvider Implementation -------------------------------------

    /*
     * @see org.eclipse.ui.texteditor.AbstractDocumentProvider#createElementInfo(Object)
     */
    protected ElementInfo createElementInfo(Object element)
        throws CoreException {
        if (element instanceof IFileEditorInput) {
            IFileEditorInput input = (IFileEditorInput) element;
            // TODO This is pretty ugly, because we needed to copy a bunch of
            //      code from FileDocumentProvider
            try {
                refreshFile(input.getFile());
            } catch (CoreException e) {
                handleCoreException(e, CssEditorMessages.getString(
                    "CssDocumentProvider.createElementInfo")); //$NON-NLS-1$
            }
            IDocument document = null;
            IStatus status = null;
            try {
                document = createDocument(element);
            } catch (CoreException e) {
                document = createEmptyDocument();
                status = e.getStatus();
            }
            IAnnotationModel annotationModel = createAnnotationModel(element);
            FileSynchronizer fileSynchronizer = new FileSynchronizer(input);
            fileSynchronizer.install();
            IStyleSheet styleSheet = createStyleSheet(document);
            if (styleSheet instanceof IDocumentListener) {
                document.addDocumentListener((IDocumentListener) styleSheet);
            }
            StyleSheetInfo info = new StyleSheetInfo(document, annotationModel,
                fileSynchronizer, styleSheet);
            info.fModificationStamp = computeModificationStamp(input.getFile());
            info.fStatus = status;
            info.fEncoding = getPersistedEncoding(input);
            info.styleSheet = styleSheet;
            return info;
        }
        return super.createElementInfo(element);
    }

    /*
     * @see org.eclipse.ui.texteditor.AbstractDocumentProvider#disposeElementInfo(Object, org.eclipse.ui.texteditor.AbstractDocumentProvider.ElementInfo)
     */
    protected void disposeElementInfo(Object element, ElementInfo info) {
        if (info instanceof StyleSheetInfo) {
            IDocument document = info.fDocument;
            IStyleSheet styleSheet = ((StyleSheetInfo) info).styleSheet;
            if (styleSheet instanceof IDocumentListener) {
                document.removeDocumentListener((IDocumentListener) styleSheet);
            }
        }
        super.disposeElementInfo(element, info);
    }

    /*
     * @see org.eclipse.ui.editors.text.StorageDocumentProvider#setupDocument(Object, IDocument)
     */
    protected void setupDocument(Object element, IDocument document) {
        if (document != null) {
            CssTextTools tools = CssEditorPlugin.getDefault().getTextTools();
            tools.setupDocument(document);
        }
    }

    // Public Methods ----------------------------------------------------------

    /**
     * Creates the parsed style sheet object corresponding to the specified 
     * document.
     * 
     * @param document the document to parse
     * @return the parsed style sheet
     */
    public IStyleSheet createStyleSheet(IDocument document) {
        return new StyleSheet(document);
    }

    /**
     * Returns the style sheet associated with the specified element.
     * 
     * @param element the element
     * @return the style sheet associated with the element
     */
    public IStyleSheet getStyleSheet(Object element) {
        ElementInfo info = getElementInfo(element);
        if (info instanceof StyleSheetInfo) {
            StyleSheetInfo styleSheetInfo = (StyleSheetInfo) info;
            return styleSheetInfo.styleSheet;
        }
        return null;
    }

}
