/*
 * Copyright (c) 2003 Christopher Lenz and others.
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 * 
 * Contributors:
 *     Christopher Lenz - initial API and implementation
 * 
 * $Id: CssOutlineDoubleClickListener.java,v 1.3 2004/01/13 16:54:27 cell Exp $
 */

package net.sourceforge.csseditor.internal.outline;

import org.eclipse.jface.viewers.DoubleClickEvent;
import org.eclipse.jface.viewers.IDoubleClickListener;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.ui.IPageLayout;
import org.eclipse.ui.IWorkbenchPage;
import org.eclipse.ui.PartInitException;
import org.eclipse.ui.views.contentoutline.ContentOutlinePage;

import net.sourceforge.csseditor.CssEditorPlugin;
import net.sourceforge.csseditor.model.IStyleRule;

/**
 * A double click listener that is intended to be attached to an outline page
 * displaying CSS elements. If a style rule is double clicked, it will attempt
 * to show the standard properties view.
 */
public class CssOutlineDoubleClickListener implements IDoubleClickListener {

    // Instance Variables ------------------------------------------------------

    /**
     * The associated content outline page.
     */
    private ContentOutlinePage outlinePage;

    // Constructors ------------------------------------------------------------

    /**
     * Constructor.
     * 
     * @param outlinePage the associated outline page
     */
    public CssOutlineDoubleClickListener(ContentOutlinePage outlinePage) {
        this.outlinePage = outlinePage;
    }

    // IDoubleClickListener Implementation -------------------------------------

    /*
     * @see IDoubleClickListener#doubleClick(DoubleClickEvent)
     */
    public void doubleClick(DoubleClickEvent event) {
        Object selectedElement = getSelectedElement(event.getSelection());
        if (selectedElement instanceof IStyleRule) {
            showPropertiesView();
        }
    }

    // Private Methods ---------------------------------------------------------

    /**
     * Shows the properties view in the current workbench window.
     */
    private void showPropertiesView() {
        IWorkbenchPage workbenchPage = outlinePage.getSite().getPage();
        try {
            workbenchPage.showView(IPageLayout.ID_PROP_SHEET);
        } catch (PartInitException e) {
            CssEditorPlugin.log(
                "Could not show properties view", e); //$NON-NLS-1$
        }
    }

    /**
     * Finds the element that is selected. As this is a double click listener,
     * only a single element can be selected at once.
     * 
     * @param selection the selection
     * @return the selected element
     */
    private Object getSelectedElement(ISelection selection) {
        Object element = null;
        if (selection instanceof IStructuredSelection) {
            element = ((IStructuredSelection) selection).getFirstElement();
        }
        return element;
    }

}
