/*
 * Copyright (c) 2003 Christopher Lenz and others.
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 * 
 * Contributors:
 *     Christopher Lenz - initial API and implementation
 * 
 * $Id: CssEditorTypingConfigurationBlock.java,v 1.3 2004/01/13 11:46:14 cell Exp $
 */

package net.sourceforge.csseditor.internal.preferences;

import org.eclipse.jface.preference.IPreferenceStore;
import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;

import net.sourceforge.csseditor.internal.CssEditorMessages;
import net.sourceforge.csseditor.internal.CssEditorPreferences;

/**
 * 
 */
final class CssEditorTypingConfigurationBlock
    extends AbstractConfigurationBlock {

    // Constructors ------------------------------------------------------------

    public CssEditorTypingConfigurationBlock(IPreferenceStore store) {
        super(store);
    }

    // Public Methods ----------------------------------------------------------

    public Control createControl(Composite parent) {

        Composite composite = new Composite(parent, SWT.NONE);
        GridLayout layout = new GridLayout();
        layout.numColumns = 2;
        composite.setLayout(layout);

        addBooleanField(composite,
            getString("insertSpaceForTabs"), //$NON-NLS-1$
            CssEditorPreferences.EDITOR_SPACES_FOR_TABS, 1);
        initialize();

        return composite;
    }

    private static String getString(String key) {
        return CssEditorMessages.getString(
            "CssEditorPreferencePage.typing." + key); //$NON-NLS-1$
    }

    private void initialize() {
        initializeFields();
    }

}
