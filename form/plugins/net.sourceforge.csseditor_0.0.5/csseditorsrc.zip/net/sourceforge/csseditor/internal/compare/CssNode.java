/*
 * Copyright (c) 2003 Christopher Lenz and others.
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 * 
 * Contributors:
 *     Christopher Lenz - initial API and implementation
 * 
 * $Id: CssNode.java,v 1.3 2004/01/13 17:10:28 cell Exp $
 */

package net.sourceforge.csseditor.internal.compare;

import org.eclipse.compare.ITypedElement;
import org.eclipse.compare.structuremergeviewer.DocumentRangeNode;
import org.eclipse.jface.text.IDocument;
import org.eclipse.swt.graphics.Image;

import net.sourceforge.csseditor.CssEditorPlugin;
import net.sourceforge.csseditor.internal.CssEditorMessages;

/**
 * 
 */
public class CssNode extends DocumentRangeNode implements ITypedElement {

    // Constants ---------------------------------------------------------------

    /**
     * Type code for the top-level style sheet.
     */
    public static final int STYLE_SHEET = 0;

    /**
     * Type code for at rules.
     */
    public static final int AT_RULE = 1;

    /**
     * Type code for style rules.
     */
    public static final int STYLE_RULE = 2;

    /**
     * Type code for declarations (property-value assignment).
     */
    public static final int DECLARATION = 3;

    // Instance Variables ------------------------------------------------------

    /**
     * The display name of the node.
     */
    private String name;

    // Constructors ------------------------------------------------------------

    /**
     * Constructor for the top-level style sheet node.
     * 
     * @param document The document
     */
    public CssNode(IDocument document) {
        super(STYLE_SHEET, "root", document, 0, //$NON-NLS-1$
            document.getLength());
    }

    /**
     * Constructor.
     * 
     * @param parent 
     * @param typeCode
     * @param id
     * @param name
     * @param start
     * @param length
     */
    public CssNode(CssNode parent, int typeCode, String id, String name,
        int start, int length) {
        super(typeCode, parent.getId() + Integer.toString(typeCode) + id,
            parent.getDocument(), start, length);
        this.name = name;
    }

    /**
     * @see org.eclipse.compare.ITypedElement#getName()
     */
    public String getName() {
        if (getTypeCode() == STYLE_SHEET) {
            return CssEditorMessages.getString(
                "CssStructureViewer.styleSheet"); //$NON-NLS-1$
        }
        return name;
    }

    /**
     * @see org.eclipse.compare.ITypedElement#getImage()
     */
    public Image getImage() {
        String key = null;
        switch (getTypeCode()) {
            case STYLE_SHEET: {
                key = CssEditorPlugin.ICON_STYLE_SHEET;
                break;
            }
            case AT_RULE: {
                key = CssEditorPlugin.ICON_AT_RULE;
                break;
            }
            case STYLE_RULE: {
                key = CssEditorPlugin.ICON_STYLE_RULE;
                break;
            }
            case DECLARATION: {
                key = CssEditorPlugin.ICON_PROPERTY;
                break;
            }
            default: {
                // we'll just return null
            }
        }
        return CssEditorPlugin.getDefault().getImageRegistry().get(key);
    }

    /**
     * @see org.eclipse.compare.ITypedElement#getType()
     */
    public String getType() {
        return "css"; //$NON-NLS-1$
    }

}
