/*
 * Copyright (c) 2003 Christopher Lenz and others.
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 * 
 * Contributors:
 *     Christopher Lenz - initial API and implementation
 * 
 * $Id: CommentAction.java,v 1.1.1.1 2003/12/14 21:59:36 cell Exp $
 */

package net.sourceforge.csseditor.internal.editor;

import java.util.ResourceBundle;

import org.eclipse.jface.text.BadLocationException;
import org.eclipse.jface.text.IDocument;
import org.eclipse.jface.text.IRewriteTarget;
import org.eclipse.jface.text.ITextSelection;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.ISelectionProvider;
import org.eclipse.ui.IEditorInput;
import org.eclipse.ui.texteditor.IDocumentProvider;
import org.eclipse.ui.texteditor.ITextEditor;
import org.eclipse.ui.texteditor.ITextEditorExtension2;
import org.eclipse.ui.texteditor.TextEditorAction;

/**
 * (Heavily inspired by the AddBlockComment class in JDT-UI)
 */
public class CommentAction extends TextEditorAction {

    // Constructors ------------------------------------------------------------

    /**
     * Constructor.
     * 
     * @param bundle the resource bundle
     * @param prefix a prefix to be prepended to the various resource keys
     *   (described in <code>ResourceAction</code> constructor), or 
     *   <code>null</code> if none
     * @param editor the text editor
     */
    public CommentAction(ResourceBundle bundle, String prefix,
        ITextEditor editor) {
        super(bundle, prefix, editor);
    }
    
    // TextEditorAction Implementation -----------------------------------------

    /**
     * @see org.eclipse.jface.action.Action#run()
     */
    public void run() {
        if (!isEnabled()) {
            return;
        }
        ITextEditor editor = getTextEditor();
        if ((editor == null) || !ensureEditable(editor)) {
            return;
        }
        ITextSelection selection = getCurrentSelection();
        if (!validSelection(selection)) {
            return;
        }
        IDocumentProvider docProvider = editor.getDocumentProvider();
        IEditorInput input = editor.getEditorInput();
        if (docProvider == null || input == null) {
            return;
        }
        IDocument document = docProvider.getDocument(input);
        if (document == null) {
            return;
        }
        IRewriteTarget target = (IRewriteTarget) 
            editor.getAdapter(IRewriteTarget.class);
        if (target != null) {
            target.beginCompoundChange();
        }
        try {
            int offset = selection.getOffset();
            String start = "/*"; //$NON-NLS-1$
            document.replace(offset, 0, start);
            document.replace(offset + selection.getLength() + start.length(), 0,
                "*/"); //$NON-NLS-1$
        } catch (BadLocationException e) {
            // ignore
        } finally {
            if (target != null) {
                target.endCompoundChange();
            }
        }
    }
    
    /**
     * @see org.eclipse.ui.texteditor.TextEditorAction#update()
     */
    public void update() {
        super.update();
        if (isEnabled()) {
            if (!validSelection(getCurrentSelection())) {
                setEnabled(false);
            }
        }
    }
    
    // Private Methods ---------------------------------------------------------

    /**
     * Ensures that the editor is modifyable. If the editor is an instance of
     * <code>ITextEditorExtension2</code>, its 
     * <code>validateEditorInputState</code> method is called, otherwise, the 
     * result of <code>isEditable</code> is returned.
     * 
     * @param editor the editor to be checked
     * @return <code>true</code> if the editor is editable, <code>false</code> 
     *         otherwise
     */
    private boolean ensureEditable(ITextEditor editor) {
        if (editor instanceof ITextEditorExtension2) {
            ITextEditorExtension2 extension = (ITextEditorExtension2) editor;
            return extension.validateEditorInputState();
        }
        return editor.isEditable();
    }

    /**
     * Returns the editor's selection, or <code>null</code> if no selection can 
     * be obtained or the editor is <code>null</code>.
     * 
     * @return the selection of the action's editor, or <code>null</code>
     */
    private ITextSelection getCurrentSelection() {
        ITextEditor editor = getTextEditor();
        if (editor != null) {
            ISelectionProvider provider = editor.getSelectionProvider();
            if (provider != null) {
                ISelection selection = provider.getSelection();
                if (selection instanceof ITextSelection) {
                    return (ITextSelection) selection;
                }
            }
        }
        return null;
    }

    /**
     * Checks whether <code>selection</code> is valid, i.e. neither 
     * <code>null</code> or empty.
     * 
     * @param selection the selection to check
     * @return <code>true</code> if the selection is valid, <code>false</code> 
     *         otherwise
     */
    private boolean validSelection(ITextSelection selection) {
        if (selection != null) {
            return (!selection.isEmpty() && (selection.getLength() > 0));
        }
        return false;
    }

}
