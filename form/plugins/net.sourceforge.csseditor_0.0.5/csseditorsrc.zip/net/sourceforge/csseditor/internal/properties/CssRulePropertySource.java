/*
 * Copyright (c) 2003 Christopher Lenz and others.
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 * 
 * Contributors:
 *     Christopher Lenz - initial API and implementation
 * 
 * $Id: CssRulePropertySource.java,v 1.2 2003/12/27 18:46:56 cell Exp $
 */

package net.sourceforge.csseditor.internal.properties;

import java.util.ArrayList;
import java.util.List;

import org.eclipse.jface.viewers.LabelProvider;
import org.eclipse.swt.graphics.Image;
import org.eclipse.ui.views.properties.IPropertyDescriptor;
import org.eclipse.ui.views.properties.IPropertySource;
import org.eclipse.ui.views.properties.PropertyDescriptor;

import net.sourceforge.csseditor.CssEditorPlugin;
import net.sourceforge.csseditor.IProfile;
import net.sourceforge.csseditor.IProfileManager;
import net.sourceforge.csseditor.model.IDeclaration;
import net.sourceforge.csseditor.model.IPropertyInfo;
import net.sourceforge.csseditor.model.IRule;
import net.sourceforge.csseditor.model.ISourceReference;

/**
 * 
 */
public class CssRulePropertySource implements IPropertySource {

    // Inner Classes -----------------------------------------------------------

    /**
     * Extended label provider that decorates the property values with specific
     * icons when a priority is set.
     */
    private static class DeclarationLabelProvider extends LabelProvider {

        /**
         * The CSS declaration for which a label should be provided.
         */
        private IDeclaration declaration;

        /**
         * Constructor.
         * 
         * @param declaration the declaration for which to provide a label
         */
        public DeclarationLabelProvider(IDeclaration declaration) {
            this.declaration = declaration;
        }

        /*
         * @see org.eclipse.jface.viewers.ILabelProvider#getImage(Object)
         */
        public Image getImage(Object element) {
            if (this.declaration.getPriority() != null) {
                CssEditorPlugin plugin = CssEditorPlugin.getDefault();
                return plugin.getImageRegistry().get(
                    CssEditorPlugin.ICON_IMPORTANT);
            }
            return null;
        }

        /*
         * @see org.eclipse.jface.viewers.ILabelProvider#getText(Object)
         */
        public String getText(Object element) {
            return this.declaration.getValue().getSource();
        }

    }

    // Instance Variables ------------------------------------------------------

    /**
     * The CSS rule for which properties should be provided.
     */
    private IRule rule;

    /**
     * Cached list of property descriptors (<code>IPropertyDescriptor</code>).
     */
    private List descriptors;

    // Constructors ------------------------------------------------------------

    /**
     * Constructor.
     * 
     * @param styleRule the style rule for which to provide properties
     */
    public CssRulePropertySource(IRule styleRule) {
        this.rule = styleRule;
    }

    // IPropertySource Implementation ------------------------------------------

    /**
     * @see IPropertySource#getEditableValue()
     */
    public Object getEditableValue() {
        return null;
    }

    /**
     * @see IPropertySource#getPropertyDescriptors()
     */
    public IPropertyDescriptor[] getPropertyDescriptors() {
        if (this.descriptors == null) {
            IProfileManager mgr =
                CssEditorPlugin.getDefault().getProfileManager();
            IProfile profile = mgr.getProfile(null);
            this.descriptors = new ArrayList();
            for (int i = 0; i < this.rule.getDeclarations().length; i++) {
                IDeclaration declaration = this.rule.getDeclarations()[i];
                String property = declaration.getProperty().getSource();
                PropertyDescriptor descriptor = new PropertyDescriptor(
                    new Integer(i), property);
                descriptor.setLabelProvider(
                    new DeclarationLabelProvider(declaration));
                IPropertyInfo info = profile.getPropertyInfo(property);
                if (info != null) {
                    descriptor.setCategory(info.getCategory());
                }
                this.descriptors.add(descriptor);
            }
        }
        return (IPropertyDescriptor[]) this.descriptors.toArray(
            new IPropertyDescriptor[this.descriptors.size()]);
    }

    /**
     * @see IPropertySource#getPropertyValue(java.lang.Object)
     */
    public Object getPropertyValue(Object id) {
        int i = ((Integer) id).intValue();
        ISourceReference propertyValue =
            this.rule.getDeclarations()[i].getValue();
        return propertyValue.getSource();
    }

    /**
     * @see IPropertySource#isPropertySet(java.lang.Object)
     */
    public boolean isPropertySet(Object id) {
        // read-only property
        return false;
    }

    /**
     * @see IPropertySource#resetPropertyValue(java.lang.Object)
     */
    public void resetPropertyValue(Object id) {
        // read-only property
    }

    /**
     * @see org.eclipse.ui.views.properties.IPropertySource#setPropertyValue(java.lang.Object, java.lang.Object)
     */
    public void setPropertyValue(Object id, Object value) {
        // read-only property
    }

}
