/*
 * Copyright (c) 2003 Christopher Lenz and others.
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 * 
 * Contributors:
 *     Christopher Lenz - initial API and implementation
 * 
 * $Id: CssStringScanner.java,v 1.2 2003/12/27 16:53:09 cell Exp $
 */

package net.sourceforge.csseditor.internal.text;

import org.eclipse.jface.preference.IPreferenceStore;
import org.eclipse.jface.text.rules.IToken;

import net.sourceforge.csseditor.internal.CssEditorPreferences;
import net.sourceforge.csseditor.text.IColorManager;

/**
 * 
 */
public class CssStringScanner extends AbstractCssScanner {

    // Constructors ------------------------------------------------------------

    /**
     * Constructor.
     * 
     * @param store The preference store
     */
    public CssStringScanner(IPreferenceStore store, IColorManager manager) {
        super(store, manager);

        IToken stringToken = createToken(
            CssEditorPreferences.EDITOR_STRING_COLOR,
            CssEditorPreferences.EDITOR_STRING_BOLD);
        
        setDefaultReturnToken(stringToken);
    }

}
