/*
 * Copyright (c) 2003 Christopher Lenz and others.
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 * 
 * Contributors:
 *     Christopher Lenz - initial API and implementation
 * 
 * $Id: AtRule.java,v 1.3 2004/01/13 13:54:05 cell Exp $
 */

package net.sourceforge.csseditor.internal.model;

import org.eclipse.jface.text.IDocument;

import net.sourceforge.csseditor.model.IAtRule;
import net.sourceforge.csseditor.model.IRule;
import net.sourceforge.csseditor.model.ISourceReference;
import net.sourceforge.csseditor.model.IStyleSheet;

/**
 * 
 */
public class AtRule extends AbstractRule
    implements IAtRule {

    // Instance Variables ------------------------------------------------------

    private ISourceReference name;

    private ISourceReference value;

    // Constructors ------------------------------------------------------------

    /**
     * Constructor.
     * 
     * @param document The document that contains the rule
     */
    public AtRule(IDocument document, IStyleSheet styleSheet) {
        this(document, styleSheet, null);
    }

    /**
     * Constructor.
     * 
     * @param document The document that contains the rule
     * @param parent The parent rule, or <code>null</code> if the rule is at top
     *        level
     */
    public AtRule(IDocument document, IStyleSheet styleSheet, IRule parent) {
        super(document, styleSheet, parent);
    }

    // IAtRule Implementation --------------------------------------------------

    /**
     * @see net.sourceforge.csseditor.model.ICssAtRule#getName()
     */
    public final ISourceReference getName() {
        return name;
    }

    /**
     * @see net.sourceforge.csseditor.model.ICssAtRule#getValue()
     */
    public final ISourceReference getValue() {
        return value;
    }

    // Public Methods --------------------------------------------------

    public final void setName(ISourceReference name) {
        this.name = name;
    }

    public final void setValue(ISourceReference value) {
        this.value = value;
    }

}
