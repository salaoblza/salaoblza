/*
 * Copyright (c) 2003 Christopher Lenz and others.
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 * 
 * Contributors:
 *     Christopher Lenz - initial API and implementation
 * 
 * $Id: SyntaxPreviewer.java,v 1.2 2003/12/27 18:46:56 cell Exp $
 */

package net.sourceforge.csseditor.internal.preferences;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import org.eclipse.jface.preference.IPreferenceStore;
import org.eclipse.jface.preference.PreferenceConverter;
import org.eclipse.jface.resource.JFaceResources;
import org.eclipse.jface.text.Document;
import org.eclipse.jface.text.IDocument;
import org.eclipse.jface.text.source.SourceViewer;
import org.eclipse.jface.util.IPropertyChangeListener;
import org.eclipse.jface.util.PropertyChangeEvent;
import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.StyledText;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.RGB;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;

import net.sourceforge.csseditor.CssEditorPlugin;
import net.sourceforge.csseditor.internal.CssEditorPreferences;
import net.sourceforge.csseditor.text.CssSourceViewerConfiguration;
import net.sourceforge.csseditor.text.CssTextTools;

/**
 * A previewer for the syntax styling preferences, used to give real time
 * feedback on changes to the preferences.
 */
public class SyntaxPreviewer extends SourceViewer {

    // Constants ---------------------------------------------------------------

    /**
     * Alias for the preference constant <code>EDITOR_BACKGROUND_COLOR</code>.
     */
    private static final String BACKGROUND_COLOR = 
        CssEditorPreferences.EDITOR_BACKGROUND_COLOR;

    /**
     * Alias for the preference constant
     * <code>EDITOR_BACKGROUND_DEFAULT_COLOR</code>.
     */
    private static final String BACKGROUND_DEFAULT_COLOR = 
        CssEditorPreferences.EDITOR_BACKGROUND_DEFAULT_COLOR;

    // Instance Variables ------------------------------------------------------

    /**
     * The preference store used for loading the style settings.
     */
    private IPreferenceStore fStore;

    /**
     * Listener that handles changes to the preference store.
     */
    private IPropertyChangeListener fPropertyChangeListener =
        new IPropertyChangeListener() {
            public void propertyChange(PropertyChangeEvent event) {
                if (affectsPresentation(event)) {
                    updateColors();
                }
                invalidateTextPresentation();
            }
        };

    private CssTextTools fTextTools;

    /**
     * The cached background color of the previewer.
     */
    private Color fBackgroundColor;

    // Constructors ------------------------------------------------------------

    /**
     * Constructor.
     * 
     * @param parent The parent composite
     * @param store The preference store to use for loading the style settings
     */
    public SyntaxPreviewer(Composite parent, IPreferenceStore store) {
        super(parent, null, SWT.V_SCROLL | SWT.H_SCROLL | SWT.BORDER);
        this.fStore = store;
        this.fTextTools = new CssTextTools(this.fStore);

        configure(new CssSourceViewerConfiguration(
            this.fTextTools, this.fStore));
        setEditable(false);
        getTextWidget().setFont(JFaceResources.getTextFont());

        IDocument document = new Document(
            loadTextFromResource("preview.css")); //$NON-NLS-1$
        this.fTextTools.setupDocument(document);
        setDocument(document);

        this.fStore.addPropertyChangeListener(this.fPropertyChangeListener);
    }

    // SourceViewer Implementation ---------------------------------------------

    /**
     * @see org.eclipse.jface.text.TextViewer#handleDispose()
     */
    protected void handleDispose() {
        if (this.fStore != null) {
            if (this.fPropertyChangeListener != null) {
                this.fStore.removePropertyChangeListener(
                    this.fPropertyChangeListener);
                this.fPropertyChangeListener = null;
            }
            this.fStore = null;
        }
        if (this.fTextTools != null) {
            this.fTextTools.dispose();
            this.fTextTools = null;
        }
        if ((this.fBackgroundColor != null)
         && !this.fBackgroundColor.isDisposed()) {
            this.fBackgroundColor.dispose();
        }
        super.handleDispose();
    }

    // Private Methods ---------------------------------------------------------

    private boolean affectsPresentation(PropertyChangeEvent event) {
        String p = event.getProperty();
        if (BACKGROUND_COLOR.equals(p)
         || BACKGROUND_DEFAULT_COLOR.equals(p)) {
            return true;
        }
        return false;
    }

    /**
     * Creates a color from the information stored in the given preference
     * store.
     * 
     * @param key The preference key under which the color is stored
     * @param display The display
     * @return The color found, or <code>null</code> if no corresponding 
     *         preference is available
     */
    private Color createColor(String key, Display display) {
        Color color = null;      
        if (this.fStore.contains(key)) {
            RGB rgb = null;
            if (this.fStore.isDefault(key)) {
                rgb = PreferenceConverter.getDefaultColor(this.fStore, key);
            } else {
                rgb = PreferenceConverter.getColor(this.fStore, key);
            }
            if (rgb != null) {
                color = new Color(display, rgb);
            }
        }
        return color;
    }   
    
    /**
     * Loads and returns the text stored in the specified resource.
     * 
     * @param name The resource name
     * @return The text loaded from the resource, or an empty string if there
     *         was an error reading the resource contents
     */
    private String loadTextFromResource(String name) {
        String line;
        String separator = System.getProperty("line.separator"); //$NON-NLS-1$
        StringBuffer buffer = new StringBuffer(512);
        BufferedReader reader = null;
        try {
            reader = new BufferedReader(new InputStreamReader(
                getClass().getResourceAsStream(name)));
            while ((line = reader.readLine()) != null) {
                buffer.append(line);
                buffer.append(separator);
            }
        } catch (IOException io) {
            CssEditorPlugin.log(io);
        } finally {
            if (reader != null) {
                try {
                    reader.close();
                } catch (IOException e) {
                    // ignore
                }
            }
        }
        return buffer.toString();
    }
    
    /**
     * Updates the previewer colors.
     */
    private void updateColors() {
        if (this.fStore != null) {
            StyledText styledText = getTextWidget();
            Color color = null;
            if (!this.fStore.getBoolean(BACKGROUND_DEFAULT_COLOR)) {
                color = createColor(BACKGROUND_COLOR,
                    styledText.getDisplay());
            }
            styledText.setBackground(color);
            if (this.fBackgroundColor != null) {
                this.fBackgroundColor.dispose();
            }
            this.fBackgroundColor = color;
        }
    }

}
