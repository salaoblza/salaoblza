/*
 * Copyright (c) 2003 Christopher Lenz and others.
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 * 
 * Contributors:
 *     Christopher Lenz - initial API and implementation
 * 
 * $Id: CssEditorContentAssistConfigurationBlock.java,v 1.2 2003/12/27 18:46:56 cell Exp $
 */

package net.sourceforge.csseditor.internal.preferences;

import org.eclipse.jface.preference.ColorSelector;
import org.eclipse.jface.preference.IPreferenceStore;
import org.eclipse.jface.preference.PreferenceConverter;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.graphics.RGB;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.List;

import net.sourceforge.csseditor.internal.CssEditorMessages;
import net.sourceforge.csseditor.internal.CssEditorPreferences;

/**
 * Configuration block for setting the preferences related to content assist.
 */
final class CssEditorContentAssistConfigurationBlock
    extends AbstractConfigurationBlock {

    // Instance Variables ------------------------------------------------------

    private List fColorList;
    private final String[][] fColorListModel = new String[][] {
        { getString("backgroundForCompletionProposals"), //$NON-NLS-1$
          CssEditorPreferences.CONTENTASSIST_PROPOSALS_BACKGROUND },
        { getString("foregroundForCompletionProposals"), //$NON-NLS-1$
          CssEditorPreferences.CONTENTASSIST_PROPOSALS_FOREGROUND },
    };
    private ColorSelector fColorSelector;
    private Control fAutoActivationDelayField;
    private Control fAutoActivationTriggersField;

    // Constructors ------------------------------------------------------------

    public CssEditorContentAssistConfigurationBlock(IPreferenceStore store) {
        super(store);
    }

    // Public Methods ----------------------------------------------------------

    public Control createControl(Composite parent) {

        Composite composite = new Composite(parent, SWT.NONE);
        GridLayout layout = new GridLayout();
        layout.numColumns = 2;
        composite.setLayout(layout);

        //addCompletionRadioButtons(contentAssistComposite);

        addBooleanField(composite,
            getString("insertSingleProposalsAutomatically"), //$NON-NLS-1$
            CssEditorPreferences.CONTENTASSIST_AUTOINSERT, 0);
        addBooleanField(composite,
            getString("presentProposalsInAlphabeticalOrder"), //$NON-NLS-1$
            CssEditorPreferences.CONTENTASSIST_ORDER_PROPOSALS, 0);
        addBooleanField(composite,
            getString("enableAutoActivation"), //$NON-NLS-1$
            CssEditorPreferences.CONTENTASSIST_AUTOACTIVATION,
            0).addSelectionListener(new SelectionAdapter() {
                public void widgetSelected(SelectionEvent e) {
                    updateAutoactivationControls();
                }
            });
        fAutoActivationDelayField = addIntegerField(composite,
            getString("autoActivationDelay"), //$NON-NLS-1$
            CssEditorPreferences.CONTENTASSIST_AUTOACTIVATION_DELAY, 4, 0);
        fAutoActivationTriggersField = addTextField(composite,
            getString("autoActivationTriggers"), //$NON-NLS-1$
            CssEditorPreferences.CONTENTASSIST_AUTOACTIVATION_TRIGGERS, 4, 0);

        Label label = new Label(composite, SWT.LEFT);
        label.setText(getString("colorOptions")); //$NON-NLS-1$
        GridData gridData = new GridData(GridData.HORIZONTAL_ALIGN_FILL);
        gridData.horizontalSpan = 2;
        label.setLayoutData(gridData);

        Composite editorComposite = new Composite(composite, SWT.NONE);
        layout = new GridLayout();
        layout.numColumns = 2;
        layout.marginHeight = 0;
        layout.marginWidth = 0;
        editorComposite.setLayout(layout);
        gridData = new GridData(
            GridData.HORIZONTAL_ALIGN_FILL | GridData.FILL_VERTICAL);
        gridData.horizontalSpan = 2;
        editorComposite.setLayoutData(gridData);

        fColorList = new List(editorComposite,
            SWT.SINGLE | SWT.V_SCROLL | SWT.BORDER);
        gridData = new GridData(
            GridData.VERTICAL_ALIGN_BEGINNING | GridData.FILL_HORIZONTAL);
        gridData.heightHint = convertHeightInCharsToPixels(composite, 8);
        fColorList.setLayoutData(gridData);
        fColorList.addSelectionListener(new SelectionListener() {
            public void widgetDefaultSelected(SelectionEvent e) {
                // do nothing
            }
            public void widgetSelected(SelectionEvent e) {
                handleColorListSelection();
            }
        });

        Composite stylesComposite = new Composite(editorComposite, SWT.NONE);
        layout = new GridLayout();
        layout.marginHeight = 0;
        layout.marginWidth = 0;
        layout.numColumns = 2;
        stylesComposite.setLayout(layout);
        stylesComposite.setLayoutData(new GridData(GridData.FILL_BOTH));
        label = new Label(stylesComposite, SWT.LEFT);
        label.setText(getString("color")); //$NON-NLS-1$
        gridData = new GridData();
        gridData.horizontalAlignment = GridData.BEGINNING;
        label.setLayoutData(gridData);

        fColorSelector = new ColorSelector(stylesComposite);
        Button colorButton = fColorSelector.getButton();
        gridData = new GridData(GridData.FILL_HORIZONTAL);
        gridData.horizontalAlignment = GridData.BEGINNING;
        colorButton.setLayoutData(gridData);
        colorButton.addSelectionListener(new SelectionListener() {
            public void widgetDefaultSelected(SelectionEvent e) {
                // do nothing
            }
            public void widgetSelected(SelectionEvent e) {
                int i = fColorList.getSelectionIndex();
                String key = fColorListModel[i][1];
                PreferenceConverter.setValue(getPreferenceStore(), key,
                    fColorSelector.getColorValue());
            }
        });

        initialize();

        return composite;
    }

    // Event Handlers ----------------------------------------------------------

    void handleColorListSelection() {
        int i = fColorList.getSelectionIndex();
        String key = fColorListModel[i][1];
        RGB rgb = PreferenceConverter.getColor(getPreferenceStore(), key);
        fColorSelector.setColorValue(rgb);
    }

    // Private Methods ---------------------------------------------------------

    private static String getString(String key) {
        return CssEditorMessages.getString(
            "CssEditorPreferencePage.contentAssist." + key); //$NON-NLS-1$
    }

    private void initialize() {
        for (int i = 0; i < fColorListModel.length; i++) {
            fColorList.add(fColorListModel[i][0]);
        }
        fColorList.getDisplay().asyncExec(new Runnable() {
            public void run() {
                if ((fColorList != null)
                 && !fColorList.isDisposed()) {
                    fColorList.select(0);
                    handleColorListSelection();
                }
            }
        });
        initializeFields();
    }

    private void updateAutoactivationControls() {
        boolean enabled = getPreferenceStore().getBoolean(
            CssEditorPreferences.CONTENTASSIST_AUTOACTIVATION);
        fAutoActivationDelayField.setEnabled(enabled);
        getLabel(fAutoActivationDelayField).setEnabled(enabled);
        fAutoActivationTriggersField.setEnabled(enabled);
        getLabel(fAutoActivationTriggersField).setEnabled(enabled);
    }

}
