/*
 * Copyright (c) 2003 Christopher Lenz and others.
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 * 
 * Contributors:
 *     Christopher Lenz - initial API and implementation
 * 
 * $Id: CssPropertyPage.java,v 1.2 2003/12/27 18:46:56 cell Exp $
 */

package net.sourceforge.csseditor.internal.properties;

import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Group;
import org.eclipse.ui.dialogs.PropertyPage;

import net.sourceforge.csseditor.CssEditorPlugin;
import net.sourceforge.csseditor.IProfileDescriptor;
import net.sourceforge.csseditor.IProfileManager;
import net.sourceforge.csseditor.internal.CssEditorMessages;
import net.sourceforge.csseditor.internal.CssEditorPreferences;
import net.sourceforge.csseditor.internal.ProfileManager;

/**
 * 
 */
public class CssPropertyPage extends PropertyPage {

    // Instance Variables ------------------------------------------------------

    private IProfileManager profileManager;

    private boolean useCustomSettings;
    private Group profileGroup;
    private Button[] profileButtons;
    private String selectedProfile;

    // Constructors ------------------------------------------------------------

    /**
     * Constructor.
     */
    public CssPropertyPage() {
        this.profileManager = CssEditorPlugin.getDefault().getProfileManager();
    }

    // PropertyPage Implementation ---------------------------------------------

    /**
     * @see org.eclipse.jface.preference.PreferencePage#createContents(Composite)
     */
    protected Control createContents(Composite parent) {

        Composite composite = new Composite(parent, SWT.NONE);
        GridLayout layout = new GridLayout();
        layout.numColumns = 1;
        composite.setLayout(layout);

        Object element = getElement();
        if (element instanceof IResource) {
            IResource resource = (IResource) element;
            try {
                this.selectedProfile = resource.getPersistentProperty(
                    ProfileManager.PROFILE_PROPERTY);
            } catch (CoreException e) {
                // ignore
            }
        }
        this.useCustomSettings = (this.selectedProfile != null);
        if (this.selectedProfile == null) {
            this.selectedProfile = getInheritedProfile();
        }

        Button useInheritedSettings =
            new Button(composite, SWT.RADIO | SWT.LEFT);
        if (element instanceof IProject) {
            useInheritedSettings.setText(
                getString("useWorkspaceSettings")); //$NON-NLS-1$
        } else if (element instanceof IResource) {
            useInheritedSettings.setText(
                getString("useProjectSettings")); //$NON-NLS-1$
        }
        useInheritedSettings.setSelection(!this.useCustomSettings);
        Button useCustomSettings = new Button(composite, SWT.RADIO | SWT.LEFT);
        useCustomSettings.setText(getString("useCustomSettings")); //$NON-NLS-1$
        useCustomSettings.addSelectionListener(new SelectionAdapter() {
            public void widgetSelected(SelectionEvent event) {
                CssPropertyPage.this.useCustomSettings =
                    ((Button) event.widget).getSelection();
                updateProfileGroup();
            }
        });
        useCustomSettings.setSelection(this.useCustomSettings);

        this.profileGroup = new Group(composite, SWT.SHADOW_ETCHED_IN);
        layout = new GridLayout();
        layout.numColumns = 1;
        this.profileGroup.setLayout(layout);
        this.profileGroup.setText(getString("profile")); //$NON-NLS-1$

        IProfileDescriptor[] profiles =
            this.profileManager.getProfileDescriptors();
        this.profileButtons = new Button[profiles.length];
        for (int i = 0; i < profiles.length; i++) {
            this.profileButtons[i] =
                new Button(this.profileGroup, SWT.RADIO | SWT.LEFT);
            this.profileButtons[i].setText(profiles[i].getName());
            this.profileButtons[i].setData(profiles[i].getId());
            if (profiles[i].getId().equals(this.selectedProfile)) {
                this.profileButtons[i].setSelection(true);
            }
            this.profileButtons[i].addSelectionListener(new SelectionAdapter() {
                public void widgetSelected(SelectionEvent event) {
                    CssPropertyPage.this.selectedProfile =
                        (String) event.widget.getData();
                }
            });
        }
        updateProfileGroup();

        return composite;
    }

    /**
     * @see org.eclipse.jface.preference.IPreferencePage#performOk()
     */
    public boolean performOk() {
        Object element = getElement();
        if (element instanceof IResource) {
            IResource resource = (IResource) element;
            if (this.useCustomSettings) {
                this.profileManager.setProfile(resource, this.selectedProfile);
            } else {
                this.profileManager.setProfile(resource, null);
            }
        }
        return true;
    }

    // Private Methods ---------------------------------------------------------

    private String getInheritedProfile() {
        Object element = getElement();
        String retVal = null;        
        if (element instanceof IResource) {
            IProject project = ((IResource) element).getProject();
            try {
                retVal = project.getPersistentProperty(
                    ProfileManager.PROFILE_PROPERTY);
            } catch (CoreException e) {
                // ignore
            }
        }
        if (retVal == null) {
            CssEditorPlugin plugin = CssEditorPlugin.getDefault();
            retVal = plugin.getPreferenceStore().getString(
                CssEditorPreferences.PROFILE);
        }
        return retVal;
    }

    private String getString(String key) {
        return CssEditorMessages.getString(
            "CssPropertyPage." + key); //$NON-NLS-1$
    }

    private void updateProfileGroup() {
        this.profileGroup.setEnabled(this.useCustomSettings);
        for (int i = 0; i < this.profileButtons.length; i++) {
            this.profileButtons[i].setEnabled(this.useCustomSettings);
        }
    }

}
