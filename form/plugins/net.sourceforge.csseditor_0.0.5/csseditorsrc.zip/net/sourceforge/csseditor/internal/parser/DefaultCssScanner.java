/*
 * Copyright (c) 2003 Christopher Lenz and others.
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 * 
 * Contributors:
 *     Christopher Lenz - initial API and implementation
 * 
 * $Id: DefaultCssScanner.java,v 1.2 2003/12/27 18:46:55 cell Exp $
 */

package net.sourceforge.csseditor.internal.parser;

import org.eclipse.jface.text.BadLocationException;
import org.eclipse.jface.text.IDocument;
import org.eclipse.jface.text.IRegion;
import org.eclipse.jface.text.Region;

import net.sourceforge.csseditor.internal.CssTextUtils;
import net.sourceforge.csseditor.parser.ICssScanner;
import net.sourceforge.csseditor.parser.ICssTokens;
import net.sourceforge.csseditor.parser.IProblem;
import net.sourceforge.csseditor.parser.LexicalErrorException;

/**
 * Default implementation of a lexical scanner for CSS.
 * 
 * TODO Add support for character escapes and unicode ranges
 */
public class DefaultCssScanner extends AbstractProblemReporter
    implements ICssScanner {

    // Instance Variables ------------------------------------------------------

    private int fCurrentChar;

    private int fOffset;

    private int fTokenOffset;

    // ICssScanner Implementation ----------------------------------------------

    /**
     * @see ICssScanner#getTokenRegion()
     */
    public IRegion getTokenRegion() {
        return new Region(fTokenOffset, fOffset - fTokenOffset);
    }

    /**
     * @see ICssScanner#getNextToken()
     */
    public int getNextToken() throws LexicalErrorException {
        if (fDocument == null) {
            throw new IllegalStateException("Source must be set"); //$NON-NLS-1$
        }
        if (fCurrentChar == -1) {
            return ICssTokens.EOF;
        }
        fTokenOffset = fOffset;
        getNextCharOrEnd();
        switch (fCurrentChar) {
            case '@': {
                return ICssTokens.AT;
            }
            case ':': {
                return ICssTokens.COLON;
            }
            case '.': {
                if (Character.isDigit((char) peekNextChar())) {
                    return handleNumber();
                }
                return fCurrentChar;
            }
            case '{': {
                return ICssTokens.LBRACE;
            }
            case '[': {
                return ICssTokens.LBRACKET;
            }
            case '(': {
                return ICssTokens.LPAREN;
            }
            case '}': {
                return ICssTokens.RBRACE;
            }
            case ']': {
                return ICssTokens.RBRACKET;
            }
            case ')': {
                return ICssTokens.RPAREN;
            }
            case ';': {
                return ICssTokens.SEMICOLON;
            }
            case '/': {
                if (peekNextChar() == '*') {
                    getNextCharOrEnd();
                    return handleComment();
                }
                return fCurrentChar;
            }
            case '\'':
            case '"': {
                return handleString((char) fCurrentChar);
            }
            case '<': {
                if (peekNextChar() == '!') {
                    getNextCharOrEnd();
                    return handleCdo();
                }
                return fCurrentChar;
            }
            case '-': {
                if (peekNextChar() == '-') {
                    getNextCharOrEnd();
                    return handleCdc();
                } else if (CssTextUtils.isCssNumberStart((char)
                    peekNextChar())) {
                    return handleNumber();
                }
                return fCurrentChar;
            }
            default: {
                if (CssTextUtils.isCssIdentifierStart((char) fCurrentChar)) {
                    return handleIdentifier();
                } else if (Character.isDigit((char) fCurrentChar)) {
                    return handleNumber(); 
                } else if (CssTextUtils.isCssWhitespace((char) fCurrentChar)) {
                    return handleWhitespace();
                }
                return fCurrentChar;
            }
        }
    }

    /**
     * @see ICssScanner#setSource(IDocument)
     */
    public void setSource(IDocument document) {
        super.setDocument(document);
        fCurrentChar = 0;
        fOffset = 0;
        fTokenOffset = 0;
    }

    // Protected Methods -------------------------------------------------------

    /**
     * @return
     */
    protected int handleCdc() throws LexicalErrorException {
        if (fCurrentChar != '-') {
            throw new IllegalStateException(
                "Not at the beginning of a CDC"); //$NON-NLS-1$
        }
        if (peekNextChar() != '>') {
            // not a CDC, rewind and return the start character
            fOffset -= 2;
            return getNextCharOrEnd();
        }
        getNextCharOrEnd();
        return ICssTokens.CDC;
    }

    /**
     * @return
     */
    protected int handleCdo() throws LexicalErrorException {
        if (fCurrentChar != '!') {
            throw new IllegalStateException(
                "Not at the beginning of a CDO"); //$NON-NLS-1$
        }
        if (peekNextChar() != '-') {
            // not a CDO, rewind and return the start character
            fOffset -= 2;
            return getNextCharOrEnd();
        }
        getNextCharOrEnd();
        if (peekNextChar() != '-') {
            // not a CDO, rewind and return the start character
            fOffset -= 3;
            return getNextCharOrEnd();
        }
        getNextCharOrEnd();
        return ICssTokens.CDO;
    }

    /**
     * 
     */
    protected int handleComment() throws LexicalErrorException {
        if (fCurrentChar != '*') {
            throw new IllegalStateException(
                "Not at the beginning of a comment"); //$NON-NLS-1$
        }
        do {
            do {
                getNextCharOrError("unterminatedComment"); //$NON-NLS-1$
            } while (fCurrentChar != '*');
            getNextCharOrError("unterminatedComment"); //$NON-NLS-1$
            while (fCurrentChar == '*') {
                getNextCharOrError("unterminatedComment"); //$NON-NLS-1$
            }
        } while (fCurrentChar != '/');
        return getNextToken();
    }

    /**
     * @return
     * @throws LexicalErrorException
     */
    protected int handleIdentifier() throws LexicalErrorException {
        if (!CssTextUtils.isCssIdentifierStart((char) fCurrentChar)) {
            throw new IllegalStateException(
                "Not at the beginning of an identifier"); //$NON-NLS-1$
        }
        while (CssTextUtils.isCssIdentifierPart((char) peekNextChar())) {
            getNextCharOrEnd();
        }
        return ICssTokens.IDENT;
    }

    /**
     * @return
     */
    protected int handleNumber() throws LexicalErrorException {
        if (!CssTextUtils.isCssNumberStart((char) fCurrentChar)) {
            throw new IllegalStateException(
                "Not at the beginning of a number"); //$NON-NLS-1$
        }
        while (CssTextUtils.isCssNumberPart((char) peekNextChar())) {
            getNextCharOrEnd();
        }
        if (peekNextChar() == '.') {
            getNextCharOrEnd();
            while (Character.isDigit((char) peekNextChar())) {
                getNextCharOrEnd();
            }
        }
        return ICssTokens.NUM;
    }

    /**
     * 
     * @param delim
     * @return
     * @throws LexicalErrorException
     */
    protected int handleString(char delim) throws LexicalErrorException {
        if (fCurrentChar != delim) {
            throw new IllegalStateException(
                "Not at the beginning of a string"); //$NON-NLS-1$
        }
        do {
            getNextCharOrError("unterminatedString"); //$NON-NLS-1$
            if (fCurrentChar == '\\') {
                getNextCharOrEnd();
                getNextCharOrError("unterminatedString"); //$NON-NLS-1$
            } else if (fCurrentChar == '\n') {
                reportError("unescapedNewlineInString", //$NON-NLS-1$
                    new Region(fTokenOffset, fOffset - fTokenOffset));
            }
        } while (fCurrentChar != delim);
        return ICssTokens.STRING;
    }

    /**
     * 
     * @return
     * @throws LexicalErrorException
     */
    protected int handleWhitespace() throws LexicalErrorException {
        if (!CssTextUtils.isCssWhitespace((char) fCurrentChar)) {
            throw new IllegalStateException(
                "Not at the beginning of white space"); //$NON-NLS-1$
        }
        while (CssTextUtils.isCssWhitespace((char) peekNextChar())) {
            getNextCharOrEnd();
        }
        return getNextToken();
    }

    /**
     * Positions the scanner over the next character in the source and returns
     * that character. If the end of the source is reached, an 'unexpected end
     * of file' error is reported. 
     * 
     * @param errorId the ID of the error to report
     * @return the next character in the source, or -1 if the end of the source
     *         has been reached
     * @throws LexicalErrorException If the end of the source has been reached
     *         and no problem collector has been configured to collect the 
     *         problem
     */
    protected final int getNextCharOrError(String errorId)
        throws LexicalErrorException {
        getNextCharOrEnd();
        if (fCurrentChar == -1) {
            IProblem error = reportError(errorId,
                new Region(fTokenOffset, fOffset - fTokenOffset));
            throw new LexicalErrorException(error.getMessage());
        }
        return fCurrentChar;
    }

    /**
     * Positions the scanner over the next character in the source and returns
     * that character.  
     * 
     * @return the next character in the source, or -1 if the end of the source
     *         has been reached
     */
    protected final int getNextCharOrEnd() {
        try {
            fCurrentChar = fDocument.getChar(fOffset);
            if (fCurrentChar != -1) {
                fOffset++;
            }
        } catch (BadLocationException e) {
            fCurrentChar = -1;
        }
        return fCurrentChar;
    }

    /**
     * Returns the next character in the source without changing the scanners
     * current position (look ahead).
     * 
     * @return the next character in the source, or -1 if the end of the source
     *         has been reached
     */
    protected final int peekNextChar() {
        int retVal = -1;
        try {
            retVal = fDocument.getChar(fOffset);
        } catch (BadLocationException e) {
            // ignore
        }
        return retVal;
    }

}
