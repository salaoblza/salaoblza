/*
 * Copyright (c) 2003 Christopher Lenz and others.
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 * 
 * Contributors:
 *     Christopher Lenz - initial API and implementation
 * 
 * $Id: ICssEditorActionDefinitionIds.java,v 1.1.1.1 2003/12/14 21:59:35 cell Exp $
 */

package net.sourceforge.csseditor.internal;

import org.eclipse.ui.texteditor.ITextEditorActionDefinitionIds;

/**
 * Action definition IDs used by the CSS editor.
 */
public interface ICssEditorActionDefinitionIds
    extends ITextEditorActionDefinitionIds {

    /**
     * Action definition ID of the "Source &gt; Comment" action
     * (value <code>"net.sourceforge.csseditor.commentAction"</code>).
     */
    String COMMENT = "net.sourceforge.csseditor.commentAction"; //$NON-NLS-1$

    /**
     * Action definition ID of the "Source &gt; Uncomment" action
     * (value <code>"net.sourceforge.csseditor.uncommentAction"</code>).
     */
    String UNCOMMENT =
        "net.sourceforge.csseditor.uncommentAction"; //$NON-NLS-1$

}
