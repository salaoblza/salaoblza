/*
 * Copyright (c) 2003 Christopher Lenz and others.
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 * 
 * Contributors:
 *     Christopher Lenz - initial API and implementation
 * 
 * $Id: OverlayPreferenceStore.java,v 1.1.1.1 2003/12/14 21:59:48 cell Exp $
 */

package net.sourceforge.csseditor.internal.preferences;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.eclipse.jface.preference.IPreferenceStore;
import org.eclipse.jface.preference.PreferenceStore;
import org.eclipse.jface.util.IPropertyChangeListener;
import org.eclipse.jface.util.PropertyChangeEvent;

/**
 * 
 */
public class OverlayPreferenceStore implements IPreferenceStore {

    // Inner Classes -----------------------------------------------------------

    /**
     * Descriptor used to denote data types.
     */
    public static final class Type {
        protected Type() {
        }
    }

    /**
     * Data structure for the overlay key.
     */
    public static class OverlayKey {

        private Type fType;
        private String fKey;

        public OverlayKey(Type type, String key) {
            this.fType = type;
            this.fKey = key;
        }
    }

    /**
     * @see IPropertyChangeListener
     */
    private class PropertyListener implements IPropertyChangeListener {

        /**
         * @see IPropertyChangeListener#propertyChange(PropertyChangeEvent)
         */
        public void propertyChange(PropertyChangeEvent event) {
            OverlayKey key = findOverlayKey(event.getProperty());
            if (key != null) {
                propagateProperty(fParent, key, fStore);
            }
        }
    }

    // Constants ---------------------------------------------------------------

    /**
     * Boolean property type.
     */
    public static final Type BOOLEAN = new Type();

    /**
     * Double property type.
     */
    public static final Type DOUBLE = new Type();

    /**
     * Floating point property type.
     */
    public static final Type FLOAT = new Type();

    /**
     * Integer property type.
     */
    public static final Type INT = new Type();

    /**
     * Long integer property type.
     */
    public static final Type LONG = new Type();

    /**
     * String property type.
     */
    public static final Type STRING = new Type();

    // Instance Variables ------------------------------------------------------

    /**
     * The parent preference store.
     */
    private IPreferenceStore fParent;

    /**
     * The underlying preference store.
     */
    private IPreferenceStore fStore;

    /**
     * The keys of this store.
     */
    private List fOverlayKeys = new ArrayList();

    /**
     * The property listener.
     */
    private PropertyListener fPropertyListener;

    // Constructors ------------------------------------------------------------

    /**
     * Creates and returns a new overlay preference store.
     * 
     * @param parent the parent preference store
     * @param overlayKeys the overlay keys
     */
    public OverlayPreferenceStore(IPreferenceStore parent) {
        this.fParent = parent;
        fStore = new PreferenceStore();
    }

    // Public Methods ----------------------------------------------------------

    public void addKey(Type type, String key) {
        this.fOverlayKeys.add(new OverlayKey(type, key));
    }
    public void addBooleanKey(String key) {
        addKey(BOOLEAN, key);
    }
    public void addDoubleKey(String key) {
        addKey(DOUBLE, key);
    }
    public void addFloatKey(String key) {
        addKey(FLOAT, key);
    }
    public void addIntKey(String key) {
        addKey(INT, key);
    }
    public void addLongKey(String key) {
        addKey(LONG, key);
    }
    public void addStringKey(String key) {
        addKey(STRING, key);
    }

    /**
     * Propagates all overlay keys from this store to the parent store.
     */
    public void propagate() {
        for (Iterator i = fOverlayKeys.iterator(); i.hasNext(); ) {
            propagateProperty(fStore, (OverlayKey) i.next(), fParent);
        }
    }

    /**
     * Loads the values from the parent into this store.
     */
    public void load() {
        for (Iterator i = fOverlayKeys.iterator(); i.hasNext(); ) {
            loadProperty(fParent, (OverlayKey) i.next(), fStore, true);
        }
    }

    /**
     * Loads the default values.
     */
    public void loadDefaults() {
        for (Iterator i = fOverlayKeys.iterator(); i.hasNext(); ) {
            setToDefault(((OverlayKey) i.next()).fKey);
        }
    }

    /**
     * Starts to listen for changes.
     */
    public void startListening() {
        if (fPropertyListener == null) {
            fPropertyListener = new PropertyListener();
            fParent.addPropertyChangeListener(fPropertyListener);
        }
    }

    /**
     * Stops to listen for changes.
     */
    public void stopListening() {
        if (fPropertyListener != null) {
            fParent.removePropertyChangeListener(fPropertyListener);
            fPropertyListener = null;
        }
    }

    // IPreferenceStore Implementation -----------------------------------------

    /**
     * @see IPreferenceStore#addPropertyChangeListener(org.eclipse.jface.util.IPropertyChangeListener)
     */
    public void addPropertyChangeListener(IPropertyChangeListener listener) {
        fStore.addPropertyChangeListener(listener);
    }

    /**
     * @see IPreferenceStore#removePropertyChangeListener(org.eclipse.jface.util.IPropertyChangeListener)
     */
    public void removePropertyChangeListener(IPropertyChangeListener listener) {
        fStore.removePropertyChangeListener(listener);
    }

    /**
     * @see IPreferenceStore#firePropertyChangeEvent(java.lang.String, java.lang.Object, java.lang.Object)
     */
    public void firePropertyChangeEvent(String name, Object oldValue,
        Object newValue) {
        fStore.firePropertyChangeEvent(name, oldValue, newValue);
    }

    /**
     * @see IPreferenceStore#contains(java.lang.String)
     */
    public boolean contains(String name) {
        return fStore.contains(name);
    }

    /**
     * @see IPreferenceStore#getBoolean(java.lang.String)
     */
    public boolean getBoolean(String name) {
        return fStore.getBoolean(name);
    }

    /**
     * @see IPreferenceStore#getDefaultBoolean(java.lang.String)
     */
    public boolean getDefaultBoolean(String name) {
        return fStore.getDefaultBoolean(name);
    }

    /**
     * @see IPreferenceStore#getDefaultDouble(java.lang.String)
     */
    public double getDefaultDouble(String name) {
        return fStore.getDefaultDouble(name);
    }

    /**
     * @see IPreferenceStore#getDefaultFloat(String)
     */
    public float getDefaultFloat(String name) {
        return fStore.getDefaultFloat(name);
    }

    /**
     * @see IPreferenceStore#getDefaultInt(String)
     */
    public int getDefaultInt(String name) {
        return fStore.getDefaultInt(name);
    }

    /**
     * @see IPreferenceStore#getDefaultLong(String)
     */
    public long getDefaultLong(String name) {
        return fStore.getDefaultLong(name);
    }

    /**
     * @see IPreferenceStore#getDefaultString(String)
     */
    public String getDefaultString(String name) {
        return fStore.getDefaultString(name);
    }

    /**
     * @see IPreferenceStore#getDouble(String)
     */
    public double getDouble(String name) {
        return fStore.getDouble(name);
    }

    /**
     * @see IPreferenceStore#getFloat(String)
     */
    public float getFloat(String name) {
        return fStore.getFloat(name);
    }

    /**
     * @see IPreferenceStore#getInt(String)
     */
    public int getInt(String name) {
        return fStore.getInt(name);
    }

    /**
     * @see IPreferenceStore#getLong(String)
     */
    public long getLong(String name) {
        return fStore.getLong(name);
    }

    /**
     * @see IPreferenceStore#getString(String)
     */
    public String getString(String name) {
        return fStore.getString(name);
    }

    /**
     * @see IPreferenceStore#isDefault(String)
     */
    public boolean isDefault(String name) {
        return fStore.isDefault(name);
    }

    /**
     * @see IPreferenceStore#needsSaving()
     */
    public boolean needsSaving() {
        return fStore.needsSaving();
    }

    /**
     * @see IPreferenceStore#putValue(String, String)
     */
    public void putValue(String name, String value) {
        if (covers(name)) {
            fStore.putValue(name, value);
        }
    }

    /**
     * @see IPreferenceStore#setDefault(String, double)
     */
    public void setDefault(String name, double value) {
        if (covers(name)) {
            fStore.setDefault(name, value);
        }
    }

    /**
     * @see IPreferenceStore#setDefault(String, float)
     */
    public void setDefault(String name, float value) {
        if (covers(name)) {
            fStore.setDefault(name, value);
        }
    }

    /**
     * @see IPreferenceStore#setDefault(String, int)
     */
    public void setDefault(String name, int value) {
        if (covers(name)) {
            fStore.setDefault(name, value);
        }
    }

    /**
     * @see IPreferenceStore#setDefault(String, long)
     */
    public void setDefault(String name, long value) {
        if (covers(name)) {
            fStore.setDefault(name, value);
        }
    }

    /**
     * @see IPreferenceStore#setDefault(String, String)
     */
    public void setDefault(String name, String value) {
        if (covers(name)) {
            fStore.setDefault(name, value);
        }
    }

    /**
     * @see IPreferenceStore#setDefault(String, boolean)
     */
    public void setDefault(String name, boolean value) {
        if (covers(name)) {
            fStore.setDefault(name, value);
        }
    }

    /**
     * @see IPreferenceStore#setToDefault(String)
     */
    public void setToDefault(String name) {
        fStore.setToDefault(name);
    }

    /**
     * @see IPreferenceStore#setValue(String, double)
     */
    public void setValue(String name, double value) {
        if (covers(name)) {
            fStore.setValue(name, value);
        }
    }

    /**
     * @see IPreferenceStore#setValue(String, float)
     */
    public void setValue(String name, float value) {
        if (covers(name)) {
            fStore.setValue(name, value);
        }
    }

    /**
     * @see IPreferenceStore#setValue(String, int)
     */
    public void setValue(String name, int value) {
        if (covers(name)) {
            fStore.setValue(name, value);
        }
    }

    /**
     * @see IPreferenceStore#setValue(String, long)
     */
    public void setValue(String name, long value) {
        if (covers(name)) {
            fStore.setValue(name, value);
        }
    }

    /**
     * @see IPreferenceStore#setValue(String, String)
     */
    public void setValue(String name, String value) {
        if (covers(name)) {
            fStore.setValue(name, value);
        }
    }

    /**
     * @see IPreferenceStore#setValue(String, boolean)
     */
    public void setValue(String name, boolean value) {
        if (covers(name)) {
            fStore.setValue(name, value);
        }
    }

    // Protected Methods -------------------------------------------------------

    /**
     * Tries to find and return the overlay key for the given preference key
     * string.
     * 
     * @param key the preference key string
     * @return the overlay key or <code>null</code> if none can be found
     */
    protected final OverlayKey findOverlayKey(String key) {
        for (Iterator i = fOverlayKeys.iterator(); i.hasNext(); ) {
            OverlayKey k = (OverlayKey) i.next();
            if (k.fKey.equals(key)) {
                return k;
            }
        }
        return null;
    }

    /**
     * Propagates the given overlay key from the orgin to the target preference
     * store.
     * 
     * @param origin the source preference store
     * @param key the overlay key
     * @param target the preference store to which the key is propagated
     */
    protected final void propagateProperty(IPreferenceStore origin,
        OverlayKey key, IPreferenceStore target) {
        if (origin.isDefault(key.fKey)) {
            if (!target.isDefault(key.fKey)) {
                target.setToDefault(key.fKey);
            }
            return;
        }
        Type d = key.fType;
        if (BOOLEAN == d) {
            boolean originValue = origin.getBoolean(key.fKey);
            boolean targetValue = target.getBoolean(key.fKey);
            if (targetValue != originValue) {
                target.setValue(key.fKey, originValue);
            }
        } else if (DOUBLE == d) {
            double originValue = origin.getDouble(key.fKey);
            double targetValue = target.getDouble(key.fKey);
            if (targetValue != originValue) {
                target.setValue(key.fKey, originValue);
            }
        } else if (FLOAT == d) {
            float originValue = origin.getFloat(key.fKey);
            float targetValue = target.getFloat(key.fKey);
            if (targetValue != originValue) {
                target.setValue(key.fKey, originValue);
            }
        } else if (INT == d) {
            int originValue = origin.getInt(key.fKey);
            int targetValue = target.getInt(key.fKey);
            if (targetValue != originValue) {
                target.setValue(key.fKey, originValue);
            }
        } else if (LONG == d) {
            long originValue = origin.getLong(key.fKey);
            long targetValue = target.getLong(key.fKey);
            if (targetValue != originValue) {
                target.setValue(key.fKey, originValue);
            }
        } else if (STRING == d) {
            String originValue = origin.getString(key.fKey);
            String targetValue = target.getString(key.fKey);
            if ((targetValue != null) && (originValue != null)
             && !targetValue.equals(originValue)) {
                target.setValue(key.fKey, originValue);
            }
        }
    }

    // Private Methods ---------------------------------------------------------

    /**
     * Tells whether the given preference key string is
     * covered by this overlay store.
     * 
     * @param key the preference key string
     * @return <code>true</code> if this overlay store covers the given key
     */
    private boolean covers(String key) {
        return (findOverlayKey(key) != null);
    }

    /**
     * Loads the given key from the orgin into the target.
     * 
     * @param orgin the source preference store
     * @param key the overlay key
     * @param target the preference store to which the key is propagated
     * @param forceInitialization if <code>true</code> the value in the target
     *        gets initialized before loading
     */
    private void loadProperty(IPreferenceStore orgin, OverlayKey key,
        IPreferenceStore target, boolean forceInitialization) {
        Type d = key.fType;
        if (BOOLEAN == d) {
            if (forceInitialization) {
                target.setValue(key.fKey, true);
            }
            target.setValue(key.fKey, orgin.getBoolean(key.fKey));
            target.setDefault(key.fKey, orgin.getDefaultBoolean(key.fKey));
        } else if (DOUBLE == d) {
            if (forceInitialization) {
                target.setValue(key.fKey, 1.0D);
            }
            target.setValue(key.fKey, orgin.getDouble(key.fKey));
            target.setDefault(key.fKey, orgin.getDefaultDouble(key.fKey));
        } else if (FLOAT == d) {
            if (forceInitialization) {
                target.setValue(key.fKey, 1.0F);
            }
            target.setValue(key.fKey, orgin.getFloat(key.fKey));
            target.setDefault(key.fKey, orgin.getDefaultFloat(key.fKey));
        } else if (INT == d) {
            if (forceInitialization) {
                target.setValue(key.fKey, 1);
            }
            target.setValue(key.fKey, orgin.getInt(key.fKey));
            target.setDefault(key.fKey, orgin.getDefaultInt(key.fKey));
        } else if (LONG == d) {
            if (forceInitialization) {
                target.setValue(key.fKey, 1L);
            }
            target.setValue(key.fKey, orgin.getLong(key.fKey));
            target.setDefault(key.fKey, orgin.getDefaultLong(key.fKey));
        } else if (STRING == d) {
            if (forceInitialization) {
                target.setValue(key.fKey, "1"); //$NON-NLS-1$
            }
            target.setValue(key.fKey, orgin.getString(key.fKey));
            target.setDefault(key.fKey, orgin.getDefaultString(key.fKey));
        }
    }

}
