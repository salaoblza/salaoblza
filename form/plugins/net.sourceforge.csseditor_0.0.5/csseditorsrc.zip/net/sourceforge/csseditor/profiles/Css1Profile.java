/*
 * Copyright (c) 2003 Christopher Lenz and others.
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 * 
 * Contributors:
 *     Christopher Lenz - initial API and implementation
 * 
 * $Id: Css1Profile.java,v 1.1.1.1 2003/12/14 21:59:57 cell Exp $
 */

package net.sourceforge.csseditor.profiles;

import net.sourceforge.csseditor.AbstractProfile;
import net.sourceforge.csseditor.IProfileDescriptor;
import net.sourceforge.csseditor.internal.CssEditorMessages;

/**
 * Implementation of the CSS Level 1 profile
 * (<a href="http://www.w3.org/TR/CSS1">http://www.w3.org/TR/CSS1</a>).
 */
public class Css1Profile extends AbstractProfile {

    // Constants ---------------------------------------------------------------

    protected static final String CATEGORY_BOX =
        CssEditorMessages.getString("CssProfile.category.box"); //$NON-NLS-1$
    protected static final String CATEGORY_COLOR_BACKGROUND =
        CssEditorMessages.getString(
            "CssProfile.category.colorAndBackground"); //$NON-NLS-1$
    protected static final String CATEGORY_FONT =
        CssEditorMessages.getString("CssProfile.category.font"); //$NON-NLS-1$
    protected static final String CATEGORY_TEXT =
        CssEditorMessages.getString("CssProfile.category.text"); //$NON-NLS-1$
    protected static final String CATEGORY_VISUAL_FORMATTING =
        CssEditorMessages.getString(
            "CssProfile.category.visualFormatting"); //$NON-NLS-1$

    // Constructors ------------------------------------------------------------

    public Css1Profile(IProfileDescriptor descriptor) {
        super(descriptor);
        initializeAtKeywords();
        initializeProperties();
        initializePseudoClasses();
    }

    // Private Methods ---------------------------------------------------------

    private void initializeAtKeywords() {
        addAtKeyword("import"); //$NON-NLS-1$
    }

    private void initializeProperties() {
        addProperty("font", CATEGORY_FONT, true); //$NON-NLS-1$
        addProperty("font-family", CATEGORY_FONT); //$NON-NLS-1$
        addProperty("font-size", CATEGORY_FONT); //$NON-NLS-1$
        addProperty("font-style", CATEGORY_FONT); //$NON-NLS-1$
        addProperty("font-variant", CATEGORY_FONT); //$NON-NLS-1$
        addProperty("font-weight", CATEGORY_FONT); //$NON-NLS-1$
        addProperty("background", //$NON-NLS-1$
            CATEGORY_COLOR_BACKGROUND, true);
        addProperty("background-attachment", //$NON-NLS-1$
            CATEGORY_COLOR_BACKGROUND);
        addProperty("background-color", //$NON-NLS-1$
            CATEGORY_COLOR_BACKGROUND);
        addProperty("background-image", //$NON-NLS-1$
            CATEGORY_COLOR_BACKGROUND);
        addProperty("background-position", //$NON-NLS-1$
            CATEGORY_COLOR_BACKGROUND);
        addProperty("background-repeat", //$NON-NLS-1$
            CATEGORY_COLOR_BACKGROUND);
        addProperty("color", CATEGORY_COLOR_BACKGROUND); //$NON-NLS-1$
        addProperty("border", CATEGORY_BOX, true); //$NON-NLS-1$
        addProperty("border-bottom", CATEGORY_BOX, true); //$NON-NLS-1$
        addProperty("border-bottom-width", CATEGORY_BOX); //$NON-NLS-1$
        addProperty("border-color", CATEGORY_BOX); //$NON-NLS-1$
        addProperty("border-left", CATEGORY_BOX, true); //$NON-NLS-1$
        addProperty("border-left-width", CATEGORY_BOX); //$NON-NLS-1$
        addProperty("border-right", CATEGORY_BOX, true); //$NON-NLS-1$
        addProperty("border-right-width", CATEGORY_BOX); //$NON-NLS-1$
        addProperty("border-style", CATEGORY_BOX); //$NON-NLS-1$
        addProperty("border-top", CATEGORY_BOX, true); //$NON-NLS-1$
        addProperty("border-top-width", CATEGORY_BOX); //$NON-NLS-1$
        addProperty("border-width", CATEGORY_BOX); //$NON-NLS-1$
        addProperty("clear", CATEGORY_BOX); //$NON-NLS-1$
        addProperty("float", CATEGORY_BOX); //$NON-NLS-1$
        addProperty("height", CATEGORY_BOX); //$NON-NLS-1$
        addProperty("margin", CATEGORY_BOX, true); //$NON-NLS-1$
        addProperty("margin-bottom", CATEGORY_BOX); //$NON-NLS-1$
        addProperty("margin-left", CATEGORY_BOX); //$NON-NLS-1$
        addProperty("margin-right", CATEGORY_BOX); //$NON-NLS-1$
        addProperty("margin-top", CATEGORY_BOX); //$NON-NLS-1$
        addProperty("padding", CATEGORY_BOX, true); //$NON-NLS-1$
        addProperty("padding-bottom", CATEGORY_BOX); //$NON-NLS-1$
        addProperty("padding-left", CATEGORY_BOX); //$NON-NLS-1$
        addProperty("padding-right", CATEGORY_BOX); //$NON-NLS-1$
        addProperty("padding-top", CATEGORY_BOX); //$NON-NLS-1$
        addProperty("width", CATEGORY_BOX); //$NON-NLS-1$
        addProperty("letter-spacing", CATEGORY_TEXT); //$NON-NLS-1$
        addProperty("line-height", CATEGORY_TEXT); //$NON-NLS-1$
        addProperty("text-align", CATEGORY_TEXT); //$NON-NLS-1$
        addProperty("text-decoration", CATEGORY_TEXT); //$NON-NLS-1$
        addProperty("text-indent", CATEGORY_TEXT); //$NON-NLS-1$
        addProperty("text-transform", CATEGORY_TEXT); //$NON-NLS-1$
        addProperty("vertical-align", CATEGORY_TEXT); //$NON-NLS-1$
        addProperty("white-space", CATEGORY_TEXT); //$NON-NLS-1$
        addProperty("word-spacing", CATEGORY_TEXT); //$NON-NLS-1$
        addProperty("display", //$NON-NLS-1$
            CATEGORY_VISUAL_FORMATTING);
        addProperty("list-style", //$NON-NLS-1$
            CATEGORY_VISUAL_FORMATTING, true);
        addProperty("list-style-image", //$NON-NLS-1$
            CATEGORY_VISUAL_FORMATTING);
        addProperty("list-style-position", //$NON-NLS-1$
            CATEGORY_VISUAL_FORMATTING);
        addProperty("list-style-type", //$NON-NLS-1$
            CATEGORY_VISUAL_FORMATTING);
    }

    private void initializePseudoClasses() {
        addPseudoClass("active"); //$NON-NLS-1$
        addPseudoClass("first-letter"); //$NON-NLS-1$
        addPseudoClass("first-line"); //$NON-NLS-1$
        addPseudoClass("link"); //$NON-NLS-1$
        addPseudoClass("visited"); //$NON-NLS-1$
    }

}
