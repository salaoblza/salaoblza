/*
 * Copyright (c) 2003 Christopher Lenz and others.
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 * 
 * Contributors:
 *     Christopher Lenz - initial API and implementation
 * 
 * $Id: Css2Profile.java,v 1.2 2004/01/12 18:14:41 cell Exp $
 */

package net.sourceforge.csseditor.profiles;

import net.sourceforge.csseditor.IProfileDescriptor;
import net.sourceforge.csseditor.internal.CssEditorMessages;

/**
 * Implementation of the CSS Level 2 profile
 * (<a href="http://www.w3.org/TR/CSS2">http://www.w3.org/TR/CSS2</a>).
 */
public class Css2Profile extends Css1Profile {

    // Constants ---------------------------------------------------------------

    protected static final String CATEGORY_AURAL =
        CssEditorMessages.getString("CssProfile.category.aural"); //$NON-NLS-1$
    protected static final String CATEGORY_GENERATED_CONTENT =
        CssEditorMessages.getString(
            "CssProfile.category.generatedContent"); //$NON-NLS-1$
    protected static final String CATEGORY_PAGED_MEDIA =
        CssEditorMessages.getString(
            "CssProfile.category.pagedMedia"); //$NON-NLS-1$
    protected static final String CATEGORY_TABLE =
        CssEditorMessages.getString("CssProfile.category.table"); //$NON-NLS-1$
    protected static final String CATEGORY_USER_INTERFACE =
        CssEditorMessages.getString(
            "CssProfile.category.userInterface"); //$NON-NLS-1$
    protected static final String CATEGORY_VISUAL_EFFECTS =
        CssEditorMessages.getString(
            "CssProfile.category.visualEffects"); //$NON-NLS-1$

    // Constructors ------------------------------------------------------------

    public Css2Profile(IProfileDescriptor descriptor) {
        super(descriptor);
        initializeAtKeywords();
        initializeProperties();
        initializePseudoClasses();
    }

    // Private Methods ---------------------------------------------------------

    private void initializeAtKeywords() {
        addAtKeyword("charset"); //$NON-NLS-1$
        addAtKeyword("font-face"); //$NON-NLS-1$
        addAtKeyword("media"); //$NON-NLS-1$
        addAtKeyword("page"); //$NON-NLS-1$
    }

    private void initializeProperties() {
        addProperty("font-stretch", CATEGORY_FONT); //$NON-NLS-1$
        addProperty("unicode-bidi", CATEGORY_TEXT); //$NON-NLS-1$
        addProperty("direction", CATEGORY_TEXT); //$NON-NLS-1$
        addProperty("border-bottom-color", CATEGORY_BOX); //$NON-NLS-1$
        addProperty("border-bottom-style", CATEGORY_BOX); //$NON-NLS-1$
        addProperty("border-collapse", CATEGORY_TABLE); //$NON-NLS-1$
        addProperty("border-left-color", CATEGORY_BOX); //$NON-NLS-1$
        addProperty("border-left-style", CATEGORY_BOX); //$NON-NLS-1$
        addProperty("border-right-color", CATEGORY_BOX); //$NON-NLS-1$
        addProperty("border-right-style", CATEGORY_BOX); //$NON-NLS-1$
        addProperty("border-top-color", CATEGORY_BOX); //$NON-NLS-1$
        addProperty("border-top-style", CATEGORY_BOX); //$NON-NLS-1$
        addProperty("border-spacing", CATEGORY_TABLE); //$NON-NLS-1$
        addProperty("caption-side", CATEGORY_TABLE); //$NON-NLS-1$
        addProperty("empty-cells", CATEGORY_TABLE); //$NON-NLS-1$
        addProperty("table-layout", CATEGORY_TABLE); //$NON-NLS-1$
        addProperty("bottom", CATEGORY_VISUAL_FORMATTING); //$NON-NLS-1$
        addProperty("clip", CATEGORY_VISUAL_EFFECTS); //$NON-NLS-1$
        addProperty("content", CATEGORY_GENERATED_CONTENT); //$NON-NLS-1$
        addProperty("counter-increment", //$NON-NLS-1$
            CATEGORY_GENERATED_CONTENT);
        addProperty("counter-reset", CATEGORY_GENERATED_CONTENT); //$NON-NLS-1$
        addProperty("azimuth", CATEGORY_AURAL); //$NON-NLS-1$
        addProperty("cue", CATEGORY_AURAL, true); //$NON-NLS-1$
        addProperty("cue-after", CATEGORY_AURAL); //$NON-NLS-1$
        addProperty("cue-before", CATEGORY_AURAL); //$NON-NLS-1$
        addProperty("cursor", CATEGORY_USER_INTERFACE); //$NON-NLS-1$
        addProperty("elevation", CATEGORY_AURAL); //$NON-NLS-1$
        addProperty("left", CATEGORY_VISUAL_FORMATTING); //$NON-NLS-1$
        addProperty("max-height", CATEGORY_VISUAL_FORMATTING); //$NON-NLS-1$
        addProperty("max-width", CATEGORY_VISUAL_FORMATTING); //$NON-NLS-1$
        addProperty("min-height", CATEGORY_VISUAL_FORMATTING); //$NON-NLS-1$
        addProperty("min-width", CATEGORY_VISUAL_FORMATTING); //$NON-NLS-1$
        addProperty("orphans", CATEGORY_PAGED_MEDIA); //$NON-NLS-1$
        addProperty("outline", CATEGORY_USER_INTERFACE); //$NON-NLS-1$
        addProperty("outline-color", CATEGORY_USER_INTERFACE); //$NON-NLS-1$
        addProperty("outline-style", CATEGORY_USER_INTERFACE); //$NON-NLS-1$
        addProperty("outline-width", CATEGORY_USER_INTERFACE); //$NON-NLS-1$
        addProperty("overflow", CATEGORY_VISUAL_EFFECTS); //$NON-NLS-1$
        addProperty("page-break-after", CATEGORY_PAGED_MEDIA); //$NON-NLS-1$
        addProperty("page-break-before", CATEGORY_PAGED_MEDIA); //$NON-NLS-1$
        addProperty("page-break-inside", CATEGORY_PAGED_MEDIA); //$NON-NLS-1$
        addProperty("pause", CATEGORY_AURAL, true); //$NON-NLS-1$
        addProperty("pause-after", CATEGORY_AURAL); //$NON-NLS-1$
        addProperty("pause-before", CATEGORY_AURAL); //$NON-NLS-1$
        addProperty("pitch", CATEGORY_AURAL); //$NON-NLS-1$
        addProperty("pitch-range", CATEGORY_AURAL); //$NON-NLS-1$
        addProperty("play-during", CATEGORY_AURAL); //$NON-NLS-1$
        addProperty("position", CATEGORY_VISUAL_FORMATTING); //$NON-NLS-1$
        addProperty("quotes", CATEGORY_AURAL); //$NON-NLS-1$
        addProperty("richness", CATEGORY_AURAL); //$NON-NLS-1$
        addProperty("right", CATEGORY_VISUAL_FORMATTING); //$NON-NLS-1$
        addProperty("speak", CATEGORY_AURAL, true); //$NON-NLS-1$
        addProperty("speak-header", CATEGORY_AURAL); //$NON-NLS-1$
        addProperty("speak-numeral", CATEGORY_AURAL); //$NON-NLS-1$
        addProperty("speak-punctuation", CATEGORY_AURAL); //$NON-NLS-1$
        addProperty("speech-rate", CATEGORY_AURAL); //$NON-NLS-1$
        addProperty("text-shadow", CATEGORY_TEXT); //$NON-NLS-1$
        addProperty("stress", CATEGORY_AURAL); //$NON-NLS-1$
        addProperty("top", CATEGORY_VISUAL_FORMATTING); //$NON-NLS-1$
        addProperty("visibility", CATEGORY_VISUAL_EFFECTS); //$NON-NLS-1$
        addProperty("voice-family", CATEGORY_AURAL); //$NON-NLS-1$
        addProperty("volume", CATEGORY_AURAL); //$NON-NLS-1$
        addProperty("widows", CATEGORY_PAGED_MEDIA); //$NON-NLS-1$
        addProperty("z-index", CATEGORY_VISUAL_FORMATTING); //$NON-NLS-1$
    }

    private void initializePseudoClasses() {
        addPseudoClass("after"); //$NON-NLS-1$
        addPseudoClass("before"); //$NON-NLS-1$
        addPseudoClass("first-child"); //$NON-NLS-1$
        addPseudoClass("focus"); //$NON-NLS-1$
        addPseudoClass("hover"); //$NON-NLS-1$
        addPseudoClass("land"); //$NON-NLS-1$
        addPseudoClass("left"); //$NON-NLS-1$
        addPseudoClass("right"); //$NON-NLS-1$
    }
}
