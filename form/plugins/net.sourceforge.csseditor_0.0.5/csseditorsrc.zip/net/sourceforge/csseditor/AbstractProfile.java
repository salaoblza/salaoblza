/*
 * Copyright (c) 2003 Christopher Lenz and others.
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 * 
 * Contributors:
 *     Christopher Lenz - initial API and implementation
 * 
 * $Id: AbstractProfile.java,v 1.1.1.1 2003/12/14 21:59:32 cell Exp $
 */

package net.sourceforge.csseditor;

import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import net.sourceforge.csseditor.internal.model.PropertyInfo;
import net.sourceforge.csseditor.model.IPropertyInfo;

/**
 * Abstract implementation of the <code>IProfile</code> interface.
 */
public abstract class AbstractProfile implements IProfile {

    // Instance Variables ------------------------------------------------------

    /**
     * The associated descriptor, as passed into the constructor by the profile
     * manager when the profile is instantiated.
     */
    private IProfileDescriptor descriptor;

    /**
     * Map of the property names of this profile, containing the 
     * <code>IPropertyInfo</code> objects keyed by property name.
     */
    private Map properties = new HashMap();

    /**
     * Set of the at rule keywords known to the profile.
     */
    private Set atKeywords = new HashSet();

    /**
     * Set of the at pseudo-classes known to the profile.
     */
    private Set pseudoClasses = new HashSet();

    // Constructors ------------------------------------------------------------

    /**
     * Constructor.
     * 
     * @param descriptor the profile descriptor
     */
    public AbstractProfile(IProfileDescriptor descriptor) {
        this.descriptor = descriptor;
    }

    // IProfile Implementation -------------------------------------------------

    /**
     * @see net.sourceforge.csseditor.IProfile#getDescriptor()
     */
    public final IProfileDescriptor getDescriptor() {
        return this.descriptor;
    }

    /**
     * @see IProfile#getAtKeywords()
     */
    public final Collection getAtKeywords() {
        return Collections.unmodifiableSet(this.atKeywords);
    }

    /**
     * @see IProfile#getProperties()
     */
    public final Collection getProperties() {
        return Collections.unmodifiableSet(this.properties.keySet());
    }

    /**
     * @see IProfile#getPropertyInfo(java.lang.String)
     */
    public final IPropertyInfo getPropertyInfo(String propertyName) {
        return (IPropertyInfo) this.properties.get(propertyName);
    }

    /**
     * @see IProfile#getPseudoClassNames()
     */
    public final Collection getPseudoClassNames() {
        return Collections.unmodifiableSet(this.pseudoClasses);
    }

    // Protected Methods -------------------------------------------------------

    protected final void addAtKeyword(String atKeyword) {
        this.atKeywords.add(atKeyword);
    }

    protected final void addProperty(String name, String category) {
        addProperty(new PropertyInfo(name, category));
    }

    protected final void addProperty(String name, String category,
        boolean shorthand) {
        addProperty(new PropertyInfo(name, category, shorthand));
    }

    protected final void addProperty(IPropertyInfo info) {
        this.properties.put(info.getName(), info);
    }

    protected final void addPseudoClass(String pseudoClass) {
        this.pseudoClasses.add(pseudoClass);
    }

}
