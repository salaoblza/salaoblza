/*******************************************************************************
 * Copyright (c) 2003 Christopher Lenz and others.
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 * 
 * Contributors:
 *     Christopher Lenz - initial API and implementation
 * 
 * $Id: IProblem.java,v 1.1.1.1 2003/12/14 21:59:56 cell Exp $
 ******************************************************************************/

package net.sourceforge.csseditor.parser;

/**
 * 
 */
public interface IProblem {

    /**
     * Returns the problem identifier.
     * 
     * @return the problem id
     */
    String getId();

    /**
     * Returns a localized, human-readable message string which describes the
     * problem.
     * 
     * @return the problem message
     */
    String getMessage();

    /**
     * Returns the file name in which the problem was found.
     * 
     * @return the file name in which the problem was found
     */
    String getOriginatingFileName();
    
    /**
     * Returns the end position of the problem (inclusive).
     * 
     * @return the end position of the problem), or -1 if unknown
     */
    int getSourceEnd();

    /**
     * Returns the line number of the source where the problem begins.
     * 
     * @return the line number of the source where the problem begins
     */
    int getSourceLineNumber();

    /**
     * Returns the start position of the problem (inclusive).
     * 
     * @return the start position of the problem, or -1 if unknown
     */
    int getSourceStart();

    /**
     * Returns whether the problem is an error.
     * 
     * @return <code>true</code> if the problem is an error, <code>false</code>
     *         otherwise
     */
    boolean isError();

    /**
     * Returns whether the problem is a warning.
     * 
     * @return <code>true</code> if the problem is a warning, <code>false</code>
     *         otherwise
     */
    boolean isWarning();

}
