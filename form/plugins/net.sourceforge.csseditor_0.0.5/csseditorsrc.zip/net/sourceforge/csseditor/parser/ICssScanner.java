/*******************************************************************************
 * Copyright (c) 2003 Christopher Lenz and others.
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 * 
 * Contributors:
 *     Christopher Lenz - initial API and implementation
 * 
 * $Id: ICssScanner.java,v 1.1.1.1 2003/12/14 21:59:56 cell Exp $
 ******************************************************************************/

package net.sourceforge.csseditor.parser;

import org.eclipse.jface.text.IDocument;
import org.eclipse.jface.text.IRegion;

/**
 * Interface for classes that implement the lexical scanning of CSS source code.
 * 
 * TODO Add a way to only parse a specific range of an IDocument
 */
public interface ICssScanner extends IProblemReporter {

    // Methods -----------------------------------------------------------------

    /**
     * Returns the starting position of the current token inside the original 
     * source. This position is zero-based and inclusive. It corresponds to the 
     * position of the first character which is part of this token.
     * 
     * @return the starting position of the current token inside the original
     *         source
     */
    IRegion getTokenRegion();

    /**
     * Read the next token in the source, and returns the value corresponding
     * to the symbolic constant corresponding to the token type (as defined by
     * the constants in this interface), or with read character itself.
     * 
     * @return the next token
     * @throws LexicalErrorException in case a lexical error was detected while 
     *         trying to retrieve the current token
     */
    int getNextToken() throws LexicalErrorException;

    /**
     * Sets the document that contains the source style sheet.
     * 
     * TODO Add parameters for range limitation
     * 
     * @param source The document containing the style sheet source
     */
    void setSource(IDocument source);

}
