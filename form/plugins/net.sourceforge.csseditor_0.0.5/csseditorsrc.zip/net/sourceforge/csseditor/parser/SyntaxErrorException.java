/*******************************************************************************
 * Copyright (c) 2003 Christopher Lenz and others.
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 * 
 * Contributors:
 *     Christopher Lenz - initial API and implementation
 * 
 * $Id: SyntaxErrorException.java,v 1.1.1.1 2003/12/14 21:59:57 cell Exp $
 ******************************************************************************/

package net.sourceforge.csseditor.parser;

/**
 * 
 */
public class SyntaxErrorException extends Exception {

    // Instance Variables ------------------------------------------------------

    /**
     * The line number at which the error was detected in the source.
     */
    private int lineNumber;

    /**
     * The offset into the document.
     */
    private int offset;

    /**
     * The length of the source range affected by the syntax error.
     */
    private int length;

    // Constructors ------------------------------------------------------------

    /**
     * Constructor.
     */
    public SyntaxErrorException() {
        super();
    }

    /**
     * Constructor.
     * 
     * @param message the exception message
     */
    public SyntaxErrorException(String message) {
        super(message);
    }

    /**
     * Constructor.
     * 
     * @param message the exception message
     * @param lineNumber the line number
     * @param offset the offset
     * @param length the length
     */
    public SyntaxErrorException(String message, int lineNumber, int offset,
        int length) {
        super(message + " (" + lineNumber + ")"); //$NON-NLS-1$ //$NON-NLS-2$
        this.lineNumber = lineNumber;
        this.offset = offset;
        this.length = length;
    }

    // Public Methods ----------------------------------------------------------

    /**
     * Returns the length of the offending code
     * 
     * @return the length of the offending code
     */
    public final int getLength() {
        return this.length;
    }

    /**
     * Returns the line number at which the error was detected.
     * 
     * @return the line number
     */
    public final int getLineNumber() {
        return this.lineNumber;
    }

    /**
     * Returns the offset of the offending code
     * 
     * @return the offset of the offending code
     */
    public final int getOffset() {
        return this.offset;
    }

}
