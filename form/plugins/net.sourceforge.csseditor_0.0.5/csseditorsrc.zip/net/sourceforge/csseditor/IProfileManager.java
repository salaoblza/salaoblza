/*
 * Copyright (c) 2003 Christopher Lenz and others.
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 * 
 * Contributors:
 *     Christopher Lenz - initial API and implementation
 * 
 * $Id: IProfileManager.java,v 1.1.1.1 2003/12/14 21:59:32 cell Exp $
 */

package net.sourceforge.csseditor;

import org.eclipse.core.resources.IResource;

/**
 * Manages the CSS profiles.
 */
public interface IProfileManager {

    /**
     * Returns the list of available profiles.
     * 
     * @return an array containing the descriptors of all available profiles
     */
    IProfileDescriptor[] getProfileDescriptors();

    /**
     * Returns the profile that is selected for the specified resource or 
     * project.
     * 
     * @param resource the resource for which the profile should be retrieved,
     *        or <code>null</code> to retrieve the default profile as specified 
     *        in the plugin preferences
     * @return the profile
     */
    IProfile getProfile(IResource resource);

    /**
     * Sets the profile that should be used for the specified resource. If the 
     * resource is an <code>IProject</code>, the profile will be used as the
     * default profile for all resources in the project. Otherwise, it will be
     * used only for the resource. If the resource is <code>null</code>, the 
     * profile will be selected as the global default profile.
     * 
     * @param resource
     * @param profileId The ID of the profile
     */
    void setProfile(IResource resource, String profileId);

}
