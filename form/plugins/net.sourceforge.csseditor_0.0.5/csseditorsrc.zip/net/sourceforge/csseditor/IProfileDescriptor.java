/*
 * Copyright (c) 2003 Christopher Lenz and others.
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 * 
 * Contributors:
 *     Christopher Lenz - initial API and implementation
 * 
 * $Id: IProfileDescriptor.java,v 1.1.1.1 2003/12/14 21:59:32 cell Exp $
 */

package net.sourceforge.csseditor;


/**
 * 
 */
public interface IProfileDescriptor {

    // Constants ---------------------------------------------------------------

    /**
     * Symbolic constant for the profiles extension point ID.
     */
    String EXTENSION_POINT_ID =
        "net.sourceforge.csseditor.profiles"; //$NON-NLS-1$

    // Methods -----------------------------------------------------------------

    /**
     * @return The ID of the extension
     */
    String getId();

    /**
     * @return The display name of the profile
     */
    String getName();

    /**
     * @return A description of the profile
     */
    String getDescription();

    /**
     * @return The name of the class implementing the profile
     */
    String getClassName();

}
