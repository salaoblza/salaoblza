/*
 * Copyright (c) 2003 Christopher Lenz and others.
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 * 
 * Contributors:
 *     Christopher Lenz - initial API and implementation
 * 
 * $Id: CssTextTools.java,v 1.2 2003/12/27 16:53:09 cell Exp $
 */

package net.sourceforge.csseditor.text;

import org.eclipse.jface.preference.IPreferenceStore;
import org.eclipse.jface.text.IDocument;
import org.eclipse.jface.text.IDocumentExtension3;
import org.eclipse.jface.text.IDocumentPartitioner;
import org.eclipse.jface.text.rules.DefaultPartitioner;
import org.eclipse.jface.text.rules.IPartitionTokenScanner;
import org.eclipse.jface.text.rules.RuleBasedScanner;
import org.eclipse.jface.util.IPropertyChangeListener;
import org.eclipse.jface.util.PropertyChangeEvent;

import net.sourceforge.csseditor.CssEditorPlugin;
import net.sourceforge.csseditor.IProfile;
import net.sourceforge.csseditor.internal.text.CssCodeScanner;
import net.sourceforge.csseditor.internal.text.CssColorManager;
import net.sourceforge.csseditor.internal.text.CssCommentScanner;
import net.sourceforge.csseditor.internal.text.CssPartitionScanner;
import net.sourceforge.csseditor.internal.text.CssStringScanner;

/**
 * Tools required to configure a CSS text viewer.
 * 
 * <p> 
 *   The color manager and all scanner exist only one time, i.e. the same 
 *   instances are returned to all clients. Thus, clients share those tools.
 * </p>
 */
public class CssTextTools {

    // Instance Variables ------------------------------------------------------

    private IPreferenceStore store;

    private IPropertyChangeListener propertyChangeListener =
        new IPropertyChangeListener() {
            public void propertyChange(PropertyChangeEvent event) {
                adaptToPreferenceChange(event);
            }
        };

    private IProfile profile;

    private IColorManager colorManager;

    private CssPartitionScanner partitionScanner;

    private CssCodeScanner codeScanner;

    private CssCommentScanner commentScanner;

    private CssStringScanner stringScanner;

    // Constructors ------------------------------------------------------------

    /**
     * Creates a new CSS text tools collection.
     * 
     * @param store the preference store to initialize the text tools. The text
     *        tools instance installs a listener on the passed preference store
     *        to adapt itself to changes in the preference store.
     */
    public CssTextTools(IPreferenceStore store) {
        this(store, null);
    }

    /**
     * Creates a new CSS text tools collection.
     * 
     * @param store the preference store to initialize the text tools. The text
     *        tools instance installs a listener on the passed preference store
     *        to adapt itself to changes in the preference store.
     * @param profile the CSS profile to use, or <code>null</code> to use the
     *        default profile
     */
    public CssTextTools(IPreferenceStore store, IProfile profile) {
        this(store, profile, true);
    }

    /**
     * Creates a new CSS text tools collection.
     * 
     * @param store the preference store to initialize the text tools. The text
     *        tool instance installs a listener on the passed preference store
     *        to adapt itself to changes in the preference store.
     * @param profile the CSS profile to use, or <code>null</code> to use the
     *        default profile
      * @param autoDisposeOnDisplayDispose if <code>true</code>  the color
     *        manager automatically disposes all managed colors when the current
     *        display gets disposed and all calls to
     *        {@link org.eclipse.jface.text.source.ISharedTextColors#dispose()}
     *        are ignored.
     */
    public CssTextTools(IPreferenceStore store, IProfile profile,
        boolean autoDisposeOnDisplayDispose) {
        this.store = store;
        this.profile = profile;
        if (this.profile == null) {
            // use the default profile
            CssEditorPlugin plugin = CssEditorPlugin.getDefault();
            this.profile = plugin.getProfileManager().getProfile(null);
        }
        this.colorManager = new CssColorManager(autoDisposeOnDisplayDispose);
        this.partitionScanner = new CssPartitionScanner();
        this.codeScanner = new CssCodeScanner(
            this.store, this.colorManager, this.profile);
        this.commentScanner = new CssCommentScanner(
            this.store, this.colorManager);
        this.stringScanner = new CssStringScanner(
            this.store, this.colorManager);
        this.store.addPropertyChangeListener(this.propertyChangeListener);
    }

    // Public Methods ----------------------------------------------------------

    /**
     * Returns whether the specified change to the preference store would effect
     * the presentation of CSS text.
     * 
     * @param event the preference store change event
     * @return <code>true</code> if the specified event affects the presentation
     *         of CSS text, <code>false</code> otherwise
     */
    public boolean affectsPresentation(PropertyChangeEvent event) {
        if (this.codeScanner.affectsPresentation(event)
         || this.commentScanner.affectsPresentation(event)
         || this.stringScanner.affectsPresentation(event)) {
            return true;
        }
        return false;
    }

    /**
     * Factory method for creating a Java-specific document partitioner
     * using this object's partitions scanner. This method is a 
     * convenience method.
     *
     * @return a newly created Java document partitioner
     */
    public IDocumentPartitioner createDocumentPartitioner() {
        String[] types = new String[] {
            CssPartitionScanner.CSS_COMMENT,
            CssPartitionScanner.CSS_STRING
        };
        return new DefaultPartitioner(getPartitionScanner(), types);
    }

    /**
     * Disposes all the individual tools of this tools collection.
     */
    public void dispose() {

        // dispose the scanners
        this.codeScanner = null;
        this.commentScanner = null;
        this.stringScanner = null;
        this.partitionScanner = null;

        // dispose the color manager
        if (this.colorManager != null) {
            this.colorManager.dispose();
            this.colorManager = null;
        }
        
        // detach from the preference store
        if (this.store != null) {
            this.store.removePropertyChangeListener(
                this.propertyChangeListener);
            this.propertyChangeListener = null;
            this.store = null;
        }
    }

    /**
     * Returns the color manager which is used to manage
     * any Java-specific colors needed for such things like syntax highlighting.
     *
     * @return the color manager to be used for Java text viewers
     */
    public IColorManager getColorManager() {
        return this.colorManager;
    }

    /**
     * Returns a scanner which is configured to scan CSS source code.
     *
     * @return a CSS source code scanner
     */
    public RuleBasedScanner getCodeScanner() {
        return this.codeScanner;
    }

    /**
     * Returns a scanner which is configured to scan CSS comments.
     *
     * @return a CSS comment scanner
     */
    public RuleBasedScanner getCommentScanner() {
        return this.commentScanner;
    }

    /**
     * Returns a scanner which is configured to scan CSS strings.
     *
     * @return a CSS string scanner
     */
    public RuleBasedScanner getStringScanner() {
        return this.stringScanner;
    }

    /**
     * Returns a scanner which is configured to scan CSS-specific partitions,
     * which are comments, strings and regular code.
     *
     * @return a CSS partition scanner
     */
    public IPartitionTokenScanner getPartitionScanner() {
        return this.partitionScanner;
    }

    /**
     * Sets up the given document for the default partitioning.
     * 
     * @param document the document to be set up
     */
    public void setupDocument(IDocument document) {
        setupDocument(document, IDocumentExtension3.DEFAULT_PARTITIONING);
    }

    /**
     * Sets up the given document for the given partitioning.
     * 
     * @param document the document to be set up
     * @param partitioning the document partitioning
     */
    public void setupDocument(IDocument document, String partitioning) {
        IDocumentPartitioner partitioner = createDocumentPartitioner();
        if (document instanceof IDocumentExtension3) {
            IDocumentExtension3 extension = (IDocumentExtension3) document;
            extension.setDocumentPartitioner(partitioning, partitioner);
        } else {
            document.setDocumentPartitioner(partitioner);
        }
        partitioner.connect(document);
    }

    // Protected Methods -------------------------------------------------------

    /**
     * Adapts the behavior of the contained components to the change according
     * to the given event.
     * 
     * @param event the event to which to adapt
     */
    protected void adaptToPreferenceChange(PropertyChangeEvent event) {
        if (this.codeScanner.affectsPresentation(event)) {
            this.codeScanner.adaptToPreferenceChange(event);
        }
        if (this.commentScanner.affectsPresentation(event)) {
            this.commentScanner.adaptToPreferenceChange(event);
        }
        if (this.stringScanner.affectsPresentation(event)) {
            this.stringScanner.adaptToPreferenceChange(event);
        }
    }

}
