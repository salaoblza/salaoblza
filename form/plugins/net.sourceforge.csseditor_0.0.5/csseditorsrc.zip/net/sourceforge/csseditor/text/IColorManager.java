/*
 * Copyright (c) 2003 Christopher Lenz and others.
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 * 
 * Contributors:
 *     Christopher Lenz - initial API and implementation
 * 
 * $Id: IColorManager.java,v 1.1.1.1 2003/12/14 21:59:59 cell Exp $
 */

package net.sourceforge.csseditor.text;

import org.eclipse.jface.text.source.ISharedTextColors;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.RGB;

/**
 * Extends the <code>ISharedTextColors</code> interface by providing methods
 * to bind and unbind colors to specific keys, and retrieve the colors by key.
 */
public interface IColorManager extends ISharedTextColors {

    /**
     * Binds a color to the specified key.
     * 
     * @param key the key to which the color should be bound
     * @param rgb the color to bind to the key
     */
    void bindColor(String key, RGB rgb);

    /**
     * Returns the color bound to a specific key.
     * 
     * @param key the key to which the color was previously bound
     * @return the color bound to the specified key, or <code>null</code> if no
     *         color was bound to that key
     */
    Color getColor(String key);

    /**
     * Unbinds (and disposes) a color.
     * 
     * @param key the key to which the color was previously bound
     */
    void unbindColor(String key);

}
