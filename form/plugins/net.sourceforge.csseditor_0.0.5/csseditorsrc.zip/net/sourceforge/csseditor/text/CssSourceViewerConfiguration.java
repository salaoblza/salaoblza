/*
 * Copyright (c) 2003 Christopher Lenz and others.
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 * 
 * Contributors:
 *     Christopher Lenz - initial API and implementation
 * 
 * $Id: CssSourceViewerConfiguration.java,v 1.3 2004/01/13 17:15:52 cell Exp $
 */

package net.sourceforge.csseditor.text;

import java.util.ArrayList;
import java.util.List;

import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.NullProgressMonitor;
import org.eclipse.jface.preference.IPreferenceStore;
import org.eclipse.jface.preference.PreferenceConverter;
import org.eclipse.jface.text.DefaultAutoIndentStrategy;
import org.eclipse.jface.text.DefaultTextDoubleClickStrategy;
import org.eclipse.jface.text.IAutoIndentStrategy;
import org.eclipse.jface.text.IDocument;
import org.eclipse.jface.text.ITextDoubleClickStrategy;
import org.eclipse.jface.text.ITextHover;
import org.eclipse.jface.text.contentassist.ContentAssistant;
import org.eclipse.jface.text.contentassist.IContentAssistant;
import org.eclipse.jface.text.presentation.IPresentationReconciler;
import org.eclipse.jface.text.presentation.PresentationReconciler;
import org.eclipse.jface.text.reconciler.IReconciler;
import org.eclipse.jface.text.reconciler.IReconcilingStrategy;
import org.eclipse.jface.text.reconciler.Reconciler;
import org.eclipse.jface.text.rules.DefaultDamagerRepairer;
import org.eclipse.jface.text.source.IAnnotationHover;
import org.eclipse.jface.text.source.IAnnotationModel;
import org.eclipse.jface.text.source.ISourceViewer;
import org.eclipse.jface.text.source.SourceViewerConfiguration;
import org.eclipse.ui.IEditorInput;
import org.eclipse.ui.IFileEditorInput;
import org.eclipse.ui.texteditor.IDocumentProvider;
import org.eclipse.ui.texteditor.ITextEditor;

import net.sourceforge.csseditor.CssEditorPlugin;
import net.sourceforge.csseditor.IProfile;
import net.sourceforge.csseditor.IProfileManager;
import net.sourceforge.csseditor.internal.CssEditorPreferences;
import net.sourceforge.csseditor.internal.text.CssAnnotationHover;
import net.sourceforge.csseditor.internal.text.CssAutoEditStrategy;
import net.sourceforge.csseditor.internal.text.CssContentAssistProcessor;
import net.sourceforge.csseditor.internal.text.CssDoubleClickStrategy;
import net.sourceforge.csseditor.internal.text.CssPartitionScanner;
import net.sourceforge.csseditor.internal.text.CssReconcilingStrategy;

/**
 * Source viewer configuration for CSS.
 */
public final class CssSourceViewerConfiguration
    extends SourceViewerConfiguration {

    // Constants ---------------------------------------------------------------

    /**
     * Alias for the preference constant <code>CONTENTASSIST_AUTOINSERT</code>.
     */
    private static final String AUTOINSERT =
        CssEditorPreferences.CONTENTASSIST_AUTOINSERT;

    /**
     * Alias for the preference constant
     * <code>CONTENTASSIST_AUTOACTIVATION</code>.
     */
    private static final String AUTOACTIVATION =
        CssEditorPreferences.CONTENTASSIST_AUTOACTIVATION;

    /**
     * Alias for the preference constant
     * <code>CONTENTASSIST_AUTOACTIVATION_DELAY</code>.
     */
    private static final String AUTOACTIVATION_DELAY =
        CssEditorPreferences.CONTENTASSIST_AUTOACTIVATION_DELAY;

    /**
     * Alias for the preference constant
     * <code>CONTENTASSIST_PROPOSALS_BACKGROUND</code>.
     */
    private static final String PROPOSALS_BACKGROUND =
        CssEditorPreferences.CONTENTASSIST_PROPOSALS_BACKGROUND;

    /**
     * Alias for the preference constant
     * <code>CONTENTASSIST_PROPOSALS_FOREGROUND</code>.
     */
    private static final String PROPOSALS_FOREGROUND =
        CssEditorPreferences.CONTENTASSIST_PROPOSALS_FOREGROUND;

    /**
     * Alias for the preference constant <code>EDITOR_SPACES_FOR_TABS</code>.
     */
    private static final String SPACES_FOR_TABS =
        CssEditorPreferences.EDITOR_SPACES_FOR_TABS;

    /**
     * Alias for the preference constant <code>EDITOR_TAB_WIDTH</code>.
     */
    private static final String TAB_WIDTH =
        CssEditorPreferences.EDITOR_TAB_WIDTH;

    // Instance Variables ------------------------------------------------------

    /**
     * The associated editor.
     */
    private ITextEditor editor;

    /**
     * The preference store used.
     */
    private IPreferenceStore store;

    /**
     * The CSS profile.
     */
    private IProfile profile;

    /**
     * The associated text tools.
     */
    private CssTextTools textTools;

    // Constructors ------------------------------------------------------------

    /**
     * Default constructor.
     */
    public CssSourceViewerConfiguration() {
        this(CssEditorPlugin.getDefault().getTextTools(),
             CssEditorPlugin.getDefault().getPreferenceStore());
    }

    /**
     * Constructor.
     * 
     * @param textTools the CSS text tools to associate with the source viewer
     *        configuration
     */
    public CssSourceViewerConfiguration(CssTextTools textTools) {
        this(textTools, CssEditorPlugin.getDefault().getPreferenceStore());
    }

    /**
     * Constructor.
     * 
     * @param textTools the CSS text tools to associate with the source viewer
     *        configuration
     * @param store the preference store
     */
    public CssSourceViewerConfiguration(CssTextTools textTools,
        IPreferenceStore store) {
        this(textTools, store, null);
    }

    /**
     * Constructor.
     * 
     * @param textTools the CSS text tools to associate with the source viewer
     *        configuration
     * @param store the preference store
     * @param editor the text editor
     */
    public CssSourceViewerConfiguration(CssTextTools textTools,
        IPreferenceStore store, ITextEditor editor) {
        this.textTools = textTools;
        this.store = store;
        this.editor = editor;
    }

    // SourceViewerConfiguration Implementation --------------------------------

    /*
     * @see SourceViewerConfiguration#getAnnotationHover(ISourceViewer)
     */
    public IAnnotationHover getAnnotationHover(ISourceViewer sourceViewer) {
        return new CssAnnotationHover(null);
    }

    /*
     * @see SourceViewerConfiguration#getAutoIndentStrategy(ISourceViewer, String)
     */
    public IAutoIndentStrategy getAutoIndentStrategy(
        ISourceViewer sourceViewer, String contentType) {
        if (IDocument.DEFAULT_CONTENT_TYPE.equals(contentType)) {
            return new CssAutoEditStrategy();
        }
        return new DefaultAutoIndentStrategy();
    }

    /*
     * @see SourceViewerConfiguration#getConfiguredContentTypes(ISourceViewer)
     */
    public String[] getConfiguredContentTypes(ISourceViewer sourceViewer) {
        return new String[] {
            IDocument.DEFAULT_CONTENT_TYPE,
            CssPartitionScanner.CSS_COMMENT,
            CssPartitionScanner.CSS_STRING
        };
    }

    /*
     * @see SourceViewerConfiguration#getContentAssistant(ISourceViewer)
     */
    public IContentAssistant getContentAssistant(ISourceViewer sourceViewer) {
        ContentAssistant assistant = new ContentAssistant();
        assistant.setContentAssistProcessor(
            new CssContentAssistProcessor(store, getProfile(), editor),
            IDocument.DEFAULT_CONTENT_TYPE);
        assistant.setInformationControlCreator(
            getInformationControlCreator(sourceViewer));
        assistant.enableAutoInsert(store.getBoolean(AUTOINSERT));
        assistant.enableAutoActivation(store.getBoolean(AUTOACTIVATION));
        assistant.setAutoActivationDelay(store.getInt(AUTOACTIVATION_DELAY));
        assistant.setContextInformationPopupOrientation(
            IContentAssistant.CONTEXT_INFO_BELOW);
        assistant.setProposalPopupOrientation(
            IContentAssistant.PROPOSAL_STACKED);
        assistant.setProposalSelectorBackground(getColorManager().getColor(
            PreferenceConverter.getColor(store, PROPOSALS_BACKGROUND)));
        assistant.setProposalSelectorForeground(getColorManager().getColor(
            PreferenceConverter.getColor(store, PROPOSALS_FOREGROUND)));
        return assistant;
    }

    /*
     * @see SourceViewerConfiguration#getDoubleClickStrategy(ISourceViewer, String)
     */
    public ITextDoubleClickStrategy getDoubleClickStrategy(
        ISourceViewer sourceViewer, String contentType) {
        if (IDocument.DEFAULT_CONTENT_TYPE.equals(contentType)) {
            return new CssDoubleClickStrategy();
        }
        return new DefaultTextDoubleClickStrategy();
    }

    /*
     * @see SourceViewerConfiguration#getIndentPrefixes(ISourceViewer, String)
     */
    public String[] getIndentPrefixes(ISourceViewer sourceViewer,
        String contentType) {
        List retVal = new ArrayList();
        int tabWidth = getTabWidth(sourceViewer);
        boolean useSpaces = this.store.getBoolean(SPACES_FOR_TABS);
        for (int i = 0; i <= tabWidth; i++) {
            StringBuffer prefix = new StringBuffer();
            if (useSpaces) {
                for (int j = 0; j + i < tabWidth; j++) {
                    prefix.append(' ');
                }
                if (i != 0) {
                    prefix.append('\t');
                }
            } else {    
                for (int j = 0; j < i; j++) {
                    prefix.append(' ');
                }
                if (i != tabWidth) {
                    prefix.append('\t');
                }
            }
            retVal.add(prefix.toString());
        }
        retVal.add(""); //$NON-NLS-1$
        return (String[]) retVal.toArray(new String[retVal.size()]);
    }

    /*
     * @see SourceViewerConfiguration#getPresentationReconciler(ISourceViewer)
     */
    public IPresentationReconciler getPresentationReconciler(
        ISourceViewer sourceViewer) {

        PresentationReconciler reconciler = new PresentationReconciler();
        DefaultDamagerRepairer dr;

        // Comments
        dr = new DefaultDamagerRepairer(textTools.getCommentScanner());
        reconciler.setDamager(dr, CssPartitionScanner.CSS_COMMENT);
        reconciler.setRepairer(dr, CssPartitionScanner.CSS_COMMENT);

        // Strings
        dr = new DefaultDamagerRepairer(textTools.getStringScanner());
        reconciler.setDamager(dr, CssPartitionScanner.CSS_STRING);
        reconciler.setRepairer(dr, CssPartitionScanner.CSS_STRING);

        // Code
        dr = new DefaultDamagerRepairer(textTools.getCodeScanner());
        reconciler.setDamager(dr, IDocument.DEFAULT_CONTENT_TYPE);
        reconciler.setRepairer(dr, IDocument.DEFAULT_CONTENT_TYPE);

        return reconciler;
    }

    /*
     * @see SourceViewerConfiguration#getReconciler(ISourceViewer)
     */
    public IReconciler getReconciler(ISourceViewer sourceViewer) {
        if ((editor != null) && editor.isEditable()) {
            Reconciler reconciler = new Reconciler();
            IReconcilingStrategy strategy =
                new CssReconcilingStrategy(editor);
            reconciler.setReconcilingStrategy(strategy,
                IDocument.DEFAULT_CONTENT_TYPE);
            reconciler.setReconcilingStrategy(strategy,
                CssPartitionScanner.CSS_COMMENT);
            reconciler.setReconcilingStrategy(strategy,
                CssPartitionScanner.CSS_STRING);
            reconciler.setProgressMonitor(new NullProgressMonitor());
            reconciler.setDelay(500);
            return reconciler;
        }
        return null;
    }

    /*
     * @see SourceViewerConfiguration#getTabWidth(ISourceViewer)
     */
    public int getTabWidth(ISourceViewer sourceViewer) {
        return store.getInt(TAB_WIDTH);
    }

    /*
     * @see SourceViewerConfiguration#getTextHover(ISourceViewer, String)
     */
    public ITextHover getTextHover(ISourceViewer sourceViewer,
        String contentType) {
        if (editor != null) {
            IDocumentProvider provider = editor.getDocumentProvider();
            IEditorInput input = editor.getEditorInput();
            IAnnotationModel model = provider.getAnnotationModel(input);
            return new CssAnnotationHover(model);
        }
        return super.getTextHover(sourceViewer, contentType);
    }

    // Private Methods ---------------------------------------------------------

    /**
     * Returns the color manager associated with this configuration.
     * 
     * @return the color manager
     */
    private IColorManager getColorManager() {
        if (textTools != null) {
            return textTools.getColorManager();
        }
        return null;
    }

    /**
     * Returns the CSS profile for the resource currently being viewed, or 
     * the default profile if this source viewer configuration isn't associated
     * with an editor.
     * 
     * @return the profile
     */
    private IProfile getProfile() {
        if (profile == null) {
            IResource resource = null;
            if (editor != null) {
                IEditorInput input = editor.getEditorInput();
                if (input instanceof IFileEditorInput) {
                    resource = ((IFileEditorInput) input).getFile();
                }
            }
            IProfileManager mgr =
                CssEditorPlugin.getDefault().getProfileManager();
            profile = mgr.getProfile(resource);
        }
        return profile;
    }

}
